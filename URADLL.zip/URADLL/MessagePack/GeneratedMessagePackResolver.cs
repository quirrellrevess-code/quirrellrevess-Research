using System;
using System.Collections.Generic;
using Cute.Http;
using Gallop;
using MessagePack.Formatters;
using MessagePack.Internal;

namespace MessagePack;

internal class GeneratedMessagePackResolver : IFormatterResolver
{
	private static class FormatterCache<T>
	{
		internal static readonly IMessagePackFormatter<T> Formatter;

		static FormatterCache()
		{
			object formatter = GeneratedMessagePackResolverGetFormatterHelper.GetFormatter(typeof(T));
			if (formatter != null)
			{
				Formatter = (IMessagePackFormatter<T>)formatter;
			}
		}
	}

	private static class GeneratedMessagePackResolverGetFormatterHelper
	{
		private static readonly Dictionary<Type, int> closedTypeLookup = new Dictionary<Type, int>(179)
		{
			{
				typeof(SingleModeSportCommandInfo.SingleModeSportGainRank[]),
				0
			},
			{
				typeof(ArcEvaluationInfo[]),
				1
			},
			{
				typeof(ArcPotential[]),
				2
			},
			{
				typeof(ArcRivalPotential[]),
				3
			},
			{
				typeof(ArcSelectionPeff[]),
				4
			},
			{
				typeof(ChampionsRoomUser[]),
				5
			},
			{
				typeof(ChampionsUserChara[]),
				6
			},
			{
				typeof(ChoiceArray[]),
				7
			},
			{
				typeof(DirectoryCard[]),
				8
			},
			{
				typeof(EvaluationInfo[]),
				9
			},
			{
				typeof(FactorExtendInfo[]),
				10
			},
			{
				typeof(FactorInfo[]),
				11
			},
			{
				typeof(GroupOutingInfo[]),
				12
			},
			{
				typeof(GuestOutingInfo[]),
				13
			},
			{
				typeof(MinigameResultDetail[]),
				14
			},
			{
				typeof(NotGainCharaEffect[]),
				15
			},
			{
				typeof(PracticePartnerOwnerInfo[]),
				16
			},
			{
				typeof(PracticeRaceEntryInfo[]),
				17
			},
			{
				typeof(RaceHorseData[]),
				18
			},
			{
				typeof(RaceHorseDataRaceResult[]),
				19
			},
			{
				typeof(RaceRewardData[]),
				20
			},
			{
				typeof(SingleModeArcCommandInfo[]),
				21
			},
			{
				typeof(SingleModeArcPotentialProgress[]),
				22
			},
			{
				typeof(SingleModeArcRaceHistory[]),
				23
			},
			{
				typeof(SingleModeArcRival[]),
				24
			},
			{
				typeof(SingleModeArcSelectionRivalInfo[]),
				25
			},
			{
				typeof(SingleModeCommandInfo[]),
				26
			},
			{
				typeof(SingleModeFreeCommandInfo[]),
				27
			},
			{
				typeof(SingleModeFreeItemEffect[]),
				28
			},
			{
				typeof(SingleModeFreePickUpItem[]),
				29
			},
			{
				typeof(SingleModeFreeTwinkleRaceNpcInfo[]),
				30
			},
			{
				typeof(SingleModeFreeUserItem[]),
				31
			},
			{
				typeof(SingleModeLiveCommandInfo[]),
				32
			},
			{
				typeof(SingleModeNpcResult[]),
				33
			},
			{
				typeof(SingleModeParamsIncDecInfo[]),
				34
			},
			{
				typeof(SingleModeRivalRaceInfo[]),
				35
			},
			{
				typeof(SingleModeSportCommandInfo[]),
				36
			},
			{
				typeof(SingleModeSportCompetitionResult[]),
				37
			},
			{
				typeof(SingleModeSportEffectedStance[]),
				38
			},
			{
				typeof(SingleModeSportTraining[]),
				39
			},
			{
				typeof(SingleModeSuccessionGainInfo[]),
				40
			},
			{
				typeof(SingleModeSupportCard[]),
				41
			},
			{
				typeof(SingleModeTeamCommandInfo[]),
				42
			},
			{
				typeof(SingleModeTwikleRaceNpcResult[]),
				43
			},
			{
				typeof(SingleModeVenusActiveSpiritEffect[]),
				44
			},
			{
				typeof(SingleModeVenusCharaCommandInfo[]),
				45
			},
			{
				typeof(SingleModeVenusCharaInfo[]),
				46
			},
			{
				typeof(SingleModeVenusCommandInfo[]),
				47
			},
			{
				typeof(SingleModeVenusEvaluationInfo[]),
				48
			},
			{
				typeof(SingleModeVenusRaceHistory[]),
				49
			},
			{
				typeof(SingleModeVenusSpiritInfo[]),
				50
			},
			{
				typeof(SkillData[]),
				51
			},
			{
				typeof(SkillTips[]),
				52
			},
			{
				typeof(SkillUpgradeInfo[]),
				53
			},
			{
				typeof(SuccessionChara[]),
				54
			},
			{
				typeof(SuccessionEffectedFactor[]),
				55
			},
			{
				typeof(SuccessionHistory[]),
				56
			},
			{
				typeof(TeamStadiumOpponent[]),
				57
			},
			{
				typeof(TeamStadiumTeamData[]),
				58
			},
			{
				typeof(TrainedChara[]),
				59
			},
			{
				typeof(TrainedCharaFavorite[]),
				60
			},
			{
				typeof(TrainedCharaRaceResult[]),
				61
			},
			{
				typeof(TrainedCharaSupportCardList[]),
				62
			},
			{
				typeof(TrainingLevelInfo[]),
				63
			},
			{
				typeof(UserSupportCard[]),
				64
			},
			{
				typeof(UserTrainedCharaAtFriend[]),
				65
			},
			{
				typeof(ChampionsFinalRaceStartResponse.CommonResponse),
				66
			},
			{
				typeof(FriendSearchResponse.CommonResponse),
				67
			},
			{
				typeof(PracticeRaceRaceStartResponse.CommonResponse),
				68
			},
			{
				typeof(RoomMatchRaceStartResponse.CommonResponse),
				69
			},
			{
				typeof(SingleModeSportCommandInfo.SingleModeSportGainRank),
				70
			},
			{
				typeof(TeamStadiumOpponentListResponse.CommonResponse),
				71
			},
			{
				typeof(TrainedCharaLoadResponse.CommonResponse),
				72
			},
			{
				typeof(DataHeader),
				73
			},
			{
				typeof(ArcEvaluationInfo),
				74
			},
			{
				typeof(ArcPotential),
				75
			},
			{
				typeof(ArcRivalPotential),
				76
			},
			{
				typeof(ArcSelectionPeff),
				77
			},
			{
				typeof(ChampionsFinalRaceStartResponse),
				78
			},
			{
				typeof(ChampionsRoomInfo),
				79
			},
			{
				typeof(ChampionsRoomUser),
				80
			},
			{
				typeof(ChampionsUserChara),
				81
			},
			{
				typeof(CharaRaceReward),
				82
			},
			{
				typeof(ChoiceArray),
				83
			},
			{
				typeof(CircleInfoAtFriend),
				84
			},
			{
				typeof(CircleUser),
				85
			},
			{
				typeof(DirectoryCard),
				86
			},
			{
				typeof(EvaluationInfo),
				87
			},
			{
				typeof(EventContentsInfo),
				88
			},
			{
				typeof(FactorExtendInfo),
				89
			},
			{
				typeof(FactorInfo),
				90
			},
			{
				typeof(FriendSearchResponse),
				91
			},
			{
				typeof(GroupOutingInfo),
				92
			},
			{
				typeof(GuestOutingInfo),
				93
			},
			{
				typeof(MinigameResult),
				94
			},
			{
				typeof(MinigameResultDetail),
				95
			},
			{
				typeof(NotDownParameterInfo),
				96
			},
			{
				typeof(NotGainCharaEffect),
				97
			},
			{
				typeof(NotUpArcParameterInfo),
				98
			},
			{
				typeof(NotUpParameterInfo),
				99
			},
			{
				typeof(PracticePartnerOwnerInfo),
				100
			},
			{
				typeof(PracticeRaceEntryInfo),
				101
			},
			{
				typeof(PracticeRaceRaceStartResponse),
				102
			},
			{
				typeof(RaceAnalyzeRequest),
				103
			},
			{
				typeof(RaceHorseData),
				104
			},
			{
				typeof(RaceHorseDataRaceResult),
				105
			},
			{
				typeof(RaceResultInfo),
				106
			},
			{
				typeof(RaceRewardData),
				107
			},
			{
				typeof(ReleaseNumInfo),
				108
			},
			{
				typeof(ResponseCommon),
				109
			},
			{
				typeof(RoomMatchRaceStartResponse),
				110
			},
			{
				typeof(SingleModeArcCommandInfo),
				111
			},
			{
				typeof(SingleModeArcDataSet),
				112
			},
			{
				typeof(SingleModeArcInfo),
				113
			},
			{
				typeof(SingleModeArcPotentialProgress),
				114
			},
			{
				typeof(SingleModeArcRaceHistory),
				115
			},
			{
				typeof(SingleModeArcRival),
				116
			},
			{
				typeof(SingleModeArcSelectionInfo),
				117
			},
			{
				typeof(SingleModeArcSelectionRivalInfo),
				118
			},
			{
				typeof(SingleModeChara),
				119
			},
			{
				typeof(SingleModeChoiceRequest),
				120
			},
			{
				typeof(SingleModeCommandInfo),
				121
			},
			{
				typeof(SingleModeEventInfo),
				122
			},
			{
				typeof(SingleModeExecCommandRequest),
				123
			},
			{
				typeof(SingleModeFreeCommandInfo),
				124
			},
			{
				typeof(SingleModeFreeDataSet),
				125
			},
			{
				typeof(SingleModeFreeItemEffect),
				126
			},
			{
				typeof(SingleModeFreePickUpItem),
				127
			},
			{
				typeof(SingleModeFreeTwinkleRaceNpcInfo),
				128
			},
			{
				typeof(SingleModeFreeUserItem),
				129
			},
			{
				typeof(SingleModeHomeInfo),
				130
			},
			{
				typeof(SingleModeLiveCommandInfo),
				131
			},
			{
				typeof(SingleModeLiveDataSet),
				132
			},
			{
				typeof(SingleModeNpcResult),
				133
			},
			{
				typeof(SingleModeParamsIncDecInfo),
				134
			},
			{
				typeof(SingleModeRaceCondition),
				135
			},
			{
				typeof(SingleModeRivalRaceInfo),
				136
			},
			{
				typeof(SingleModeSportCommandInfo),
				137
			},
			{
				typeof(SingleModeSportCompetitionResult),
				138
			},
			{
				typeof(SingleModeSportDataSet),
				139
			},
			{
				typeof(SingleModeSportEffectedStance),
				140
			},
			{
				typeof(SingleModeSportTraining),
				141
			},
			{
				typeof(SingleModeSuccessionEventInfo),
				142
			},
			{
				typeof(SingleModeSuccessionGainInfo),
				143
			},
			{
				typeof(SingleModeSupportCard),
				144
			},
			{
				typeof(SingleModeTeamCommandInfo),
				145
			},
			{
				typeof(SingleModeTeamDataSet),
				146
			},
			{
				typeof(SingleModeTwikleRaceNpcResult),
				147
			},
			{
				typeof(SingleModeVenusActiveSpiritEffect),
				148
			},
			{
				typeof(SingleModeVenusCharaCommandInfo),
				149
			},
			{
				typeof(SingleModeVenusCharaInfo),
				150
			},
			{
				typeof(SingleModeVenusCommandInfo),
				151
			},
			{
				typeof(SingleModeVenusDataSet),
				152
			},
			{
				typeof(SingleModeVenusEvaluationInfo),
				153
			},
			{
				typeof(SingleModeVenusRaceHistory),
				154
			},
			{
				typeof(SingleModeVenusSpiritInfo),
				155
			},
			{
				typeof(SingleRaceStartInfo),
				156
			},
			{
				typeof(SkillData),
				157
			},
			{
				typeof(SkillTips),
				158
			},
			{
				typeof(SkillUpgradeInfo),
				159
			},
			{
				typeof(SuccessionChara),
				160
			},
			{
				typeof(SuccessionEffectedFactor),
				161
			},
			{
				typeof(SuccessionHistory),
				162
			},
			{
				typeof(TeamStadiumOpponent),
				163
			},
			{
				typeof(TeamStadiumOpponentListResponse),
				164
			},
			{
				typeof(TeamStadiumTeamData),
				165
			},
			{
				typeof(TeamStadiumUser),
				166
			},
			{
				typeof(TrainedChara),
				167
			},
			{
				typeof(TrainedCharaFavorite),
				168
			},
			{
				typeof(TrainedCharaLoadResponse),
				169
			},
			{
				typeof(TrainedCharaRaceResult),
				170
			},
			{
				typeof(TrainedCharaSupportCardList),
				171
			},
			{
				typeof(TrainingLevelInfo),
				172
			},
			{
				typeof(TrophyNumInfo),
				173
			},
			{
				typeof(UserFriend),
				174
			},
			{
				typeof(UserInfoAtFriend),
				175
			},
			{
				typeof(UserSupportCard),
				176
			},
			{
				typeof(UserSupportCardAtFriend),
				177
			},
			{
				typeof(UserTrainedCharaAtFriend),
				178
			}
		};

		internal static object GetFormatter(Type t)
		{
			if (closedTypeLookup.TryGetValue(t, out var value))
			{
				return value switch
				{
					0 => (object)new ArrayFormatter<SingleModeSportCommandInfo.SingleModeSportGainRank>(), 
					1 => new ArrayFormatter<ArcEvaluationInfo>(), 
					2 => new ArrayFormatter<ArcPotential>(), 
					3 => new ArrayFormatter<ArcRivalPotential>(), 
					4 => new ArrayFormatter<ArcSelectionPeff>(), 
					5 => new ArrayFormatter<ChampionsRoomUser>(), 
					6 => new ArrayFormatter<ChampionsUserChara>(), 
					7 => new ArrayFormatter<ChoiceArray>(), 
					8 => new ArrayFormatter<DirectoryCard>(), 
					9 => new ArrayFormatter<EvaluationInfo>(), 
					10 => new ArrayFormatter<FactorExtendInfo>(), 
					11 => new ArrayFormatter<FactorInfo>(), 
					12 => new ArrayFormatter<GroupOutingInfo>(), 
					13 => new ArrayFormatter<GuestOutingInfo>(), 
					14 => new ArrayFormatter<MinigameResultDetail>(), 
					15 => new ArrayFormatter<NotGainCharaEffect>(), 
					16 => new ArrayFormatter<PracticePartnerOwnerInfo>(), 
					17 => new ArrayFormatter<PracticeRaceEntryInfo>(), 
					18 => new ArrayFormatter<RaceHorseData>(), 
					19 => new ArrayFormatter<RaceHorseDataRaceResult>(), 
					20 => new ArrayFormatter<RaceRewardData>(), 
					21 => new ArrayFormatter<SingleModeArcCommandInfo>(), 
					22 => new ArrayFormatter<SingleModeArcPotentialProgress>(), 
					23 => new ArrayFormatter<SingleModeArcRaceHistory>(), 
					24 => new ArrayFormatter<SingleModeArcRival>(), 
					25 => new ArrayFormatter<SingleModeArcSelectionRivalInfo>(), 
					26 => new ArrayFormatter<SingleModeCommandInfo>(), 
					27 => new ArrayFormatter<SingleModeFreeCommandInfo>(), 
					28 => new ArrayFormatter<SingleModeFreeItemEffect>(), 
					29 => new ArrayFormatter<SingleModeFreePickUpItem>(), 
					30 => new ArrayFormatter<SingleModeFreeTwinkleRaceNpcInfo>(), 
					31 => new ArrayFormatter<SingleModeFreeUserItem>(), 
					32 => new ArrayFormatter<SingleModeLiveCommandInfo>(), 
					33 => new ArrayFormatter<SingleModeNpcResult>(), 
					34 => new ArrayFormatter<SingleModeParamsIncDecInfo>(), 
					35 => new ArrayFormatter<SingleModeRivalRaceInfo>(), 
					36 => new ArrayFormatter<SingleModeSportCommandInfo>(), 
					37 => new ArrayFormatter<SingleModeSportCompetitionResult>(), 
					38 => new ArrayFormatter<SingleModeSportEffectedStance>(), 
					39 => new ArrayFormatter<SingleModeSportTraining>(), 
					40 => new ArrayFormatter<SingleModeSuccessionGainInfo>(), 
					41 => new ArrayFormatter<SingleModeSupportCard>(), 
					42 => new ArrayFormatter<SingleModeTeamCommandInfo>(), 
					43 => new ArrayFormatter<SingleModeTwikleRaceNpcResult>(), 
					44 => new ArrayFormatter<SingleModeVenusActiveSpiritEffect>(), 
					45 => new ArrayFormatter<SingleModeVenusCharaCommandInfo>(), 
					46 => new ArrayFormatter<SingleModeVenusCharaInfo>(), 
					47 => new ArrayFormatter<SingleModeVenusCommandInfo>(), 
					48 => new ArrayFormatter<SingleModeVenusEvaluationInfo>(), 
					49 => new ArrayFormatter<SingleModeVenusRaceHistory>(), 
					50 => new ArrayFormatter<SingleModeVenusSpiritInfo>(), 
					51 => new ArrayFormatter<SkillData>(), 
					52 => new ArrayFormatter<SkillTips>(), 
					53 => new ArrayFormatter<SkillUpgradeInfo>(), 
					54 => new ArrayFormatter<SuccessionChara>(), 
					55 => new ArrayFormatter<SuccessionEffectedFactor>(), 
					56 => new ArrayFormatter<SuccessionHistory>(), 
					57 => new ArrayFormatter<TeamStadiumOpponent>(), 
					58 => new ArrayFormatter<TeamStadiumTeamData>(), 
					59 => new ArrayFormatter<TrainedChara>(), 
					60 => new ArrayFormatter<TrainedCharaFavorite>(), 
					61 => new ArrayFormatter<TrainedCharaRaceResult>(), 
					62 => new ArrayFormatter<TrainedCharaSupportCardList>(), 
					63 => new ArrayFormatter<TrainingLevelInfo>(), 
					64 => new ArrayFormatter<UserSupportCard>(), 
					65 => new ArrayFormatter<UserTrainedCharaAtFriend>(), 
					66 => new Gallop.ChampionsFinalRaceStartResponse.CommonResponseFormatter(), 
					67 => new Gallop.FriendSearchResponse.CommonResponseFormatter(), 
					68 => new Gallop.PracticeRaceRaceStartResponse.CommonResponseFormatter(), 
					69 => new Gallop.RoomMatchRaceStartResponse.CommonResponseFormatter(), 
					70 => new Gallop.SingleModeSportCommandInfo.SingleModeSportGainRankFormatter(), 
					71 => new Gallop.TeamStadiumOpponentListResponse.CommonResponseFormatter(), 
					72 => new Gallop.TrainedCharaLoadResponse.CommonResponseFormatter(), 
					73 => new Cute.Http.DataHeaderFormatter(), 
					74 => new Gallop.ArcEvaluationInfoFormatter(), 
					75 => new Gallop.ArcPotentialFormatter(), 
					76 => new Gallop.ArcRivalPotentialFormatter(), 
					77 => new Gallop.ArcSelectionPeffFormatter(), 
					78 => new Gallop.ChampionsFinalRaceStartResponseFormatter(), 
					79 => new Gallop.ChampionsRoomInfoFormatter(), 
					80 => new Gallop.ChampionsRoomUserFormatter(), 
					81 => new Gallop.ChampionsUserCharaFormatter(), 
					82 => new Gallop.CharaRaceRewardFormatter(), 
					83 => new Gallop.ChoiceArrayFormatter(), 
					84 => new Gallop.CircleInfoAtFriendFormatter(), 
					85 => new Gallop.CircleUserFormatter(), 
					86 => new Gallop.DirectoryCardFormatter(), 
					87 => new Gallop.EvaluationInfoFormatter(), 
					88 => new Gallop.EventContentsInfoFormatter(), 
					89 => new Gallop.FactorExtendInfoFormatter(), 
					90 => new Gallop.FactorInfoFormatter(), 
					91 => new Gallop.FriendSearchResponseFormatter(), 
					92 => new Gallop.GroupOutingInfoFormatter(), 
					93 => new Gallop.GuestOutingInfoFormatter(), 
					94 => new Gallop.MinigameResultFormatter(), 
					95 => new Gallop.MinigameResultDetailFormatter(), 
					96 => new Gallop.NotDownParameterInfoFormatter(), 
					97 => new Gallop.NotGainCharaEffectFormatter(), 
					98 => new Gallop.NotUpArcParameterInfoFormatter(), 
					99 => new Gallop.NotUpParameterInfoFormatter(), 
					100 => new Gallop.PracticePartnerOwnerInfoFormatter(), 
					101 => new Gallop.PracticeRaceEntryInfoFormatter(), 
					102 => new Gallop.PracticeRaceRaceStartResponseFormatter(), 
					103 => new Gallop.RaceAnalyzeRequestFormatter(), 
					104 => new Gallop.RaceHorseDataFormatter(), 
					105 => new Gallop.RaceHorseDataRaceResultFormatter(), 
					106 => new Gallop.RaceResultInfoFormatter(), 
					107 => new Gallop.RaceRewardDataFormatter(), 
					108 => new Gallop.ReleaseNumInfoFormatter(), 
					109 => new Gallop.ResponseCommonFormatter(), 
					110 => new Gallop.RoomMatchRaceStartResponseFormatter(), 
					111 => new Gallop.SingleModeArcCommandInfoFormatter(), 
					112 => new Gallop.SingleModeArcDataSetFormatter(), 
					113 => new Gallop.SingleModeArcInfoFormatter(), 
					114 => new Gallop.SingleModeArcPotentialProgressFormatter(), 
					115 => new Gallop.SingleModeArcRaceHistoryFormatter(), 
					116 => new Gallop.SingleModeArcRivalFormatter(), 
					117 => new Gallop.SingleModeArcSelectionInfoFormatter(), 
					118 => new Gallop.SingleModeArcSelectionRivalInfoFormatter(), 
					119 => new Gallop.SingleModeCharaFormatter(), 
					120 => new Gallop.SingleModeChoiceRequestFormatter(), 
					121 => new Gallop.SingleModeCommandInfoFormatter(), 
					122 => new Gallop.SingleModeEventInfoFormatter(), 
					123 => new Gallop.SingleModeExecCommandRequestFormatter(), 
					124 => new Gallop.SingleModeFreeCommandInfoFormatter(), 
					125 => new Gallop.SingleModeFreeDataSetFormatter(), 
					126 => new Gallop.SingleModeFreeItemEffectFormatter(), 
					127 => new Gallop.SingleModeFreePickUpItemFormatter(), 
					128 => new Gallop.SingleModeFreeTwinkleRaceNpcInfoFormatter(), 
					129 => new Gallop.SingleModeFreeUserItemFormatter(), 
					130 => new Gallop.SingleModeHomeInfoFormatter(), 
					131 => new Gallop.SingleModeLiveCommandInfoFormatter(), 
					132 => new Gallop.SingleModeLiveDataSetFormatter(), 
					133 => new Gallop.SingleModeNpcResultFormatter(), 
					134 => new Gallop.SingleModeParamsIncDecInfoFormatter(), 
					135 => new Gallop.SingleModeRaceConditionFormatter(), 
					136 => new Gallop.SingleModeRivalRaceInfoFormatter(), 
					137 => new Gallop.SingleModeSportCommandInfoFormatter(), 
					138 => new Gallop.SingleModeSportCompetitionResultFormatter(), 
					139 => new Gallop.SingleModeSportDataSetFormatter(), 
					140 => new Gallop.SingleModeSportEffectedStanceFormatter(), 
					141 => new Gallop.SingleModeSportTrainingFormatter(), 
					142 => new Gallop.SingleModeSuccessionEventInfoFormatter(), 
					143 => new Gallop.SingleModeSuccessionGainInfoFormatter(), 
					144 => new Gallop.SingleModeSupportCardFormatter(), 
					145 => new Gallop.SingleModeTeamCommandInfoFormatter(), 
					146 => new Gallop.SingleModeTeamDataSetFormatter(), 
					147 => new Gallop.SingleModeTwikleRaceNpcResultFormatter(), 
					148 => new Gallop.SingleModeVenusActiveSpiritEffectFormatter(), 
					149 => new Gallop.SingleModeVenusCharaCommandInfoFormatter(), 
					150 => new Gallop.SingleModeVenusCharaInfoFormatter(), 
					151 => new Gallop.SingleModeVenusCommandInfoFormatter(), 
					152 => new Gallop.SingleModeVenusDataSetFormatter(), 
					153 => new Gallop.SingleModeVenusEvaluationInfoFormatter(), 
					154 => new Gallop.SingleModeVenusRaceHistoryFormatter(), 
					155 => new Gallop.SingleModeVenusSpiritInfoFormatter(), 
					156 => new Gallop.SingleRaceStartInfoFormatter(), 
					157 => new Gallop.SkillDataFormatter(), 
					158 => new Gallop.SkillTipsFormatter(), 
					159 => new Gallop.SkillUpgradeInfoFormatter(), 
					160 => new Gallop.SuccessionCharaFormatter(), 
					161 => new Gallop.SuccessionEffectedFactorFormatter(), 
					162 => new Gallop.SuccessionHistoryFormatter(), 
					163 => new Gallop.TeamStadiumOpponentFormatter(), 
					164 => new Gallop.TeamStadiumOpponentListResponseFormatter(), 
					165 => new Gallop.TeamStadiumTeamDataFormatter(), 
					166 => new Gallop.TeamStadiumUserFormatter(), 
					167 => new Gallop.TrainedCharaFormatter(), 
					168 => new Gallop.TrainedCharaFavoriteFormatter(), 
					169 => new Gallop.TrainedCharaLoadResponseFormatter(), 
					170 => new Gallop.TrainedCharaRaceResultFormatter(), 
					171 => new Gallop.TrainedCharaSupportCardListFormatter(), 
					172 => new Gallop.TrainingLevelInfoFormatter(), 
					173 => new Gallop.TrophyNumInfoFormatter(), 
					174 => new Gallop.UserFriendFormatter(), 
					175 => new Gallop.UserInfoAtFriendFormatter(), 
					176 => new Gallop.UserSupportCardFormatter(), 
					177 => new Gallop.UserSupportCardAtFriendFormatter(), 
					178 => new Gallop.UserTrainedCharaAtFriendFormatter(), 
					_ => null, 
				};
			}
			return null;
		}
	}

	internal class Gallop
	{
		internal class ChampionsFinalRaceStartResponse
		{
			internal sealed class CommonResponseFormatter : IMessagePackFormatter<global::Gallop.ChampionsFinalRaceStartResponse.CommonResponse>, IMessagePackFormatter
			{
				private static ReadOnlySpan<byte> GetSpan_room_info()
				{
					return new byte[10] { 169, 114, 111, 111, 109, 95, 105, 110, 102, 111 };
				}

				private static ReadOnlySpan<byte> GetSpan_room_user_array()
				{
					return new byte[16]
					{
						175, 114, 111, 111, 109, 95, 117, 115, 101, 114,
						95, 97, 114, 114, 97, 121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_race_horse_data_array()
				{
					return new byte[22]
					{
						181, 114, 97, 99, 101, 95, 104, 111, 114, 115,
						101, 95, 100, 97, 116, 97, 95, 97, 114, 114,
						97, 121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_trained_chara_array()
				{
					return new byte[20]
					{
						179, 116, 114, 97, 105, 110, 101, 100, 95, 99,
						104, 97, 114, 97, 95, 97, 114, 114, 97, 121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_state()
				{
					return new byte[6] { 165, 115, 116, 97, 116, 101 };
				}

				public void Serialize(ref MessagePackWriter writer, global::Gallop.ChampionsFinalRaceStartResponse.CommonResponse value, MessagePackSerializerOptions options)
				{
					if (value == null)
					{
						writer.WriteNil();
						return;
					}
					IFormatterResolver resolver = options.Resolver;
					writer.WriteMapHeader(5);
					writer.WriteRaw(GetSpan_room_info());
					resolver.GetFormatterWithVerify<ChampionsRoomInfo>().Serialize(ref writer, value.room_info, options);
					writer.WriteRaw(GetSpan_room_user_array());
					resolver.GetFormatterWithVerify<ChampionsRoomUser[]>().Serialize(ref writer, value.room_user_array, options);
					writer.WriteRaw(GetSpan_race_horse_data_array());
					resolver.GetFormatterWithVerify<RaceHorseData[]>().Serialize(ref writer, value.race_horse_data_array, options);
					writer.WriteRaw(GetSpan_trained_chara_array());
					resolver.GetFormatterWithVerify<TrainedChara[]>().Serialize(ref writer, value.trained_chara_array, options);
					writer.WriteRaw(GetSpan_state());
					writer.Write(value.state);
				}

				public global::Gallop.ChampionsFinalRaceStartResponse.CommonResponse Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
				{
					if (reader.TryReadNil())
					{
						return null;
					}
					options.Security.DepthStep(ref reader);
					IFormatterResolver resolver = options.Resolver;
					int num = reader.ReadMapHeader();
					global::Gallop.ChampionsFinalRaceStartResponse.CommonResponse commonResponse = new global::Gallop.ChampionsFinalRaceStartResponse.CommonResponse();
					for (int i = 0; i < num; i++)
					{
						ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
						int length = span.Length;
						if (length <= 9)
						{
							if (length != 5)
							{
								if (length == 9 && span.SequenceEqual(GetSpan_room_info().Slice(1)))
								{
									commonResponse.room_info = resolver.GetFormatterWithVerify<ChampionsRoomInfo>().Deserialize(ref reader, options);
									continue;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 435744240755L)
							{
								commonResponse.state = reader.ReadInt32();
								continue;
							}
						}
						else if (length != 15)
						{
							if (length != 19)
							{
								if (length == 21 && span.SequenceEqual(GetSpan_race_horse_data_array().Slice(1)))
								{
									commonResponse.race_horse_data_array = resolver.GetFormatterWithVerify<RaceHorseData[]>().Deserialize(ref reader, options);
									continue;
								}
							}
							else if (span.SequenceEqual(GetSpan_trained_chara_array().Slice(1)))
							{
								commonResponse.trained_chara_array = resolver.GetFormatterWithVerify<TrainedChara[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_room_user_array().Slice(1)))
						{
							commonResponse.room_user_array = resolver.GetFormatterWithVerify<ChampionsRoomUser[]>().Deserialize(ref reader, options);
							continue;
						}
						reader.Skip();
					}
					reader.Depth--;
					return commonResponse;
				}
			}
		}

		internal class FriendSearchResponse
		{
			internal sealed class CommonResponseFormatter : IMessagePackFormatter<global::Gallop.FriendSearchResponse.CommonResponse>, IMessagePackFormatter
			{
				private static ReadOnlySpan<byte> GetSpan_friend_info()
				{
					return new byte[12]
					{
						171, 102, 114, 105, 101, 110, 100, 95, 105, 110,
						102, 111
					};
				}

				private static ReadOnlySpan<byte> GetSpan_user_info_summary()
				{
					return new byte[18]
					{
						177, 117, 115, 101, 114, 95, 105, 110, 102, 111,
						95, 115, 117, 109, 109, 97, 114, 121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_practice_partner_info()
				{
					return new byte[22]
					{
						181, 112, 114, 97, 99, 116, 105, 99, 101, 95,
						112, 97, 114, 116, 110, 101, 114, 95, 105, 110,
						102, 111
					};
				}

				private static ReadOnlySpan<byte> GetSpan_partner_chara_info_array()
				{
					return new byte[25]
					{
						184, 112, 97, 114, 116, 110, 101, 114, 95, 99,
						104, 97, 114, 97, 95, 105, 110, 102, 111, 95,
						97, 114, 114, 97, 121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_directory_chara_info()
				{
					return new byte[21]
					{
						180, 100, 105, 114, 101, 99, 116, 111, 114, 121,
						95, 99, 104, 97, 114, 97, 95, 105, 110, 102,
						111
					};
				}

				private static ReadOnlySpan<byte> GetSpan_directory_card_array()
				{
					return new byte[21]
					{
						180, 100, 105, 114, 101, 99, 116, 111, 114, 121,
						95, 99, 97, 114, 100, 95, 97, 114, 114, 97,
						121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_support_card_data()
				{
					return new byte[18]
					{
						177, 115, 117, 112, 112, 111, 114, 116, 95, 99,
						97, 114, 100, 95, 100, 97, 116, 97
					};
				}

				private static ReadOnlySpan<byte> GetSpan_support_card_data_array()
				{
					return new byte[24]
					{
						183, 115, 117, 112, 112, 111, 114, 116, 95, 99,
						97, 114, 100, 95, 100, 97, 116, 97, 95, 97,
						114, 114, 97, 121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_trophy_num_info()
				{
					return new byte[16]
					{
						175, 116, 114, 111, 112, 104, 121, 95, 110, 117,
						109, 95, 105, 110, 102, 111
					};
				}

				private static ReadOnlySpan<byte> GetSpan_release_num_info()
				{
					return new byte[17]
					{
						176, 114, 101, 108, 101, 97, 115, 101, 95, 110,
						117, 109, 95, 105, 110, 102, 111
					};
				}

				private static ReadOnlySpan<byte> GetSpan_team_stadium_user()
				{
					return new byte[18]
					{
						177, 116, 101, 97, 109, 95, 115, 116, 97, 100,
						105, 117, 109, 95, 117, 115, 101, 114
					};
				}

				private static ReadOnlySpan<byte> GetSpan_follower_num()
				{
					return new byte[13]
					{
						172, 102, 111, 108, 108, 111, 119, 101, 114, 95,
						110, 117, 109
					};
				}

				private static ReadOnlySpan<byte> GetSpan_own_follow_num()
				{
					return new byte[15]
					{
						174, 111, 119, 110, 95, 102, 111, 108, 108, 111,
						119, 95, 110, 117, 109
					};
				}

				private static ReadOnlySpan<byte> GetSpan_enable_circle_scout()
				{
					return new byte[20]
					{
						179, 101, 110, 97, 98, 108, 101, 95, 99, 105,
						114, 99, 108, 101, 95, 115, 99, 111, 117, 116
					};
				}

				public void Serialize(ref MessagePackWriter writer, global::Gallop.FriendSearchResponse.CommonResponse value, MessagePackSerializerOptions options)
				{
					if (value == null)
					{
						writer.WriteNil();
						return;
					}
					IFormatterResolver resolver = options.Resolver;
					writer.WriteMapHeader(14);
					writer.WriteRaw(GetSpan_friend_info());
					resolver.GetFormatterWithVerify<UserFriend>().Serialize(ref writer, value.friend_info, options);
					writer.WriteRaw(GetSpan_user_info_summary());
					resolver.GetFormatterWithVerify<UserInfoAtFriend>().Serialize(ref writer, value.user_info_summary, options);
					writer.WriteRaw(GetSpan_practice_partner_info());
					resolver.GetFormatterWithVerify<TrainedChara>().Serialize(ref writer, value.practice_partner_info, options);
					writer.WriteRaw(GetSpan_partner_chara_info_array());
					resolver.GetFormatterWithVerify<TrainedChara[]>().Serialize(ref writer, value.partner_chara_info_array, options);
					writer.WriteRaw(GetSpan_directory_chara_info());
					resolver.GetFormatterWithVerify<TrainedChara[]>().Serialize(ref writer, value.directory_chara_info, options);
					writer.WriteRaw(GetSpan_directory_card_array());
					resolver.GetFormatterWithVerify<DirectoryCard[]>().Serialize(ref writer, value.directory_card_array, options);
					writer.WriteRaw(GetSpan_support_card_data());
					resolver.GetFormatterWithVerify<UserSupportCard>().Serialize(ref writer, value.support_card_data, options);
					writer.WriteRaw(GetSpan_support_card_data_array());
					resolver.GetFormatterWithVerify<UserSupportCard[]>().Serialize(ref writer, value.support_card_data_array, options);
					writer.WriteRaw(GetSpan_trophy_num_info());
					resolver.GetFormatterWithVerify<TrophyNumInfo>().Serialize(ref writer, value.trophy_num_info, options);
					writer.WriteRaw(GetSpan_release_num_info());
					resolver.GetFormatterWithVerify<ReleaseNumInfo>().Serialize(ref writer, value.release_num_info, options);
					writer.WriteRaw(GetSpan_team_stadium_user());
					resolver.GetFormatterWithVerify<TeamStadiumUser>().Serialize(ref writer, value.team_stadium_user, options);
					writer.WriteRaw(GetSpan_follower_num());
					writer.Write(value.follower_num);
					writer.WriteRaw(GetSpan_own_follow_num());
					writer.Write(value.own_follow_num);
					writer.WriteRaw(GetSpan_enable_circle_scout());
					writer.Write(value.enable_circle_scout);
				}

				public global::Gallop.FriendSearchResponse.CommonResponse Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
				{
					if (reader.TryReadNil())
					{
						return null;
					}
					options.Security.DepthStep(ref reader);
					IFormatterResolver resolver = options.Resolver;
					int num = reader.ReadMapHeader();
					global::Gallop.FriendSearchResponse.CommonResponse commonResponse = new global::Gallop.FriendSearchResponse.CommonResponse();
					for (int i = 0; i < num; i++)
					{
						ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
						switch (span.Length)
						{
						default:
							reader.Skip();
							break;
						case 11:
							if (span.SequenceEqual(GetSpan_friend_info().Slice(1)))
							{
								commonResponse.friend_info = resolver.GetFormatterWithVerify<UserFriend>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						case 17:
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 6878248353854944627L)
							{
								if (key != 7022364572671632756L)
								{
									if (key == 7380952697968882549L && span.SequenceEqual(GetSpan_user_info_summary().Slice(9)))
									{
										commonResponse.user_info_summary = resolver.GetFormatterWithVerify<UserInfoAtFriend>().Deserialize(ref reader, options);
										break;
									}
								}
								else if (span.SequenceEqual(GetSpan_team_stadium_user().Slice(9)))
								{
									commonResponse.team_stadium_user = resolver.GetFormatterWithVerify<TeamStadiumUser>().Deserialize(ref reader, options);
									break;
								}
							}
							else if (span.SequenceEqual(GetSpan_support_card_data().Slice(9)))
							{
								commonResponse.support_card_data = resolver.GetFormatterWithVerify<UserSupportCard>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						}
						case 21:
							if (span.SequenceEqual(GetSpan_practice_partner_info().Slice(1)))
							{
								commonResponse.practice_partner_info = resolver.GetFormatterWithVerify<TrainedChara>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						case 24:
							if (span.SequenceEqual(GetSpan_partner_chara_info_array().Slice(1)))
							{
								commonResponse.partner_chara_info_array = resolver.GetFormatterWithVerify<TrainedChara[]>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						case 20:
							if (AutomataKeyGen.GetKey(ref span) == 8245937412991248740L)
							{
								ulong key = AutomataKeyGen.GetKey(ref span);
								if (key != 6872900269032824697L)
								{
									if (key == 7016437186889473913L && AutomataKeyGen.GetKey(ref span) == 2036429426)
									{
										commonResponse.directory_card_array = resolver.GetFormatterWithVerify<DirectoryCard[]>().Deserialize(ref reader, options);
										break;
									}
								}
								else if (AutomataKeyGen.GetKey(ref span) == 1868983913)
								{
									commonResponse.directory_chara_info = resolver.GetFormatterWithVerify<TrainedChara[]>().Deserialize(ref reader, options);
									break;
								}
							}
							goto default;
						case 23:
							if (span.SequenceEqual(GetSpan_support_card_data_array().Slice(1)))
							{
								commonResponse.support_card_data_array = resolver.GetFormatterWithVerify<UserSupportCard[]>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						case 15:
							if (span.SequenceEqual(GetSpan_trophy_num_info().Slice(1)))
							{
								commonResponse.trophy_num_info = resolver.GetFormatterWithVerify<TrophyNumInfo>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						case 16:
							if (span.SequenceEqual(GetSpan_release_num_info().Slice(1)))
							{
								commonResponse.release_num_info = resolver.GetFormatterWithVerify<ReleaseNumInfo>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						case 12:
							if (span.SequenceEqual(GetSpan_follower_num().Slice(1)))
							{
								commonResponse.follower_num = reader.ReadInt32();
								break;
							}
							goto default;
						case 14:
							if (span.SequenceEqual(GetSpan_own_follow_num().Slice(1)))
							{
								commonResponse.own_follow_num = reader.ReadInt32();
								break;
							}
							goto default;
						case 19:
							if (span.SequenceEqual(GetSpan_enable_circle_scout().Slice(1)))
							{
								commonResponse.enable_circle_scout = reader.ReadInt32();
								break;
							}
							goto default;
						}
					}
					reader.Depth--;
					return commonResponse;
				}
			}
		}

		internal class PracticeRaceRaceStartResponse
		{
			internal sealed class CommonResponseFormatter : IMessagePackFormatter<global::Gallop.PracticeRaceRaceStartResponse.CommonResponse>, IMessagePackFormatter
			{
				private static ReadOnlySpan<byte> GetSpan_trained_chara_array()
				{
					return new byte[20]
					{
						179, 116, 114, 97, 105, 110, 101, 100, 95, 99,
						104, 97, 114, 97, 95, 97, 114, 114, 97, 121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_race_result_info()
				{
					return new byte[17]
					{
						176, 114, 97, 99, 101, 95, 114, 101, 115, 117,
						108, 116, 95, 105, 110, 102, 111
					};
				}

				private static ReadOnlySpan<byte> GetSpan_entry_info_array()
				{
					return new byte[17]
					{
						176, 101, 110, 116, 114, 121, 95, 105, 110, 102,
						111, 95, 97, 114, 114, 97, 121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_practice_race_id()
				{
					return new byte[17]
					{
						176, 112, 114, 97, 99, 116, 105, 99, 101, 95,
						114, 97, 99, 101, 95, 105, 100
					};
				}

				private static ReadOnlySpan<byte> GetSpan_state()
				{
					return new byte[6] { 165, 115, 116, 97, 116, 101 };
				}

				private static ReadOnlySpan<byte> GetSpan_practice_partner_owner_info_array()
				{
					return new byte[35]
					{
						217, 33, 112, 114, 97, 99, 116, 105, 99, 101,
						95, 112, 97, 114, 116, 110, 101, 114, 95, 111,
						119, 110, 101, 114, 95, 105, 110, 102, 111, 95,
						97, 114, 114, 97, 121
					};
				}

				public void Serialize(ref MessagePackWriter writer, global::Gallop.PracticeRaceRaceStartResponse.CommonResponse value, MessagePackSerializerOptions options)
				{
					if (value == null)
					{
						writer.WriteNil();
						return;
					}
					IFormatterResolver resolver = options.Resolver;
					writer.WriteMapHeader(6);
					writer.WriteRaw(GetSpan_trained_chara_array());
					resolver.GetFormatterWithVerify<TrainedChara[]>().Serialize(ref writer, value.trained_chara_array, options);
					writer.WriteRaw(GetSpan_race_result_info());
					resolver.GetFormatterWithVerify<RaceResultInfo>().Serialize(ref writer, value.race_result_info, options);
					writer.WriteRaw(GetSpan_entry_info_array());
					resolver.GetFormatterWithVerify<PracticeRaceEntryInfo[]>().Serialize(ref writer, value.entry_info_array, options);
					writer.WriteRaw(GetSpan_practice_race_id());
					writer.Write(value.practice_race_id);
					writer.WriteRaw(GetSpan_state());
					writer.Write(value.state);
					writer.WriteRaw(GetSpan_practice_partner_owner_info_array());
					resolver.GetFormatterWithVerify<PracticePartnerOwnerInfo[]>().Serialize(ref writer, value.practice_partner_owner_info_array, options);
				}

				public global::Gallop.PracticeRaceRaceStartResponse.CommonResponse Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
				{
					if (reader.TryReadNil())
					{
						return null;
					}
					options.Security.DepthStep(ref reader);
					IFormatterResolver resolver = options.Resolver;
					int num = reader.ReadMapHeader();
					global::Gallop.PracticeRaceRaceStartResponse.CommonResponse commonResponse = new global::Gallop.PracticeRaceRaceStartResponse.CommonResponse();
					for (int i = 0; i < num; i++)
					{
						ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
						int length = span.Length;
						if (length <= 16)
						{
							if (length != 5)
							{
								if (length == 16)
								{
									ulong key = AutomataKeyGen.GetKey(ref span);
									if (key != 7305798969129529968L)
									{
										if (key != 7955995191942606437L)
										{
											if (key == 8315178041057960306L && AutomataKeyGen.GetKey(ref span) == 8027224784686574709L)
											{
												commonResponse.race_result_info = resolver.GetFormatterWithVerify<RaceResultInfo>().Deserialize(ref reader, options);
												continue;
											}
										}
										else if (AutomataKeyGen.GetKey(ref span) == 8746397786915696486L)
										{
											commonResponse.entry_info_array = resolver.GetFormatterWithVerify<PracticeRaceEntryInfo[]>().Deserialize(ref reader, options);
											continue;
										}
									}
									else if (AutomataKeyGen.GetKey(ref span) == 7235419165411078751L)
									{
										commonResponse.practice_race_id = reader.ReadInt32();
										continue;
									}
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 435744240755L)
							{
								commonResponse.state = reader.ReadInt32();
								continue;
							}
						}
						else if (length != 19)
						{
							if (length == 33 && span.SequenceEqual(GetSpan_practice_partner_owner_info_array().Slice(2)))
							{
								commonResponse.practice_partner_owner_info_array = resolver.GetFormatterWithVerify<PracticePartnerOwnerInfo[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_trained_chara_array().Slice(1)))
						{
							commonResponse.trained_chara_array = resolver.GetFormatterWithVerify<TrainedChara[]>().Deserialize(ref reader, options);
							continue;
						}
						reader.Skip();
					}
					reader.Depth--;
					return commonResponse;
				}
			}
		}

		internal class RoomMatchRaceStartResponse
		{
			internal sealed class CommonResponseFormatter : IMessagePackFormatter<global::Gallop.RoomMatchRaceStartResponse.CommonResponse>, IMessagePackFormatter
			{
				private static ReadOnlySpan<byte> GetSpan_race_scenario()
				{
					return new byte[14]
					{
						173, 114, 97, 99, 101, 95, 115, 99, 101, 110,
						97, 114, 105, 111
					};
				}

				private static ReadOnlySpan<byte> GetSpan_random_seed()
				{
					return new byte[12]
					{
						171, 114, 97, 110, 100, 111, 109, 95, 115, 101,
						101, 100
					};
				}

				private static ReadOnlySpan<byte> GetSpan_race_horse_data_array()
				{
					return new byte[22]
					{
						181, 114, 97, 99, 101, 95, 104, 111, 114, 115,
						101, 95, 100, 97, 116, 97, 95, 97, 114, 114,
						97, 121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_trained_chara_array()
				{
					return new byte[20]
					{
						179, 116, 114, 97, 105, 110, 101, 100, 95, 99,
						104, 97, 114, 97, 95, 97, 114, 114, 97, 121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_season()
				{
					return new byte[7] { 166, 115, 101, 97, 115, 111, 110 };
				}

				private static ReadOnlySpan<byte> GetSpan_weather()
				{
					return new byte[8] { 167, 119, 101, 97, 116, 104, 101, 114 };
				}

				private static ReadOnlySpan<byte> GetSpan_ground_condition()
				{
					return new byte[17]
					{
						176, 103, 114, 111, 117, 110, 100, 95, 99, 111,
						110, 100, 105, 116, 105, 111, 110
					};
				}

				public void Serialize(ref MessagePackWriter writer, global::Gallop.RoomMatchRaceStartResponse.CommonResponse value, MessagePackSerializerOptions options)
				{
					if (value == null)
					{
						writer.WriteNil();
						return;
					}
					IFormatterResolver resolver = options.Resolver;
					writer.WriteMapHeader(7);
					writer.WriteRaw(GetSpan_race_scenario());
					resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.race_scenario, options);
					writer.WriteRaw(GetSpan_random_seed());
					writer.Write(value.random_seed);
					writer.WriteRaw(GetSpan_race_horse_data_array());
					resolver.GetFormatterWithVerify<RaceHorseData[]>().Serialize(ref writer, value.race_horse_data_array, options);
					writer.WriteRaw(GetSpan_trained_chara_array());
					resolver.GetFormatterWithVerify<TrainedChara[]>().Serialize(ref writer, value.trained_chara_array, options);
					writer.WriteRaw(GetSpan_season());
					writer.Write(value.season);
					writer.WriteRaw(GetSpan_weather());
					writer.Write(value.weather);
					writer.WriteRaw(GetSpan_ground_condition());
					writer.Write(value.ground_condition);
				}

				public global::Gallop.RoomMatchRaceStartResponse.CommonResponse Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
				{
					if (reader.TryReadNil())
					{
						return null;
					}
					options.Security.DepthStep(ref reader);
					IFormatterResolver resolver = options.Resolver;
					int num = reader.ReadMapHeader();
					global::Gallop.RoomMatchRaceStartResponse.CommonResponse commonResponse = new global::Gallop.RoomMatchRaceStartResponse.CommonResponse();
					for (int i = 0; i < num; i++)
					{
						ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
						int length = span.Length;
						if (length <= 11)
						{
							if (length != 6)
							{
								if (length != 7)
								{
									if (length == 11 && span.SequenceEqual(GetSpan_random_seed().Slice(1)))
									{
										commonResponse.random_seed = reader.ReadInt32();
										continue;
									}
								}
								else if (AutomataKeyGen.GetKey(ref span) == 32199646648558967L)
								{
									commonResponse.weather = reader.ReadInt32();
									continue;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 121424956188019L)
							{
								commonResponse.season = reader.ReadInt32();
								continue;
							}
						}
						else if (length <= 16)
						{
							if (length != 13)
							{
								if (length == 16 && span.SequenceEqual(GetSpan_ground_condition().Slice(1)))
								{
									commonResponse.ground_condition = reader.ReadInt32();
									continue;
								}
							}
							else if (span.SequenceEqual(GetSpan_race_scenario().Slice(1)))
							{
								commonResponse.race_scenario = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (length != 19)
						{
							if (length == 21 && span.SequenceEqual(GetSpan_race_horse_data_array().Slice(1)))
							{
								commonResponse.race_horse_data_array = resolver.GetFormatterWithVerify<RaceHorseData[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_trained_chara_array().Slice(1)))
						{
							commonResponse.trained_chara_array = resolver.GetFormatterWithVerify<TrainedChara[]>().Deserialize(ref reader, options);
							continue;
						}
						reader.Skip();
					}
					reader.Depth--;
					return commonResponse;
				}
			}
		}

		internal class SingleModeSportCommandInfo
		{
			internal sealed class SingleModeSportGainRankFormatter : IMessagePackFormatter<global::Gallop.SingleModeSportCommandInfo.SingleModeSportGainRank>, IMessagePackFormatter
			{
				private static ReadOnlySpan<byte> GetSpan_command_id()
				{
					return new byte[11]
					{
						170, 99, 111, 109, 109, 97, 110, 100, 95, 105,
						100
					};
				}

				private static ReadOnlySpan<byte> GetSpan_gain_rank()
				{
					return new byte[10] { 169, 103, 97, 105, 110, 95, 114, 97, 110, 107 };
				}

				public void Serialize(ref MessagePackWriter writer, global::Gallop.SingleModeSportCommandInfo.SingleModeSportGainRank value, MessagePackSerializerOptions options)
				{
					if (value == null)
					{
						writer.WriteNil();
						return;
					}
					writer.WriteMapHeader(2);
					writer.WriteRaw(GetSpan_command_id());
					writer.Write(value.command_id);
					writer.WriteRaw(GetSpan_gain_rank());
					writer.Write(value.gain_rank);
				}

				public global::Gallop.SingleModeSportCommandInfo.SingleModeSportGainRank Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
				{
					if (reader.TryReadNil())
					{
						return null;
					}
					options.Security.DepthStep(ref reader);
					int num = reader.ReadMapHeader();
					global::Gallop.SingleModeSportCommandInfo.SingleModeSportGainRank singleModeSportGainRank = new global::Gallop.SingleModeSportCommandInfo.SingleModeSportGainRank();
					for (int i = 0; i < num; i++)
					{
						ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
						int length = span.Length;
						if (length != 9)
						{
							if (length == 10 && span.SequenceEqual(GetSpan_command_id().Slice(1)))
							{
								singleModeSportGainRank.command_id = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_gain_rank().Slice(1)))
						{
							singleModeSportGainRank.gain_rank = reader.ReadInt32();
							continue;
						}
						reader.Skip();
					}
					reader.Depth--;
					return singleModeSportGainRank;
				}
			}
		}

		internal class TeamStadiumOpponentListResponse
		{
			internal sealed class CommonResponseFormatter : IMessagePackFormatter<global::Gallop.TeamStadiumOpponentListResponse.CommonResponse>, IMessagePackFormatter
			{
				private static ReadOnlySpan<byte> GetSpan_opponent_info_array()
				{
					return new byte[20]
					{
						179, 111, 112, 112, 111, 110, 101, 110, 116, 95,
						105, 110, 102, 111, 95, 97, 114, 114, 97, 121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_opponent_info_copy()
				{
					return new byte[19]
					{
						178, 111, 112, 112, 111, 110, 101, 110, 116, 95,
						105, 110, 102, 111, 95, 99, 111, 112, 121
					};
				}

				public void Serialize(ref MessagePackWriter writer, global::Gallop.TeamStadiumOpponentListResponse.CommonResponse value, MessagePackSerializerOptions options)
				{
					if (value == null)
					{
						writer.WriteNil();
						return;
					}
					IFormatterResolver resolver = options.Resolver;
					writer.WriteMapHeader(2);
					writer.WriteRaw(GetSpan_opponent_info_array());
					resolver.GetFormatterWithVerify<TeamStadiumOpponent[]>().Serialize(ref writer, value.opponent_info_array, options);
					writer.WriteRaw(GetSpan_opponent_info_copy());
					resolver.GetFormatterWithVerify<TeamStadiumOpponent>().Serialize(ref writer, value.opponent_info_copy, options);
				}

				public global::Gallop.TeamStadiumOpponentListResponse.CommonResponse Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
				{
					if (reader.TryReadNil())
					{
						return null;
					}
					options.Security.DepthStep(ref reader);
					IFormatterResolver resolver = options.Resolver;
					int num = reader.ReadMapHeader();
					global::Gallop.TeamStadiumOpponentListResponse.CommonResponse commonResponse = new global::Gallop.TeamStadiumOpponentListResponse.CommonResponse();
					for (int i = 0; i < num; i++)
					{
						ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
						int length = span.Length;
						if (length != 18)
						{
							if (length == 19 && span.SequenceEqual(GetSpan_opponent_info_array().Slice(1)))
							{
								commonResponse.opponent_info_array = resolver.GetFormatterWithVerify<TeamStadiumOpponent[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_opponent_info_copy().Slice(1)))
						{
							commonResponse.opponent_info_copy = resolver.GetFormatterWithVerify<TeamStadiumOpponent>().Deserialize(ref reader, options);
							continue;
						}
						reader.Skip();
					}
					reader.Depth--;
					return commonResponse;
				}
			}
		}

		internal class TrainedCharaLoadResponse
		{
			internal sealed class CommonResponseFormatter : IMessagePackFormatter<global::Gallop.TrainedCharaLoadResponse.CommonResponse>, IMessagePackFormatter
			{
				private static ReadOnlySpan<byte> GetSpan_trained_chara_array()
				{
					return new byte[20]
					{
						179, 116, 114, 97, 105, 110, 101, 100, 95, 99,
						104, 97, 114, 97, 95, 97, 114, 114, 97, 121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_trained_chara_favorite_array()
				{
					return new byte[29]
					{
						188, 116, 114, 97, 105, 110, 101, 100, 95, 99,
						104, 97, 114, 97, 95, 102, 97, 118, 111, 114,
						105, 116, 101, 95, 97, 114, 114, 97, 121
					};
				}

				private static ReadOnlySpan<byte> GetSpan_room_match_entry_chara_id_array()
				{
					return new byte[32]
					{
						191, 114, 111, 111, 109, 95, 109, 97, 116, 99,
						104, 95, 101, 110, 116, 114, 121, 95, 99, 104,
						97, 114, 97, 95, 105, 100, 95, 97, 114, 114,
						97, 121
					};
				}

				public void Serialize(ref MessagePackWriter writer, global::Gallop.TrainedCharaLoadResponse.CommonResponse value, MessagePackSerializerOptions options)
				{
					if (value == null)
					{
						writer.WriteNil();
						return;
					}
					IFormatterResolver resolver = options.Resolver;
					writer.WriteMapHeader(3);
					writer.WriteRaw(GetSpan_trained_chara_array());
					resolver.GetFormatterWithVerify<TrainedChara[]>().Serialize(ref writer, value.trained_chara_array, options);
					writer.WriteRaw(GetSpan_trained_chara_favorite_array());
					resolver.GetFormatterWithVerify<TrainedCharaFavorite[]>().Serialize(ref writer, value.trained_chara_favorite_array, options);
					writer.WriteRaw(GetSpan_room_match_entry_chara_id_array());
					resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.room_match_entry_chara_id_array, options);
				}

				public global::Gallop.TrainedCharaLoadResponse.CommonResponse Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
				{
					if (reader.TryReadNil())
					{
						return null;
					}
					options.Security.DepthStep(ref reader);
					IFormatterResolver resolver = options.Resolver;
					int num = reader.ReadMapHeader();
					global::Gallop.TrainedCharaLoadResponse.CommonResponse commonResponse = new global::Gallop.TrainedCharaLoadResponse.CommonResponse();
					for (int i = 0; i < num; i++)
					{
						ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
						int length = span.Length;
						if (length != 19)
						{
							if (length != 28)
							{
								if (length == 31 && span.SequenceEqual(GetSpan_room_match_entry_chara_id_array().Slice(1)))
								{
									commonResponse.room_match_entry_chara_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
									continue;
								}
							}
							else if (span.SequenceEqual(GetSpan_trained_chara_favorite_array().Slice(1)))
							{
								commonResponse.trained_chara_favorite_array = resolver.GetFormatterWithVerify<TrainedCharaFavorite[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_trained_chara_array().Slice(1)))
						{
							commonResponse.trained_chara_array = resolver.GetFormatterWithVerify<TrainedChara[]>().Deserialize(ref reader, options);
							continue;
						}
						reader.Skip();
					}
					reader.Depth--;
					return commonResponse;
				}
			}
		}

		internal sealed class ArcEvaluationInfoFormatter : IMessagePackFormatter<ArcEvaluationInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_target_id()
			{
				return new byte[10] { 169, 116, 97, 114, 103, 101, 116, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			public void Serialize(ref MessagePackWriter writer, ArcEvaluationInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_target_id());
				writer.Write(value.target_id);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
			}

			public ArcEvaluationInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				ArcEvaluationInfo arcEvaluationInfo = new ArcEvaluationInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 8)
					{
						if (length == 9 && span.SequenceEqual(GetSpan_target_id().Slice(1)))
						{
							arcEvaluationInfo.target_id = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 7235419148482865251L)
					{
						arcEvaluationInfo.chara_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return arcEvaluationInfo;
			}
		}

		internal sealed class ArcPotentialFormatter : IMessagePackFormatter<ArcPotential>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_potential_id()
			{
				return new byte[13]
				{
					172, 112, 111, 116, 101, 110, 116, 105, 97, 108,
					95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_level()
			{
				return new byte[6] { 165, 108, 101, 118, 101, 108 };
			}

			private static ReadOnlySpan<byte> GetSpan_progress_array()
			{
				return new byte[15]
				{
					174, 112, 114, 111, 103, 114, 101, 115, 115, 95,
					97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, ArcPotential value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_potential_id());
				writer.Write(value.potential_id);
				writer.WriteRaw(GetSpan_level());
				writer.Write(value.level);
				writer.WriteRaw(GetSpan_progress_array());
				resolver.GetFormatterWithVerify<SingleModeArcPotentialProgress[]>().Serialize(ref writer, value.progress_array, options);
			}

			public ArcPotential Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				ArcPotential arcPotential = new ArcPotential();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 5)
					{
						if (length != 12)
						{
							if (length == 14 && span.SequenceEqual(GetSpan_progress_array().Slice(1)))
							{
								arcPotential.progress_array = resolver.GetFormatterWithVerify<SingleModeArcPotentialProgress[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_potential_id().Slice(1)))
						{
							arcPotential.potential_id = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 465558725996L)
					{
						arcPotential.level = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return arcPotential;
			}
		}

		internal sealed class ArcRivalPotentialFormatter : IMessagePackFormatter<ArcRivalPotential>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_potential_id()
			{
				return new byte[13]
				{
					172, 112, 111, 116, 101, 110, 116, 105, 97, 108,
					95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_level()
			{
				return new byte[6] { 165, 108, 101, 118, 101, 108 };
			}

			public void Serialize(ref MessagePackWriter writer, ArcRivalPotential value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_potential_id());
				writer.Write(value.potential_id);
				writer.WriteRaw(GetSpan_level());
				writer.Write(value.level);
			}

			public ArcRivalPotential Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				ArcRivalPotential arcRivalPotential = new ArcRivalPotential();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 5)
					{
						if (length == 12 && span.SequenceEqual(GetSpan_potential_id().Slice(1)))
						{
							arcRivalPotential.potential_id = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 465558725996L)
					{
						arcRivalPotential.level = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return arcRivalPotential;
			}
		}

		internal sealed class ArcSelectionPeffFormatter : IMessagePackFormatter<ArcSelectionPeff>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_effect_num()
			{
				return new byte[11]
				{
					170, 101, 102, 102, 101, 99, 116, 95, 110, 117,
					109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_effect_group_id()
			{
				return new byte[16]
				{
					175, 101, 102, 102, 101, 99, 116, 95, 103, 114,
					111, 117, 112, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_effect_value()
			{
				return new byte[13]
				{
					172, 101, 102, 102, 101, 99, 116, 95, 118, 97,
					108, 117, 101
				};
			}

			public void Serialize(ref MessagePackWriter writer, ArcSelectionPeff value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_effect_num());
				writer.Write(value.effect_num);
				writer.WriteRaw(GetSpan_effect_group_id());
				writer.Write(value.effect_group_id);
				writer.WriteRaw(GetSpan_effect_value());
				writer.Write(value.effect_value);
			}

			public ArcSelectionPeff Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				ArcSelectionPeff arcSelectionPeff = new ArcSelectionPeff();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 10)
					{
						if (length != 12)
						{
							if (length == 15 && span.SequenceEqual(GetSpan_effect_group_id().Slice(1)))
							{
								arcSelectionPeff.effect_group_id = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_effect_value().Slice(1)))
						{
							arcSelectionPeff.effect_value = reader.ReadInt32();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_effect_num().Slice(1)))
					{
						arcSelectionPeff.effect_num = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return arcSelectionPeff;
			}
		}

		internal sealed class ChampionsFinalRaceStartResponseFormatter : IMessagePackFormatter<global::Gallop.ChampionsFinalRaceStartResponse>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_data()
			{
				return new byte[5] { 164, 100, 97, 116, 97 };
			}

			public void Serialize(ref MessagePackWriter writer, global::Gallop.ChampionsFinalRaceStartResponse value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(1);
				writer.WriteRaw(GetSpan_data());
				resolver.GetFormatterWithVerify<global::Gallop.ChampionsFinalRaceStartResponse.CommonResponse>().Serialize(ref writer, value.data, options);
			}

			public global::Gallop.ChampionsFinalRaceStartResponse Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				global::Gallop.ChampionsFinalRaceStartResponse championsFinalRaceStartResponse = new global::Gallop.ChampionsFinalRaceStartResponse();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					if (span.Length != 4 || AutomataKeyGen.GetKey(ref span) != 1635017060)
					{
						reader.Skip();
					}
					else
					{
						championsFinalRaceStartResponse.data = resolver.GetFormatterWithVerify<global::Gallop.ChampionsFinalRaceStartResponse.CommonResponse>().Deserialize(ref reader, options);
					}
				}
				reader.Depth--;
				return championsFinalRaceStartResponse;
			}
		}

		internal sealed class ChampionsRoomInfoFormatter : IMessagePackFormatter<ChampionsRoomInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_room_id()
			{
				return new byte[8] { 167, 114, 111, 111, 109, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_user_entry_num()
			{
				return new byte[15]
				{
					174, 117, 115, 101, 114, 95, 101, 110, 116, 114,
					121, 95, 110, 117, 109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_start_time()
			{
				return new byte[16]
				{
					175, 114, 97, 99, 101, 95, 115, 116, 97, 114,
					116, 95, 116, 105, 109, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_instance_id()
			{
				return new byte[17]
				{
					176, 114, 97, 99, 101, 95, 105, 110, 115, 116,
					97, 110, 99, 101, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_season()
			{
				return new byte[7] { 166, 115, 101, 97, 115, 111, 110 };
			}

			private static ReadOnlySpan<byte> GetSpan_weather()
			{
				return new byte[8] { 167, 119, 101, 97, 116, 104, 101, 114 };
			}

			private static ReadOnlySpan<byte> GetSpan_ground_condition()
			{
				return new byte[17]
				{
					176, 103, 114, 111, 117, 110, 100, 95, 99, 111,
					110, 100, 105, 116, 105, 111, 110
				};
			}

			private static ReadOnlySpan<byte> GetSpan_random_seed()
			{
				return new byte[12]
				{
					171, 114, 97, 110, 100, 111, 109, 95, 115, 101,
					101, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_scenario()
			{
				return new byte[14]
				{
					173, 114, 97, 99, 101, 95, 115, 99, 101, 110,
					97, 114, 105, 111
				};
			}

			public void Serialize(ref MessagePackWriter writer, ChampionsRoomInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(9);
				writer.WriteRaw(GetSpan_room_id());
				writer.Write(value.room_id);
				writer.WriteRaw(GetSpan_user_entry_num());
				writer.Write(value.user_entry_num);
				writer.WriteRaw(GetSpan_race_start_time());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.race_start_time, options);
				writer.WriteRaw(GetSpan_race_instance_id());
				writer.Write(value.race_instance_id);
				writer.WriteRaw(GetSpan_season());
				writer.Write(value.season);
				writer.WriteRaw(GetSpan_weather());
				writer.Write(value.weather);
				writer.WriteRaw(GetSpan_ground_condition());
				writer.Write(value.ground_condition);
				writer.WriteRaw(GetSpan_random_seed());
				writer.Write(value.random_seed);
				writer.WriteRaw(GetSpan_race_scenario());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.race_scenario, options);
			}

			public ChampionsRoomInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				ChampionsRoomInfo championsRoomInfo = new ChampionsRoomInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 7:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 28263356249894770uL:
							championsRoomInfo.room_id = reader.ReadInt64();
							goto end_IL_0046;
						case 32199646648558967uL:
							championsRoomInfo.weather = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 14:
						if (span.SequenceEqual(GetSpan_user_entry_num().Slice(1)))
						{
							championsRoomInfo.user_entry_num = reader.ReadInt32();
							break;
						}
						goto default;
					case 15:
						if (span.SequenceEqual(GetSpan_race_start_time().Slice(1)))
						{
							championsRoomInfo.race_start_time = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 16:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7160552358121796199L)
						{
							if (key == 8317701420243706226L && AutomataKeyGen.GetKey(ref span) == 7235419165411926388L)
							{
								championsRoomInfo.race_instance_id = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 7957695015292268143L)
						{
							championsRoomInfo.ground_condition = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 6:
						if (AutomataKeyGen.GetKey(ref span) == 121424956188019L)
						{
							championsRoomInfo.season = reader.ReadInt32();
							break;
						}
						goto default;
					case 11:
						if (span.SequenceEqual(GetSpan_random_seed().Slice(1)))
						{
							championsRoomInfo.random_seed = reader.ReadInt32();
							break;
						}
						goto default;
					case 13:
						{
							if (span.SequenceEqual(GetSpan_race_scenario().Slice(1)))
							{
								championsRoomInfo.race_scenario = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						}
						end_IL_0046:
						break;
					}
				}
				reader.Depth--;
				return championsRoomInfo;
			}
		}

		internal sealed class ChampionsRoomUserFormatter : IMessagePackFormatter<ChampionsRoomUser>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_room_id()
			{
				return new byte[8] { 167, 114, 111, 111, 109, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_viewer_id()
			{
				return new byte[10] { 169, 118, 105, 101, 119, 101, 114, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_name()
			{
				return new byte[5] { 164, 110, 97, 109, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_honor_id()
			{
				return new byte[9] { 168, 104, 111, 110, 111, 114, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_team_id()
			{
				return new byte[8] { 167, 116, 101, 97, 109, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_entry_chara_array()
			{
				return new byte[18]
				{
					177, 101, 110, 116, 114, 121, 95, 99, 104, 97,
					114, 97, 95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, ChampionsRoomUser value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(6);
				writer.WriteRaw(GetSpan_room_id());
				writer.Write(value.room_id);
				writer.WriteRaw(GetSpan_viewer_id());
				writer.Write(value.viewer_id);
				writer.WriteRaw(GetSpan_name());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.name, options);
				writer.WriteRaw(GetSpan_honor_id());
				writer.Write(value.honor_id);
				writer.WriteRaw(GetSpan_team_id());
				writer.Write(value.team_id);
				writer.WriteRaw(GetSpan_entry_chara_array());
				resolver.GetFormatterWithVerify<ChampionsUserChara[]>().Serialize(ref writer, value.entry_chara_array, options);
			}

			public ChampionsRoomUser Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				ChampionsRoomUser championsRoomUser = new ChampionsRoomUser();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 7:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 28263356249894770uL:
							championsRoomUser.room_id = reader.ReadInt64();
							goto end_IL_0046;
						case 28263356248974708uL:
							championsRoomUser.team_id = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 9:
						if (span.SequenceEqual(GetSpan_viewer_id().Slice(1)))
						{
							championsRoomUser.viewer_id = reader.ReadInt64();
							break;
						}
						goto default;
					case 4:
						if (AutomataKeyGen.GetKey(ref span) == 1701667182)
						{
							championsRoomUser.name = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 7235419221447831400L)
						{
							championsRoomUser.honor_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 17:
						{
							if (span.SequenceEqual(GetSpan_entry_chara_array().Slice(1)))
							{
								championsRoomUser.entry_chara_array = resolver.GetFormatterWithVerify<ChampionsUserChara[]>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						}
						end_IL_0046:
						break;
					}
				}
				reader.Depth--;
				return championsRoomUser;
			}
		}

		internal sealed class ChampionsUserCharaFormatter : IMessagePackFormatter<ChampionsUserChara>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_race_cloth_id()
			{
				return new byte[14]
				{
					173, 114, 97, 99, 101, 95, 99, 108, 111, 116,
					104, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_nick_name_id()
			{
				return new byte[13]
				{
					172, 110, 105, 99, 107, 95, 110, 97, 109, 101,
					95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_team_member_id()
			{
				return new byte[15]
				{
					174, 116, 101, 97, 109, 95, 109, 101, 109, 98,
					101, 114, 95, 105, 100
				};
			}

			public void Serialize(ref MessagePackWriter writer, ChampionsUserChara value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(4);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
				writer.WriteRaw(GetSpan_race_cloth_id());
				writer.Write(value.race_cloth_id);
				writer.WriteRaw(GetSpan_nick_name_id());
				writer.Write(value.nick_name_id);
				writer.WriteRaw(GetSpan_team_member_id());
				writer.Write(value.team_member_id);
			}

			public ChampionsUserChara Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				ChampionsUserChara championsUserChara = new ChampionsUserChara();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 7235419148482865251L)
						{
							championsUserChara.chara_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 13:
						if (span.SequenceEqual(GetSpan_race_cloth_id().Slice(1)))
						{
							championsUserChara.race_cloth_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 12:
						if (span.SequenceEqual(GetSpan_nick_name_id().Slice(1)))
						{
							championsUserChara.nick_name_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 14:
						if (span.SequenceEqual(GetSpan_team_member_id().Slice(1)))
						{
							championsUserChara.team_member_id = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return championsUserChara;
			}
		}

		internal sealed class CharaRaceRewardFormatter : IMessagePackFormatter<CharaRaceReward>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_result_rank()
			{
				return new byte[12]
				{
					171, 114, 101, 115, 117, 108, 116, 95, 114, 97,
					110, 107
				};
			}

			private static ReadOnlySpan<byte> GetSpan_result_time()
			{
				return new byte[12]
				{
					171, 114, 101, 115, 117, 108, 116, 95, 116, 105,
					109, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_reward()
			{
				return new byte[12]
				{
					171, 114, 97, 99, 101, 95, 114, 101, 119, 97,
					114, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_reward_bonus()
			{
				return new byte[18]
				{
					177, 114, 97, 99, 101, 95, 114, 101, 119, 97,
					114, 100, 95, 98, 111, 110, 117, 115
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_reward_plus_bonus()
			{
				return new byte[23]
				{
					182, 114, 97, 99, 101, 95, 114, 101, 119, 97,
					114, 100, 95, 112, 108, 117, 115, 95, 98, 111,
					110, 117, 115
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_reward_bonus_win()
			{
				return new byte[22]
				{
					181, 114, 97, 99, 101, 95, 114, 101, 119, 97,
					114, 100, 95, 98, 111, 110, 117, 115, 95, 119,
					105, 110
				};
			}

			private static ReadOnlySpan<byte> GetSpan_gained_fans()
			{
				return new byte[12]
				{
					171, 103, 97, 105, 110, 101, 100, 95, 102, 97,
					110, 115
				};
			}

			private static ReadOnlySpan<byte> GetSpan_campaign_id_array()
			{
				return new byte[18]
				{
					177, 99, 97, 109, 112, 97, 105, 103, 110, 95,
					105, 100, 95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, CharaRaceReward value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(8);
				writer.WriteRaw(GetSpan_result_rank());
				writer.Write(value.result_rank);
				writer.WriteRaw(GetSpan_result_time());
				writer.Write(value.result_time);
				writer.WriteRaw(GetSpan_race_reward());
				resolver.GetFormatterWithVerify<RaceRewardData[]>().Serialize(ref writer, value.race_reward, options);
				writer.WriteRaw(GetSpan_race_reward_bonus());
				resolver.GetFormatterWithVerify<RaceRewardData[]>().Serialize(ref writer, value.race_reward_bonus, options);
				writer.WriteRaw(GetSpan_race_reward_plus_bonus());
				resolver.GetFormatterWithVerify<RaceRewardData[]>().Serialize(ref writer, value.race_reward_plus_bonus, options);
				writer.WriteRaw(GetSpan_race_reward_bonus_win());
				resolver.GetFormatterWithVerify<RaceRewardData[]>().Serialize(ref writer, value.race_reward_bonus_win, options);
				writer.WriteRaw(GetSpan_gained_fans());
				writer.Write(value.gained_fans);
				writer.WriteRaw(GetSpan_campaign_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.campaign_id_array, options);
			}

			public CharaRaceReward Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				CharaRaceReward charaRaceReward = new CharaRaceReward();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length <= 17)
					{
						if (length != 11)
						{
							if (length == 17)
							{
								ulong key = AutomataKeyGen.GetKey(ref span);
								if (key != 7955443133992231267L)
								{
									if (key == 8603408417209672050L && span.SequenceEqual(GetSpan_race_reward_bonus().Slice(9)))
									{
										charaRaceReward.race_reward_bonus = resolver.GetFormatterWithVerify<RaceRewardData[]>().Deserialize(ref reader, options);
										continue;
									}
								}
								else if (span.SequenceEqual(GetSpan_campaign_id_array().Slice(9)))
								{
									charaRaceReward.campaign_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
									continue;
								}
							}
						}
						else
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key <= 8241433852287083890L)
							{
								if (key != 7376725101463036263L)
								{
									if (key == 8241433852287083890L && AutomataKeyGen.GetKey(ref span) == 7040609)
									{
										charaRaceReward.result_rank = reader.ReadInt32();
										continue;
									}
								}
								else if (AutomataKeyGen.GetKey(ref span) == 7564897)
								{
									charaRaceReward.gained_fans = reader.ReadInt32();
									continue;
								}
							}
							else if (key != 8385549040362939762L)
							{
								if (key == 8603408417209672050L && AutomataKeyGen.GetKey(ref span) == 6582881)
								{
									charaRaceReward.race_reward = resolver.GetFormatterWithVerify<RaceRewardData[]>().Deserialize(ref reader, options);
									continue;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 6647145)
							{
								charaRaceReward.result_time = reader.ReadInt32();
								continue;
							}
						}
					}
					else if (length != 21)
					{
						if (length == 22 && span.SequenceEqual(GetSpan_race_reward_plus_bonus().Slice(1)))
						{
							charaRaceReward.race_reward_plus_bonus = resolver.GetFormatterWithVerify<RaceRewardData[]>().Deserialize(ref reader, options);
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_race_reward_bonus_win().Slice(1)))
					{
						charaRaceReward.race_reward_bonus_win = resolver.GetFormatterWithVerify<RaceRewardData[]>().Deserialize(ref reader, options);
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return charaRaceReward;
			}
		}

		internal sealed class ChoiceArrayFormatter : IMessagePackFormatter<ChoiceArray>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_select_index()
			{
				return new byte[13]
				{
					172, 115, 101, 108, 101, 99, 116, 95, 105, 110,
					100, 101, 120
				};
			}

			private static ReadOnlySpan<byte> GetSpan_receive_item_id()
			{
				return new byte[16]
				{
					175, 114, 101, 99, 101, 105, 118, 101, 95, 105,
					116, 101, 109, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_target_race_id()
			{
				return new byte[15]
				{
					174, 116, 97, 114, 103, 101, 116, 95, 114, 97,
					99, 101, 95, 105, 100
				};
			}

			public void Serialize(ref MessagePackWriter writer, ChoiceArray value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_select_index());
				writer.Write(value.select_index);
				writer.WriteRaw(GetSpan_receive_item_id());
				writer.Write(value.receive_item_id);
				writer.WriteRaw(GetSpan_target_race_id());
				writer.Write(value.target_race_id);
			}

			public ChoiceArray Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				ChoiceArray choiceArray = new ChoiceArray();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 12:
						if (span.SequenceEqual(GetSpan_select_index().Slice(1)))
						{
							choiceArray.select_index = reader.ReadInt32();
							break;
						}
						goto default;
					case 15:
						if (span.SequenceEqual(GetSpan_receive_item_id().Slice(1)))
						{
							choiceArray.receive_item_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 14:
						if (span.SequenceEqual(GetSpan_target_race_id().Slice(1)))
						{
							choiceArray.target_race_id = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return choiceArray;
			}
		}

		internal sealed class CircleInfoAtFriendFormatter : IMessagePackFormatter<CircleInfoAtFriend>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_circle_id()
			{
				return new byte[10] { 169, 99, 105, 114, 99, 108, 101, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_name()
			{
				return new byte[5] { 164, 110, 97, 109, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_monthly_rank()
			{
				return new byte[13]
				{
					172, 109, 111, 110, 116, 104, 108, 121, 95, 114,
					97, 110, 107
				};
			}

			public void Serialize(ref MessagePackWriter writer, CircleInfoAtFriend value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_circle_id());
				writer.Write(value.circle_id);
				writer.WriteRaw(GetSpan_name());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.name, options);
				writer.WriteRaw(GetSpan_monthly_rank());
				writer.Write(value.monthly_rank);
			}

			public CircleInfoAtFriend Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				CircleInfoAtFriend circleInfoAtFriend = new CircleInfoAtFriend();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 4)
					{
						if (length != 9)
						{
							if (length == 12 && span.SequenceEqual(GetSpan_monthly_rank().Slice(1)))
							{
								circleInfoAtFriend.monthly_rank = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_circle_id().Slice(1)))
						{
							circleInfoAtFriend.circle_id = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 1701667182)
					{
						circleInfoAtFriend.name = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return circleInfoAtFriend;
			}
		}

		internal sealed class CircleUserFormatter : IMessagePackFormatter<CircleUser>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_viewer_id()
			{
				return new byte[10] { 169, 118, 105, 101, 119, 101, 114, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_circle_id()
			{
				return new byte[10] { 169, 99, 105, 114, 99, 108, 101, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_membership()
			{
				return new byte[11]
				{
					170, 109, 101, 109, 98, 101, 114, 115, 104, 105,
					112
				};
			}

			private static ReadOnlySpan<byte> GetSpan_join_time()
			{
				return new byte[10] { 169, 106, 111, 105, 110, 95, 116, 105, 109, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_penalty_end_time()
			{
				return new byte[17]
				{
					176, 112, 101, 110, 97, 108, 116, 121, 95, 101,
					110, 100, 95, 116, 105, 109, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_item_request_end_time()
			{
				return new byte[22]
				{
					181, 105, 116, 101, 109, 95, 114, 101, 113, 117,
					101, 115, 116, 95, 101, 110, 100, 95, 116, 105,
					109, 101
				};
			}

			public void Serialize(ref MessagePackWriter writer, CircleUser value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(6);
				writer.WriteRaw(GetSpan_viewer_id());
				writer.Write(value.viewer_id);
				writer.WriteRaw(GetSpan_circle_id());
				writer.Write(value.circle_id);
				writer.WriteRaw(GetSpan_membership());
				writer.Write(value.membership);
				writer.WriteRaw(GetSpan_join_time());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.join_time, options);
				writer.WriteRaw(GetSpan_penalty_end_time());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.penalty_end_time, options);
				writer.WriteRaw(GetSpan_item_request_end_time());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.item_request_end_time, options);
			}

			public CircleUser Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				CircleUser circleUser = new CircleUser();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length <= 10)
					{
						if (length != 9)
						{
							if (length == 10 && span.SequenceEqual(GetSpan_membership().Slice(1)))
							{
								circleUser.membership = reader.ReadInt32();
								continue;
							}
						}
						else
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 7592899012969261411L)
							{
								if (key != 7592913276890343798L)
								{
									if (key == 7883960575911882602L && span[0] == 101)
									{
										circleUser.join_time = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
										continue;
									}
								}
								else if (span[0] == 100)
								{
									circleUser.viewer_id = reader.ReadInt64();
									continue;
								}
							}
							else if (span[0] == 100)
							{
								circleUser.circle_id = reader.ReadInt32();
								continue;
							}
						}
					}
					else if (length != 16)
					{
						if (length == 21 && span.SequenceEqual(GetSpan_item_request_end_time().Slice(1)))
						{
							circleUser.item_request_end_time = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_penalty_end_time().Slice(1)))
					{
						circleUser.penalty_end_time = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return circleUser;
			}
		}

		internal sealed class DirectoryCardFormatter : IMessagePackFormatter<DirectoryCard>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_card_id()
			{
				return new byte[8] { 167, 99, 97, 114, 100, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_directory_ranking()
			{
				return new byte[18]
				{
					177, 100, 105, 114, 101, 99, 116, 111, 114, 121,
					95, 114, 97, 110, 107, 105, 110, 103
				};
			}

			private static ReadOnlySpan<byte> GetSpan_trained_chara()
			{
				return new byte[14]
				{
					173, 116, 114, 97, 105, 110, 101, 100, 95, 99,
					104, 97, 114, 97
				};
			}

			public void Serialize(ref MessagePackWriter writer, DirectoryCard value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_card_id());
				writer.Write(value.card_id);
				writer.WriteRaw(GetSpan_directory_ranking());
				writer.Write(value.directory_ranking);
				writer.WriteRaw(GetSpan_trained_chara());
				resolver.GetFormatterWithVerify<TrainedChara>().Serialize(ref writer, value.trained_chara, options);
			}

			public DirectoryCard Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				DirectoryCard directoryCard = new DirectoryCard();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 7)
					{
						if (length != 13)
						{
							if (length == 17 && span.SequenceEqual(GetSpan_directory_ranking().Slice(1)))
							{
								directoryCard.directory_ranking = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_trained_chara().Slice(1)))
						{
							directoryCard.trained_chara = resolver.GetFormatterWithVerify<TrainedChara>().Deserialize(ref reader, options);
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 28263356099092835L)
					{
						directoryCard.card_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return directoryCard;
			}
		}

		internal sealed class EvaluationInfoFormatter : IMessagePackFormatter<EvaluationInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_target_id()
			{
				return new byte[10] { 169, 116, 97, 114, 103, 101, 116, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_evaluation()
			{
				return new byte[11]
				{
					170, 101, 118, 97, 108, 117, 97, 116, 105, 111,
					110
				};
			}

			private static ReadOnlySpan<byte> GetSpan_is_outing()
			{
				return new byte[10] { 169, 105, 115, 95, 111, 117, 116, 105, 110, 103 };
			}

			private static ReadOnlySpan<byte> GetSpan_story_step()
			{
				return new byte[11]
				{
					170, 115, 116, 111, 114, 121, 95, 115, 116, 101,
					112
				};
			}

			private static ReadOnlySpan<byte> GetSpan_is_appear()
			{
				return new byte[10] { 169, 105, 115, 95, 97, 112, 112, 101, 97, 114 };
			}

			private static ReadOnlySpan<byte> GetSpan_group_outing_info_array()
			{
				return new byte[24]
				{
					183, 103, 114, 111, 117, 112, 95, 111, 117, 116,
					105, 110, 103, 95, 105, 110, 102, 111, 95, 97,
					114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, EvaluationInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(6);
				writer.WriteRaw(GetSpan_target_id());
				writer.Write(value.target_id);
				writer.WriteRaw(GetSpan_evaluation());
				writer.Write(value.evaluation);
				writer.WriteRaw(GetSpan_is_outing());
				writer.Write(value.is_outing);
				writer.WriteRaw(GetSpan_story_step());
				writer.Write(value.story_step);
				writer.WriteRaw(GetSpan_is_appear());
				writer.Write(value.is_appear);
				writer.WriteRaw(GetSpan_group_outing_info_array());
				resolver.GetFormatterWithVerify<GroupOutingInfo[]>().Serialize(ref writer, value.group_outing_info_array, options);
			}

			public EvaluationInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				EvaluationInfo evaluationInfo = new EvaluationInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 9)
					{
						if (length != 10)
						{
							if (length == 23 && span.SequenceEqual(GetSpan_group_outing_info_array().Slice(1)))
							{
								evaluationInfo.group_outing_info_array = resolver.GetFormatterWithVerify<GroupOutingInfo[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 7598805628238263909L)
							{
								if (key == 8391155505936954483L && AutomataKeyGen.GetKey(ref span) == 28773)
								{
									evaluationInfo.story_step = reader.ReadInt32();
									continue;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 28271)
							{
								evaluationInfo.evaluation = reader.ReadInt32();
								continue;
							}
						}
					}
					else
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7018139222299079529L)
						{
							if (key != 7592915475646013812L)
							{
								if (key == 7956018264455213929L && span[0] == 103)
								{
									evaluationInfo.is_outing = reader.ReadInt32();
									continue;
								}
							}
							else if (span[0] == 100)
							{
								evaluationInfo.target_id = reader.ReadInt32();
								continue;
							}
						}
						else if (span[0] == 114)
						{
							evaluationInfo.is_appear = reader.ReadInt32();
							continue;
						}
					}
					reader.Skip();
				}
				reader.Depth--;
				return evaluationInfo;
			}
		}

		internal sealed class EventContentsInfoFormatter : IMessagePackFormatter<EventContentsInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_support_card_id()
			{
				return new byte[16]
				{
					175, 115, 117, 112, 112, 111, 114, 116, 95, 99,
					97, 114, 100, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_show_clear()
			{
				return new byte[11]
				{
					170, 115, 104, 111, 119, 95, 99, 108, 101, 97,
					114
				};
			}

			private static ReadOnlySpan<byte> GetSpan_show_clear_sort_id()
			{
				return new byte[19]
				{
					178, 115, 104, 111, 119, 95, 99, 108, 101, 97,
					114, 95, 115, 111, 114, 116, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_choice_array()
			{
				return new byte[13]
				{
					172, 99, 104, 111, 105, 99, 101, 95, 97, 114,
					114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_is_effected_multi_chara()
			{
				return new byte[24]
				{
					183, 105, 115, 95, 101, 102, 102, 101, 99, 116,
					101, 100, 95, 109, 117, 108, 116, 105, 95, 99,
					104, 97, 114, 97
				};
			}

			public void Serialize(ref MessagePackWriter writer, EventContentsInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(5);
				writer.WriteRaw(GetSpan_support_card_id());
				writer.Write(value.support_card_id);
				writer.WriteRaw(GetSpan_show_clear());
				writer.Write(value.show_clear);
				writer.WriteRaw(GetSpan_show_clear_sort_id());
				writer.Write(value.show_clear_sort_id);
				writer.WriteRaw(GetSpan_choice_array());
				resolver.GetFormatterWithVerify<ChoiceArray[]>().Serialize(ref writer, value.choice_array, options);
				writer.WriteRaw(GetSpan_is_effected_multi_chara());
				writer.Write(value.is_effected_multi_chara);
			}

			public EventContentsInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				EventContentsInfo eventContentsInfo = new EventContentsInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length <= 12)
					{
						if (length != 10)
						{
							if (length == 12 && span.SequenceEqual(GetSpan_choice_array().Slice(1)))
							{
								eventContentsInfo.choice_array = resolver.GetFormatterWithVerify<ChoiceArray[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_show_clear().Slice(1)))
						{
							eventContentsInfo.show_clear = reader.ReadInt32();
							continue;
						}
					}
					else if (length != 15)
					{
						if (length != 18)
						{
							if (length == 23 && span.SequenceEqual(GetSpan_is_effected_multi_chara().Slice(1)))
							{
								eventContentsInfo.is_effected_multi_chara = reader.ReadBoolean();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_show_clear_sort_id().Slice(1)))
						{
							eventContentsInfo.show_clear_sort_id = reader.ReadInt32();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_support_card_id().Slice(1)))
					{
						eventContentsInfo.support_card_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return eventContentsInfo;
			}
		}

		internal sealed class FactorExtendInfoFormatter : IMessagePackFormatter<FactorExtendInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_position_id()
			{
				return new byte[12]
				{
					171, 112, 111, 115, 105, 116, 105, 111, 110, 95,
					105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_base_factor_id()
			{
				return new byte[15]
				{
					174, 98, 97, 115, 101, 95, 102, 97, 99, 116,
					111, 114, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_factor_id()
			{
				return new byte[10] { 169, 102, 97, 99, 116, 111, 114, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_register_time()
			{
				return new byte[14]
				{
					173, 114, 101, 103, 105, 115, 116, 101, 114, 95,
					116, 105, 109, 101
				};
			}

			public void Serialize(ref MessagePackWriter writer, FactorExtendInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(4);
				writer.WriteRaw(GetSpan_position_id());
				writer.Write(value.position_id);
				writer.WriteRaw(GetSpan_base_factor_id());
				writer.Write(value.base_factor_id);
				writer.WriteRaw(GetSpan_factor_id());
				writer.Write(value.factor_id);
				writer.WriteRaw(GetSpan_register_time());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.register_time, options);
			}

			public FactorExtendInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				FactorExtendInfo factorExtendInfo = new FactorExtendInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 11:
						if (span.SequenceEqual(GetSpan_position_id().Slice(1)))
						{
							factorExtendInfo.position_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 14:
						if (span.SequenceEqual(GetSpan_base_factor_id().Slice(1)))
						{
							factorExtendInfo.base_factor_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 9:
						if (span.SequenceEqual(GetSpan_factor_id().Slice(1)))
						{
							factorExtendInfo.factor_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 13:
						if (span.SequenceEqual(GetSpan_register_time().Slice(1)))
						{
							factorExtendInfo.register_time = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return factorExtendInfo;
			}
		}

		internal sealed class FactorInfoFormatter : IMessagePackFormatter<FactorInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_factor_id()
			{
				return new byte[10] { 169, 102, 97, 99, 116, 111, 114, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_level()
			{
				return new byte[6] { 165, 108, 101, 118, 101, 108 };
			}

			public void Serialize(ref MessagePackWriter writer, FactorInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_factor_id());
				writer.Write(value.factor_id);
				writer.WriteRaw(GetSpan_level());
				writer.Write(value.level);
			}

			public FactorInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				FactorInfo factorInfo = new FactorInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 5)
					{
						if (length == 9 && span.SequenceEqual(GetSpan_factor_id().Slice(1)))
						{
							factorInfo.factor_id = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 465558725996L)
					{
						factorInfo.level = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return factorInfo;
			}
		}

		internal sealed class FriendSearchResponseFormatter : IMessagePackFormatter<global::Gallop.FriendSearchResponse>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_data()
			{
				return new byte[5] { 164, 100, 97, 116, 97 };
			}

			public void Serialize(ref MessagePackWriter writer, global::Gallop.FriendSearchResponse value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(1);
				writer.WriteRaw(GetSpan_data());
				resolver.GetFormatterWithVerify<global::Gallop.FriendSearchResponse.CommonResponse>().Serialize(ref writer, value.data, options);
			}

			public global::Gallop.FriendSearchResponse Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				global::Gallop.FriendSearchResponse friendSearchResponse = new global::Gallop.FriendSearchResponse();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					if (span.Length != 4 || AutomataKeyGen.GetKey(ref span) != 1635017060)
					{
						reader.Skip();
					}
					else
					{
						friendSearchResponse.data = resolver.GetFormatterWithVerify<global::Gallop.FriendSearchResponse.CommonResponse>().Deserialize(ref reader, options);
					}
				}
				reader.Depth--;
				return friendSearchResponse;
			}
		}

		internal sealed class GroupOutingInfoFormatter : IMessagePackFormatter<GroupOutingInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_is_outing()
			{
				return new byte[10] { 169, 105, 115, 95, 111, 117, 116, 105, 110, 103 };
			}

			private static ReadOnlySpan<byte> GetSpan_story_step()
			{
				return new byte[11]
				{
					170, 115, 116, 111, 114, 121, 95, 115, 116, 101,
					112
				};
			}

			public void Serialize(ref MessagePackWriter writer, GroupOutingInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
				writer.WriteRaw(GetSpan_is_outing());
				writer.Write(value.is_outing);
				writer.WriteRaw(GetSpan_story_step());
				writer.Write(value.story_step);
			}

			public GroupOutingInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				GroupOutingInfo groupOutingInfo = new GroupOutingInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 7235419148482865251L)
						{
							groupOutingInfo.chara_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 9:
						if (span.SequenceEqual(GetSpan_is_outing().Slice(1)))
						{
							groupOutingInfo.is_outing = reader.ReadInt32();
							break;
						}
						goto default;
					case 10:
						if (span.SequenceEqual(GetSpan_story_step().Slice(1)))
						{
							groupOutingInfo.story_step = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return groupOutingInfo;
			}
		}

		internal sealed class GuestOutingInfoFormatter : IMessagePackFormatter<GuestOutingInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_support_card_id()
			{
				return new byte[16]
				{
					175, 115, 117, 112, 112, 111, 114, 116, 95, 99,
					97, 114, 100, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_story_step()
			{
				return new byte[11]
				{
					170, 115, 116, 111, 114, 121, 95, 115, 116, 101,
					112
				};
			}

			private static ReadOnlySpan<byte> GetSpan_group_outing_info_array()
			{
				return new byte[24]
				{
					183, 103, 114, 111, 117, 112, 95, 111, 117, 116,
					105, 110, 103, 95, 105, 110, 102, 111, 95, 97,
					114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, GuestOutingInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_support_card_id());
				writer.Write(value.support_card_id);
				writer.WriteRaw(GetSpan_story_step());
				writer.Write(value.story_step);
				writer.WriteRaw(GetSpan_group_outing_info_array());
				resolver.GetFormatterWithVerify<GroupOutingInfo[]>().Serialize(ref writer, value.group_outing_info_array, options);
			}

			public GuestOutingInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				GuestOutingInfo guestOutingInfo = new GuestOutingInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 10)
					{
						if (length != 15)
						{
							if (length == 23 && span.SequenceEqual(GetSpan_group_outing_info_array().Slice(1)))
							{
								guestOutingInfo.group_outing_info_array = resolver.GetFormatterWithVerify<GroupOutingInfo[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_support_card_id().Slice(1)))
						{
							guestOutingInfo.support_card_id = reader.ReadInt32();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_story_step().Slice(1)))
					{
						guestOutingInfo.story_step = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return guestOutingInfo;
			}
		}

		internal sealed class MinigameResultFormatter : IMessagePackFormatter<MinigameResult>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_result_state()
			{
				return new byte[13]
				{
					172, 114, 101, 115, 117, 108, 116, 95, 115, 116,
					97, 116, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_result_value()
			{
				return new byte[13]
				{
					172, 114, 101, 115, 117, 108, 116, 95, 118, 97,
					108, 117, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_result_detail_array()
			{
				return new byte[20]
				{
					179, 114, 101, 115, 117, 108, 116, 95, 100, 101,
					116, 97, 105, 108, 95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, MinigameResult value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_result_state());
				writer.Write(value.result_state);
				writer.WriteRaw(GetSpan_result_value());
				writer.Write(value.result_value);
				writer.WriteRaw(GetSpan_result_detail_array());
				resolver.GetFormatterWithVerify<MinigameResultDetail[]>().Serialize(ref writer, value.result_detail_array, options);
			}

			public MinigameResult Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				MinigameResult minigameResult = new MinigameResult();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 12)
					{
						if (length == 19 && span.SequenceEqual(GetSpan_result_detail_array().Slice(1)))
						{
							minigameResult.result_detail_array = resolver.GetFormatterWithVerify<MinigameResultDetail[]>().Deserialize(ref reader, options);
							continue;
						}
					}
					else
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 8313491446325011826L)
						{
							if (key == 8529664228438795634L && AutomataKeyGen.GetKey(ref span) == 1702194273)
							{
								minigameResult.result_value = reader.ReadInt32();
								continue;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 1702125940)
						{
							minigameResult.result_state = reader.ReadInt32();
							continue;
						}
					}
					reader.Skip();
				}
				reader.Depth--;
				return minigameResult;
			}
		}

		internal sealed class MinigameResultDetailFormatter : IMessagePackFormatter<MinigameResultDetail>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_get_id()
			{
				return new byte[7] { 166, 103, 101, 116, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_dress_id()
			{
				return new byte[9] { 168, 100, 114, 101, 115, 115, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_motion()
			{
				return new byte[7] { 166, 109, 111, 116, 105, 111, 110 };
			}

			private static ReadOnlySpan<byte> GetSpan_face()
			{
				return new byte[5] { 164, 102, 97, 99, 101 };
			}

			public void Serialize(ref MessagePackWriter writer, MinigameResultDetail value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(5);
				writer.WriteRaw(GetSpan_get_id());
				writer.Write(value.get_id);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
				writer.WriteRaw(GetSpan_dress_id());
				writer.Write(value.dress_id);
				writer.WriteRaw(GetSpan_motion());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.motion, options);
				writer.WriteRaw(GetSpan_face());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.face, options);
			}

			public MinigameResultDetail Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				MinigameResultDetail minigameResultDetail = new MinigameResultDetail();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 6:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 110403735807335uL:
							minigameResultDetail.get_id = reader.ReadInt32();
							goto end_IL_0046;
						case 121424789663597uL:
							minigameResultDetail.motion = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							goto end_IL_0046;
						}
						goto default;
					case 8:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 7235419148482865251uL:
							minigameResultDetail.chara_id = reader.ReadInt32();
							goto end_IL_0046;
						case 7235419225809318500uL:
							minigameResultDetail.dress_id = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 4:
						{
							if (AutomataKeyGen.GetKey(ref span) == 1701011814)
							{
								minigameResultDetail.face = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						}
						end_IL_0046:
						break;
					}
				}
				reader.Depth--;
				return minigameResultDetail;
			}
		}

		internal sealed class NotDownParameterInfoFormatter : IMessagePackFormatter<NotDownParameterInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_evaluation_chara_id_array()
			{
				return new byte[26]
				{
					185, 101, 118, 97, 108, 117, 97, 116, 105, 111,
					110, 95, 99, 104, 97, 114, 97, 95, 105, 100,
					95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, NotDownParameterInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(1);
				writer.WriteRaw(GetSpan_evaluation_chara_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.evaluation_chara_id_array, options);
			}

			public NotDownParameterInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				NotDownParameterInfo notDownParameterInfo = new NotDownParameterInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					if (span.Length != 25 || !span.SequenceEqual(GetSpan_evaluation_chara_id_array().Slice(1)))
					{
						reader.Skip();
					}
					else
					{
						notDownParameterInfo.evaluation_chara_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
					}
				}
				reader.Depth--;
				return notDownParameterInfo;
			}
		}

		internal sealed class NotGainCharaEffectFormatter : IMessagePackFormatter<NotGainCharaEffect>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_effected_chara_effect_id()
			{
				return new byte[25]
				{
					184, 101, 102, 102, 101, 99, 116, 101, 100, 95,
					99, 104, 97, 114, 97, 95, 101, 102, 102, 101,
					99, 116, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_not_gain_chara_effect_id()
			{
				return new byte[25]
				{
					184, 110, 111, 116, 95, 103, 97, 105, 110, 95,
					99, 104, 97, 114, 97, 95, 101, 102, 102, 101,
					99, 116, 95, 105, 100
				};
			}

			public void Serialize(ref MessagePackWriter writer, NotGainCharaEffect value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_effected_chara_effect_id());
				writer.Write(value.effected_chara_effect_id);
				writer.WriteRaw(GetSpan_not_gain_chara_effect_id());
				writer.Write(value.not_gain_chara_effect_id);
			}

			public NotGainCharaEffect Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				NotGainCharaEffect notGainCharaEffect = new NotGainCharaEffect();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					if (span.Length == 24)
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7234316346692363877L)
						{
							if (key == 7955997313337683822L && span.SequenceEqual(GetSpan_not_gain_chara_effect_id().Slice(9)))
							{
								notGainCharaEffect.not_gain_chara_effect_id = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_effected_chara_effect_id().Slice(9)))
						{
							notGainCharaEffect.effected_chara_effect_id = reader.ReadInt32();
							continue;
						}
					}
					reader.Skip();
				}
				reader.Depth--;
				return notGainCharaEffect;
			}
		}

		internal sealed class NotUpArcParameterInfoFormatter : IMessagePackFormatter<NotUpArcParameterInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_rival_boost_chara_id_array()
			{
				return new byte[27]
				{
					186, 114, 105, 118, 97, 108, 95, 98, 111, 111,
					115, 116, 95, 99, 104, 97, 114, 97, 95, 105,
					100, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_all_rival_boost_flag()
			{
				return new byte[21]
				{
					180, 97, 108, 108, 95, 114, 105, 118, 97, 108,
					95, 98, 111, 111, 115, 116, 95, 102, 108, 97,
					103
				};
			}

			public void Serialize(ref MessagePackWriter writer, NotUpArcParameterInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_rival_boost_chara_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.rival_boost_chara_id_array, options);
				writer.WriteRaw(GetSpan_all_rival_boost_flag());
				writer.Write(value.all_rival_boost_flag);
			}

			public NotUpArcParameterInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				NotUpArcParameterInfo notUpArcParameterInfo = new NotUpArcParameterInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 20)
					{
						if (length == 26 && span.SequenceEqual(GetSpan_rival_boost_chara_id_array().Slice(1)))
						{
							notUpArcParameterInfo.rival_boost_chara_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_all_rival_boost_flag().Slice(1)))
					{
						notUpArcParameterInfo.all_rival_boost_flag = reader.ReadBoolean();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return notUpArcParameterInfo;
			}
		}

		internal sealed class NotUpParameterInfoFormatter : IMessagePackFormatter<NotUpParameterInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_status_type_array()
			{
				return new byte[18]
				{
					177, 115, 116, 97, 116, 117, 115, 95, 116, 121,
					112, 101, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_chara_effect_id_array()
			{
				return new byte[22]
				{
					181, 99, 104, 97, 114, 97, 95, 101, 102, 102,
					101, 99, 116, 95, 105, 100, 95, 97, 114, 114,
					97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_skill_id_array()
			{
				return new byte[15]
				{
					174, 115, 107, 105, 108, 108, 95, 105, 100, 95,
					97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_skill_tips_array()
			{
				return new byte[17]
				{
					176, 115, 107, 105, 108, 108, 95, 116, 105, 112,
					115, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_skill_lv_id_array()
			{
				return new byte[18]
				{
					177, 115, 107, 105, 108, 108, 95, 108, 118, 95,
					105, 100, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_evaluation_chara_id_array()
			{
				return new byte[26]
				{
					185, 101, 118, 97, 108, 117, 97, 116, 105, 111,
					110, 95, 99, 104, 97, 114, 97, 95, 105, 100,
					95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_lv_array()
			{
				return new byte[17]
				{
					176, 99, 111, 109, 109, 97, 110, 100, 95, 108,
					118, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_has_chara_effect_id_array()
			{
				return new byte[26]
				{
					185, 104, 97, 115, 95, 99, 104, 97, 114, 97,
					95, 101, 102, 102, 101, 99, 116, 95, 105, 100,
					95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_unsupported_evaluation_chara_id_array()
			{
				return new byte[39]
				{
					217, 37, 117, 110, 115, 117, 112, 112, 111, 114,
					116, 101, 100, 95, 101, 118, 97, 108, 117, 97,
					116, 105, 111, 110, 95, 99, 104, 97, 114, 97,
					95, 105, 100, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_not_gain_chara_effect_array()
			{
				return new byte[28]
				{
					187, 110, 111, 116, 95, 103, 97, 105, 110, 95,
					99, 104, 97, 114, 97, 95, 101, 102, 102, 101,
					99, 116, 95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, NotUpParameterInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(10);
				writer.WriteRaw(GetSpan_status_type_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.status_type_array, options);
				writer.WriteRaw(GetSpan_chara_effect_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.chara_effect_id_array, options);
				writer.WriteRaw(GetSpan_skill_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.skill_id_array, options);
				writer.WriteRaw(GetSpan_skill_tips_array());
				resolver.GetFormatterWithVerify<SkillTips[]>().Serialize(ref writer, value.skill_tips_array, options);
				writer.WriteRaw(GetSpan_skill_lv_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.skill_lv_id_array, options);
				writer.WriteRaw(GetSpan_evaluation_chara_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.evaluation_chara_id_array, options);
				writer.WriteRaw(GetSpan_command_lv_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.command_lv_array, options);
				writer.WriteRaw(GetSpan_has_chara_effect_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.has_chara_effect_id_array, options);
				writer.WriteRaw(GetSpan_unsupported_evaluation_chara_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.unsupported_evaluation_chara_id_array, options);
				writer.WriteRaw(GetSpan_not_gain_chara_effect_array());
				resolver.GetFormatterWithVerify<NotGainCharaEffect[]>().Serialize(ref writer, value.not_gain_chara_effect_array, options);
			}

			public NotUpParameterInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				NotUpParameterInfo notUpParameterInfo = new NotUpParameterInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 17:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 8385547979488064627L)
						{
							if (key == 8533300313240202099L && span.SequenceEqual(GetSpan_skill_lv_id_array().Slice(9)))
							{
								notUpParameterInfo.skill_lv_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_status_type_array().Slice(9)))
						{
							notUpParameterInfo.status_type_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 21:
						if (span.SequenceEqual(GetSpan_chara_effect_id_array().Slice(1)))
						{
							notUpParameterInfo.chara_effect_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 14:
						if (span.SequenceEqual(GetSpan_skill_id_array().Slice(1)))
						{
							notUpParameterInfo.skill_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 16:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6873740296000991075L)
						{
							if (key == 7598803390560824179L && AutomataKeyGen.GetKey(ref span) == 8746397786915697520L)
							{
								notUpParameterInfo.skill_tips_array = resolver.GetFormatterWithVerify<SkillTips[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 8746397786915698284L)
						{
							notUpParameterInfo.command_lv_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 25:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7598805628238263909L)
						{
							if (key == 8241983569077166440L && span.SequenceEqual(GetSpan_has_chara_effect_id_array().Slice(9)))
							{
								notUpParameterInfo.has_chara_effect_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_evaluation_chara_id_array().Slice(9)))
						{
							notUpParameterInfo.evaluation_chara_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 37:
						if (span.SequenceEqual(GetSpan_unsupported_evaluation_chara_id_array().Slice(2)))
						{
							notUpParameterInfo.unsupported_evaluation_chara_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 27:
						if (span.SequenceEqual(GetSpan_not_gain_chara_effect_array().Slice(1)))
						{
							notUpParameterInfo.not_gain_chara_effect_array = resolver.GetFormatterWithVerify<NotGainCharaEffect[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return notUpParameterInfo;
			}
		}

		internal sealed class PracticePartnerOwnerInfoFormatter : IMessagePackFormatter<PracticePartnerOwnerInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_partner_trained_chara_id()
			{
				return new byte[25]
				{
					184, 112, 97, 114, 116, 110, 101, 114, 95, 116,
					114, 97, 105, 110, 101, 100, 95, 99, 104, 97,
					114, 97, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_owner_viewer_id()
			{
				return new byte[16]
				{
					175, 111, 119, 110, 101, 114, 95, 118, 105, 101,
					119, 101, 114, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_owner_name()
			{
				return new byte[11]
				{
					170, 111, 119, 110, 101, 114, 95, 110, 97, 109,
					101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_owner_trained_chara_id()
			{
				return new byte[23]
				{
					182, 111, 119, 110, 101, 114, 95, 116, 114, 97,
					105, 110, 101, 100, 95, 99, 104, 97, 114, 97,
					95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_friend_state()
			{
				return new byte[13]
				{
					172, 102, 114, 105, 101, 110, 100, 95, 115, 116,
					97, 116, 101
				};
			}

			public void Serialize(ref MessagePackWriter writer, PracticePartnerOwnerInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(5);
				writer.WriteRaw(GetSpan_partner_trained_chara_id());
				writer.Write(value.partner_trained_chara_id);
				writer.WriteRaw(GetSpan_owner_viewer_id());
				writer.Write(value.owner_viewer_id);
				writer.WriteRaw(GetSpan_owner_name());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.owner_name, options);
				writer.WriteRaw(GetSpan_owner_trained_chara_id());
				writer.Write(value.owner_trained_chara_id);
				writer.WriteRaw(GetSpan_friend_state());
				writer.Write(value.friend_state);
			}

			public PracticePartnerOwnerInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				PracticePartnerOwnerInfo practicePartnerOwnerInfo = new PracticePartnerOwnerInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length <= 12)
					{
						if (length != 10)
						{
							if (length == 12 && span.SequenceEqual(GetSpan_friend_state().Slice(1)))
							{
								practicePartnerOwnerInfo.friend_state = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_owner_name().Slice(1)))
						{
							practicePartnerOwnerInfo.owner_name = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							continue;
						}
					}
					else if (length != 15)
					{
						if (length != 22)
						{
							if (length == 24 && span.SequenceEqual(GetSpan_partner_trained_chara_id().Slice(1)))
							{
								practicePartnerOwnerInfo.partner_trained_chara_id = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_owner_trained_chara_id().Slice(1)))
						{
							practicePartnerOwnerInfo.owner_trained_chara_id = reader.ReadInt32();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_owner_viewer_id().Slice(1)))
					{
						practicePartnerOwnerInfo.owner_viewer_id = reader.ReadInt64();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return practicePartnerOwnerInfo;
			}
		}

		internal sealed class PracticeRaceEntryInfoFormatter : IMessagePackFormatter<PracticeRaceEntryInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_entry_id()
			{
				return new byte[9] { 168, 101, 110, 116, 114, 121, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_frame_order()
			{
				return new byte[12]
				{
					171, 102, 114, 97, 109, 101, 95, 111, 114, 100,
					101, 114
				};
			}

			public void Serialize(ref MessagePackWriter writer, PracticeRaceEntryInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_entry_id());
				writer.Write(value.entry_id);
				writer.WriteRaw(GetSpan_frame_order());
				writer.Write(value.frame_order);
			}

			public PracticeRaceEntryInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				PracticeRaceEntryInfo practiceRaceEntryInfo = new PracticeRaceEntryInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 8)
					{
						if (length == 11 && span.SequenceEqual(GetSpan_frame_order().Slice(1)))
						{
							practiceRaceEntryInfo.frame_order = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 7235419251563327077L)
					{
						practiceRaceEntryInfo.entry_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return practiceRaceEntryInfo;
			}
		}

		internal sealed class PracticeRaceRaceStartResponseFormatter : IMessagePackFormatter<global::Gallop.PracticeRaceRaceStartResponse>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_data()
			{
				return new byte[5] { 164, 100, 97, 116, 97 };
			}

			public void Serialize(ref MessagePackWriter writer, global::Gallop.PracticeRaceRaceStartResponse value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(1);
				writer.WriteRaw(GetSpan_data());
				resolver.GetFormatterWithVerify<global::Gallop.PracticeRaceRaceStartResponse.CommonResponse>().Serialize(ref writer, value.data, options);
			}

			public global::Gallop.PracticeRaceRaceStartResponse Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				global::Gallop.PracticeRaceRaceStartResponse practiceRaceRaceStartResponse = new global::Gallop.PracticeRaceRaceStartResponse();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					if (span.Length != 4 || AutomataKeyGen.GetKey(ref span) != 1635017060)
					{
						reader.Skip();
					}
					else
					{
						practiceRaceRaceStartResponse.data = resolver.GetFormatterWithVerify<global::Gallop.PracticeRaceRaceStartResponse.CommonResponse>().Deserialize(ref reader, options);
					}
				}
				reader.Depth--;
				return practiceRaceRaceStartResponse;
			}
		}

		internal sealed class RaceAnalyzeRequestFormatter : IMessagePackFormatter<RaceAnalyzeRequest>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_program_id()
			{
				return new byte[11]
				{
					170, 112, 114, 111, 103, 114, 97, 109, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_current_turn()
			{
				return new byte[13]
				{
					172, 99, 117, 114, 114, 101, 110, 116, 95, 116,
					117, 114, 110
				};
			}

			public void Serialize(ref MessagePackWriter writer, RaceAnalyzeRequest value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_program_id());
				writer.Write(value.program_id);
				writer.WriteRaw(GetSpan_current_turn());
				writer.Write(value.current_turn);
			}

			public RaceAnalyzeRequest Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				RaceAnalyzeRequest raceAnalyzeRequest = new RaceAnalyzeRequest();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 10)
					{
						if (length == 12 && span.SequenceEqual(GetSpan_current_turn().Slice(1)))
						{
							raceAnalyzeRequest.current_turn = reader.ReadInt32();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_program_id().Slice(1)))
					{
						raceAnalyzeRequest.program_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return raceAnalyzeRequest;
			}
		}

		internal sealed class RaceHorseDataFormatter : IMessagePackFormatter<RaceHorseData>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_viewer_id()
			{
				return new byte[10] { 169, 118, 105, 101, 119, 101, 114, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_owner_viewer_id()
			{
				return new byte[16]
				{
					175, 111, 119, 110, 101, 114, 95, 118, 105, 101,
					119, 101, 114, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_trainer_name()
			{
				return new byte[13]
				{
					172, 116, 114, 97, 105, 110, 101, 114, 95, 110,
					97, 109, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_owner_trainer_name()
			{
				return new byte[19]
				{
					178, 111, 119, 110, 101, 114, 95, 116, 114, 97,
					105, 110, 101, 114, 95, 110, 97, 109, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_single_mode_chara_id()
			{
				return new byte[21]
				{
					180, 115, 105, 110, 103, 108, 101, 95, 109, 111,
					100, 101, 95, 99, 104, 97, 114, 97, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_trained_chara_id()
			{
				return new byte[17]
				{
					176, 116, 114, 97, 105, 110, 101, 100, 95, 99,
					104, 97, 114, 97, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_nickname_id()
			{
				return new byte[12]
				{
					171, 110, 105, 99, 107, 110, 97, 109, 101, 95,
					105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_card_id()
			{
				return new byte[8] { 167, 99, 97, 114, 100, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_rarity()
			{
				return new byte[7] { 166, 114, 97, 114, 105, 116, 121 };
			}

			private static ReadOnlySpan<byte> GetSpan_talent_level()
			{
				return new byte[13]
				{
					172, 116, 97, 108, 101, 110, 116, 95, 108, 101,
					118, 101, 108
				};
			}

			private static ReadOnlySpan<byte> GetSpan_frame_order()
			{
				return new byte[12]
				{
					171, 102, 114, 97, 109, 101, 95, 111, 114, 100,
					101, 114
				};
			}

			private static ReadOnlySpan<byte> GetSpan_skill_array()
			{
				return new byte[12]
				{
					171, 115, 107, 105, 108, 108, 95, 97, 114, 114,
					97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_stamina()
			{
				return new byte[8] { 167, 115, 116, 97, 109, 105, 110, 97 };
			}

			private static ReadOnlySpan<byte> GetSpan_speed()
			{
				return new byte[6] { 165, 115, 112, 101, 101, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_pow()
			{
				return new byte[4] { 163, 112, 111, 119 };
			}

			private static ReadOnlySpan<byte> GetSpan_guts()
			{
				return new byte[5] { 164, 103, 117, 116, 115 };
			}

			private static ReadOnlySpan<byte> GetSpan_wiz()
			{
				return new byte[4] { 163, 119, 105, 122 };
			}

			private static ReadOnlySpan<byte> GetSpan_running_style()
			{
				return new byte[14]
				{
					173, 114, 117, 110, 110, 105, 110, 103, 95, 115,
					116, 121, 108, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_dress_id()
			{
				return new byte[14]
				{
					173, 114, 97, 99, 101, 95, 100, 114, 101, 115,
					115, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_chara_color_type()
			{
				return new byte[17]
				{
					176, 99, 104, 97, 114, 97, 95, 99, 111, 108,
					111, 114, 95, 116, 121, 112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_npc_type()
			{
				return new byte[9] { 168, 110, 112, 99, 95, 116, 121, 112, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_final_grade()
			{
				return new byte[12]
				{
					171, 102, 105, 110, 97, 108, 95, 103, 114, 97,
					100, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_popularity()
			{
				return new byte[11]
				{
					170, 112, 111, 112, 117, 108, 97, 114, 105, 116,
					121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_popularity_mark_rank_array()
			{
				return new byte[27]
				{
					186, 112, 111, 112, 117, 108, 97, 114, 105, 116,
					121, 95, 109, 97, 114, 107, 95, 114, 97, 110,
					107, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_short()
			{
				return new byte[22]
				{
					181, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 115, 104, 111,
					114, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_mile()
			{
				return new byte[21]
				{
					180, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 109, 105, 108,
					101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_middle()
			{
				return new byte[23]
				{
					182, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 109, 105, 100,
					100, 108, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_long()
			{
				return new byte[21]
				{
					180, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 108, 111, 110,
					103
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_nige()
			{
				return new byte[26]
				{
					185, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 110, 105, 103, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_senko()
			{
				return new byte[27]
				{
					186, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 115, 101, 110, 107, 111
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_sashi()
			{
				return new byte[27]
				{
					186, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 115, 97, 115, 104, 105
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_oikomi()
			{
				return new byte[28]
				{
					187, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 111, 105, 107, 111, 109, 105
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_ground_turf()
			{
				return new byte[19]
				{
					178, 112, 114, 111, 112, 101, 114, 95, 103, 114,
					111, 117, 110, 100, 95, 116, 117, 114, 102
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_ground_dirt()
			{
				return new byte[19]
				{
					178, 112, 114, 111, 112, 101, 114, 95, 103, 114,
					111, 117, 110, 100, 95, 100, 105, 114, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_motivation()
			{
				return new byte[11]
				{
					170, 109, 111, 116, 105, 118, 97, 116, 105, 111,
					110
				};
			}

			private static ReadOnlySpan<byte> GetSpan_mob_id()
			{
				return new byte[7] { 166, 109, 111, 98, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_win_saddle_id_array()
			{
				return new byte[20]
				{
					179, 119, 105, 110, 95, 115, 97, 100, 100, 108,
					101, 95, 105, 100, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_result_array()
			{
				return new byte[18]
				{
					177, 114, 97, 99, 101, 95, 114, 101, 115, 117,
					108, 116, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_team_id()
			{
				return new byte[8] { 167, 116, 101, 97, 109, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_team_member_id()
			{
				return new byte[15]
				{
					174, 116, 101, 97, 109, 95, 109, 101, 109, 98,
					101, 114, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_item_id_array()
			{
				return new byte[14]
				{
					173, 105, 116, 101, 109, 95, 105, 100, 95, 97,
					114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_motivation_change_flag()
			{
				return new byte[23]
				{
					182, 109, 111, 116, 105, 118, 97, 116, 105, 111,
					110, 95, 99, 104, 97, 110, 103, 101, 95, 102,
					108, 97, 103
				};
			}

			private static ReadOnlySpan<byte> GetSpan_frame_order_change_flag()
			{
				return new byte[24]
				{
					183, 102, 114, 97, 109, 101, 95, 111, 114, 100,
					101, 114, 95, 99, 104, 97, 110, 103, 101, 95,
					102, 108, 97, 103
				};
			}

			private static ReadOnlySpan<byte> GetSpan_team_rank()
			{
				return new byte[10] { 169, 116, 101, 97, 109, 95, 114, 97, 110, 107 };
			}

			private static ReadOnlySpan<byte> GetSpan_single_mode_win_count()
			{
				return new byte[22]
				{
					181, 115, 105, 110, 103, 108, 101, 95, 109, 111,
					100, 101, 95, 119, 105, 110, 95, 99, 111, 117,
					110, 116
				};
			}

			public void Serialize(ref MessagePackWriter writer, RaceHorseData value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(46);
				writer.WriteRaw(GetSpan_viewer_id());
				writer.Write(value.viewer_id);
				writer.WriteRaw(GetSpan_owner_viewer_id());
				writer.Write(value.owner_viewer_id);
				writer.WriteRaw(GetSpan_trainer_name());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.trainer_name, options);
				writer.WriteRaw(GetSpan_owner_trainer_name());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.owner_trainer_name, options);
				writer.WriteRaw(GetSpan_single_mode_chara_id());
				writer.Write(value.single_mode_chara_id);
				writer.WriteRaw(GetSpan_trained_chara_id());
				writer.Write(value.trained_chara_id);
				writer.WriteRaw(GetSpan_nickname_id());
				writer.Write(value.nickname_id);
				writer.WriteRaw(GetSpan_card_id());
				resolver.GetFormatterWithVerify<int?>().Serialize(ref writer, value.card_id, options);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
				writer.WriteRaw(GetSpan_rarity());
				writer.Write(value.rarity);
				writer.WriteRaw(GetSpan_talent_level());
				writer.Write(value.talent_level);
				writer.WriteRaw(GetSpan_frame_order());
				writer.Write(value.frame_order);
				writer.WriteRaw(GetSpan_skill_array());
				resolver.GetFormatterWithVerify<SkillData[]>().Serialize(ref writer, value.skill_array, options);
				writer.WriteRaw(GetSpan_stamina());
				writer.Write(value.stamina);
				writer.WriteRaw(GetSpan_speed());
				writer.Write(value.speed);
				writer.WriteRaw(GetSpan_pow());
				writer.Write(value.pow);
				writer.WriteRaw(GetSpan_guts());
				writer.Write(value.guts);
				writer.WriteRaw(GetSpan_wiz());
				writer.Write(value.wiz);
				writer.WriteRaw(GetSpan_running_style());
				writer.Write(value.running_style);
				writer.WriteRaw(GetSpan_race_dress_id());
				writer.Write(value.race_dress_id);
				writer.WriteRaw(GetSpan_chara_color_type());
				writer.Write(value.chara_color_type);
				writer.WriteRaw(GetSpan_npc_type());
				writer.Write(value.npc_type);
				writer.WriteRaw(GetSpan_final_grade());
				writer.Write(value.final_grade);
				writer.WriteRaw(GetSpan_popularity());
				writer.Write(value.popularity);
				writer.WriteRaw(GetSpan_popularity_mark_rank_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.popularity_mark_rank_array, options);
				writer.WriteRaw(GetSpan_proper_distance_short());
				writer.Write(value.proper_distance_short);
				writer.WriteRaw(GetSpan_proper_distance_mile());
				writer.Write(value.proper_distance_mile);
				writer.WriteRaw(GetSpan_proper_distance_middle());
				writer.Write(value.proper_distance_middle);
				writer.WriteRaw(GetSpan_proper_distance_long());
				writer.Write(value.proper_distance_long);
				writer.WriteRaw(GetSpan_proper_running_style_nige());
				writer.Write(value.proper_running_style_nige);
				writer.WriteRaw(GetSpan_proper_running_style_senko());
				writer.Write(value.proper_running_style_senko);
				writer.WriteRaw(GetSpan_proper_running_style_sashi());
				writer.Write(value.proper_running_style_sashi);
				writer.WriteRaw(GetSpan_proper_running_style_oikomi());
				writer.Write(value.proper_running_style_oikomi);
				writer.WriteRaw(GetSpan_proper_ground_turf());
				writer.Write(value.proper_ground_turf);
				writer.WriteRaw(GetSpan_proper_ground_dirt());
				writer.Write(value.proper_ground_dirt);
				writer.WriteRaw(GetSpan_motivation());
				writer.Write(value.motivation);
				writer.WriteRaw(GetSpan_mob_id());
				writer.Write(value.mob_id);
				writer.WriteRaw(GetSpan_win_saddle_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.win_saddle_id_array, options);
				writer.WriteRaw(GetSpan_race_result_array());
				resolver.GetFormatterWithVerify<RaceHorseDataRaceResult[]>().Serialize(ref writer, value.race_result_array, options);
				writer.WriteRaw(GetSpan_team_id());
				writer.Write(value.team_id);
				writer.WriteRaw(GetSpan_team_member_id());
				writer.Write(value.team_member_id);
				writer.WriteRaw(GetSpan_item_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.item_id_array, options);
				writer.WriteRaw(GetSpan_motivation_change_flag());
				writer.Write(value.motivation_change_flag);
				writer.WriteRaw(GetSpan_frame_order_change_flag());
				writer.Write(value.frame_order_change_flag);
				writer.WriteRaw(GetSpan_team_rank());
				writer.Write(value.team_rank);
				writer.WriteRaw(GetSpan_single_mode_win_count());
				writer.Write(value.single_mode_win_count);
			}

			public RaceHorseData Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				RaceHorseData raceHorseData = new RaceHorseData();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 9:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7592913276890343798L)
						{
							if (key == 7953764171095565684L && span[0] == 107)
							{
								raceHorseData.team_rank = reader.ReadInt32();
								break;
							}
						}
						else if (span[0] == 100)
						{
							raceHorseData.viewer_id = reader.ReadInt64();
							break;
						}
						goto default;
					}
					case 15:
						if (span.SequenceEqual(GetSpan_owner_viewer_id().Slice(1)))
						{
							raceHorseData.owner_viewer_id = reader.ReadInt64();
							break;
						}
						goto default;
					case 12:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6877671105836970612L)
						{
							if (key == 7809088296380555636L && AutomataKeyGen.GetKey(ref span) == 1818588773)
							{
								raceHorseData.talent_level = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 1701667182)
						{
							raceHorseData.trainer_name = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 18:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7448798088697705072L)
						{
							if (key == 8247321762554869615L && span.SequenceEqual(GetSpan_owner_trainer_name().Slice(9)))
							{
								raceHorseData.owner_trainer_name = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
								break;
							}
						}
						else
						{
							ulong key2 = AutomataKeyGen.GetKey(ref span);
							if (key2 != 7594299756608057202L)
							{
								if (key2 == 8463494484690562930L && AutomataKeyGen.GetKey(ref span) == 26226)
								{
									raceHorseData.proper_ground_turf = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 29810)
							{
								raceHorseData.proper_ground_dirt = reader.ReadInt32();
								break;
							}
						}
						goto default;
					}
					case 20:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7232625306583921264L)
						{
							if (key == 7881129389187819891L && span.SequenceEqual(GetSpan_single_mode_chara_id().Slice(9)))
							{
								raceHorseData.single_mode_chara_id = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 6874009731983504233L)
						{
							switch (AutomataKeyGen.GetKey(ref span))
							{
							case 1701603693uL:
								raceHorseData.proper_distance_mile = reader.ReadInt32();
								goto end_IL_0046;
							case 1735290732uL:
								raceHorseData.proper_distance_long = reader.ReadInt32();
								goto end_IL_0046;
							}
						}
						goto default;
					}
					case 16:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6873730456163021428L)
						{
							if (key == 8026363833039808611L && AutomataKeyGen.GetKey(ref span) == 7309475735946817388L)
							{
								raceHorseData.chara_color_type = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 7235419148482865251L)
						{
							raceHorseData.trained_chara_id = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 11:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key <= 8241973712344673139L)
						{
							if (key != 7308604897168157038L)
							{
								if (key == 8241973712344673139L && AutomataKeyGen.GetKey(ref span) == 7954802)
								{
									raceHorseData.skill_array = resolver.GetFormatterWithVerify<SkillData[]>().Deserialize(ref reader, options);
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 6580575)
							{
								raceHorseData.nickname_id = reader.ReadInt32();
								break;
							}
						}
						else if (key != 8243662562020714854L)
						{
							if (key == 8245914331970105958L && AutomataKeyGen.GetKey(ref span) == 7497060)
							{
								raceHorseData.frame_order = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 6644833)
						{
							raceHorseData.final_grade = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 7:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 28263356099092835uL:
							raceHorseData.card_id = resolver.GetFormatterWithVerify<int?>().Deserialize(ref reader, options);
							goto end_IL_0046;
						case 27424471826658419uL:
							raceHorseData.stamina = reader.ReadInt32();
							goto end_IL_0046;
						case 28263356248974708uL:
							raceHorseData.team_id = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 8:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 7235419148482865251uL:
							raceHorseData.chara_id = reader.ReadInt32();
							goto end_IL_0046;
						case 7309475735945834606uL:
							raceHorseData.npc_type = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 6:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 133540892270962uL:
							raceHorseData.rarity = reader.ReadInt32();
							goto end_IL_0046;
						case 110403734630253uL:
							raceHorseData.mob_id = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 5:
						if (AutomataKeyGen.GetKey(ref span) == 431197876339L)
						{
							raceHorseData.speed = reader.ReadInt32();
							break;
						}
						goto default;
					case 3:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 7827312uL:
							raceHorseData.pow = reader.ReadInt32();
							goto end_IL_0046;
						case 8022391uL:
							raceHorseData.wiz = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 4:
						if (AutomataKeyGen.GetKey(ref span) == 1937012071)
						{
							raceHorseData.guts = reader.ReadInt32();
							break;
						}
						goto default;
					case 13:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6873734789852394601L)
						{
							if (key != 6874584755307705714L)
							{
								if (key == 7310015506061418866L && AutomataKeyGen.GetKey(ref span) == 431264592755L)
								{
									raceHorseData.race_dress_id = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 435611595891L)
							{
								raceHorseData.running_style = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 521325933153L)
						{
							raceHorseData.item_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 10:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7598242639782113136L)
						{
							if (key == 7598805632484142957L && AutomataKeyGen.GetKey(ref span) == 28271)
							{
								raceHorseData.motivation = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 31092)
						{
							raceHorseData.popularity = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 26:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7598242639782113136L)
						{
							if (key == 8241431623114912368L && AutomataKeyGen.GetKey(ref span) == 8313477161062133365L)
							{
								ulong key2 = AutomataKeyGen.GetKey(ref span);
								if (key2 != 7954891170380544372L)
								{
									if (key2 == 8314053240663341428L && AutomataKeyGen.GetKey(ref span) == 26984)
									{
										raceHorseData.proper_running_style_sashi = reader.ReadInt32();
										break;
									}
								}
								else if (AutomataKeyGen.GetKey(ref span) == 28523)
								{
									raceHorseData.proper_running_style_senko = reader.ReadInt32();
									break;
								}
							}
						}
						else if (span.SequenceEqual(GetSpan_popularity_mark_rank_array().Slice(9)))
						{
							raceHorseData.popularity_mark_rank_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 21:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7232625306583921264L)
						{
							if (key == 7881129389187819891L && span.SequenceEqual(GetSpan_single_mode_win_count().Slice(9)))
							{
								raceHorseData.single_mode_win_count = reader.ReadInt32();
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_proper_distance_short().Slice(9)))
						{
							raceHorseData.proper_distance_short = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 22:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7232625306583921264L)
						{
							if (key == 7598805632484142957L && span.SequenceEqual(GetSpan_motivation_change_flag().Slice(9)))
							{
								raceHorseData.motivation_change_flag = reader.ReadInt32();
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_proper_distance_middle().Slice(9)))
						{
							raceHorseData.proper_distance_middle = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 25:
						if (span.SequenceEqual(GetSpan_proper_running_style_nige().Slice(1)))
						{
							raceHorseData.proper_running_style_nige = reader.ReadInt32();
							break;
						}
						goto default;
					case 27:
						if (span.SequenceEqual(GetSpan_proper_running_style_oikomi().Slice(1)))
						{
							raceHorseData.proper_running_style_oikomi = reader.ReadInt32();
							break;
						}
						goto default;
					case 19:
						if (span.SequenceEqual(GetSpan_win_saddle_id_array().Slice(1)))
						{
							raceHorseData.win_saddle_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 17:
						if (span.SequenceEqual(GetSpan_race_result_array().Slice(1)))
						{
							raceHorseData.race_result_array = resolver.GetFormatterWithVerify<RaceHorseDataRaceResult[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 14:
						if (span.SequenceEqual(GetSpan_team_member_id().Slice(1)))
						{
							raceHorseData.team_member_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 23:
						{
							if (span.SequenceEqual(GetSpan_frame_order_change_flag().Slice(1)))
							{
								raceHorseData.frame_order_change_flag = reader.ReadInt32();
								break;
							}
							goto default;
						}
						end_IL_0046:
						break;
					}
				}
				reader.Depth--;
				return raceHorseData;
			}
		}

		internal sealed class RaceHorseDataRaceResultFormatter : IMessagePackFormatter<RaceHorseDataRaceResult>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_turn()
			{
				return new byte[5] { 164, 116, 117, 114, 110 };
			}

			private static ReadOnlySpan<byte> GetSpan_program_id()
			{
				return new byte[11]
				{
					170, 112, 114, 111, 103, 114, 97, 109, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_result_rank()
			{
				return new byte[12]
				{
					171, 114, 101, 115, 117, 108, 116, 95, 114, 97,
					110, 107
				};
			}

			public void Serialize(ref MessagePackWriter writer, RaceHorseDataRaceResult value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_turn());
				writer.Write(value.turn);
				writer.WriteRaw(GetSpan_program_id());
				writer.Write(value.program_id);
				writer.WriteRaw(GetSpan_result_rank());
				writer.Write(value.result_rank);
			}

			public RaceHorseDataRaceResult Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				RaceHorseDataRaceResult raceHorseDataRaceResult = new RaceHorseDataRaceResult();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 4)
					{
						if (length != 10)
						{
							if (length == 11 && span.SequenceEqual(GetSpan_result_rank().Slice(1)))
							{
								raceHorseDataRaceResult.result_rank = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_program_id().Slice(1)))
						{
							raceHorseDataRaceResult.program_id = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 1852994932)
					{
						raceHorseDataRaceResult.turn = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return raceHorseDataRaceResult;
			}
		}

		internal sealed class RaceResultInfoFormatter : IMessagePackFormatter<RaceResultInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_race_instance_id()
			{
				return new byte[17]
				{
					176, 114, 97, 99, 101, 95, 105, 110, 115, 116,
					97, 110, 99, 101, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_horse_data_array()
			{
				return new byte[22]
				{
					181, 114, 97, 99, 101, 95, 104, 111, 114, 115,
					101, 95, 100, 97, 116, 97, 95, 97, 114, 114,
					97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_season()
			{
				return new byte[7] { 166, 115, 101, 97, 115, 111, 110 };
			}

			private static ReadOnlySpan<byte> GetSpan_weather()
			{
				return new byte[8] { 167, 119, 101, 97, 116, 104, 101, 114 };
			}

			private static ReadOnlySpan<byte> GetSpan_ground_condition()
			{
				return new byte[17]
				{
					176, 103, 114, 111, 117, 110, 100, 95, 99, 111,
					110, 100, 105, 116, 105, 111, 110
				};
			}

			private static ReadOnlySpan<byte> GetSpan_random_seed()
			{
				return new byte[12]
				{
					171, 114, 97, 110, 100, 111, 109, 95, 115, 101,
					101, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_scenario()
			{
				return new byte[14]
				{
					173, 114, 97, 99, 101, 95, 115, 99, 101, 110,
					97, 114, 105, 111
				};
			}

			public void Serialize(ref MessagePackWriter writer, RaceResultInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(7);
				writer.WriteRaw(GetSpan_race_instance_id());
				writer.Write(value.race_instance_id);
				writer.WriteRaw(GetSpan_race_horse_data_array());
				resolver.GetFormatterWithVerify<RaceHorseData[]>().Serialize(ref writer, value.race_horse_data_array, options);
				writer.WriteRaw(GetSpan_season());
				writer.Write(value.season);
				writer.WriteRaw(GetSpan_weather());
				writer.Write(value.weather);
				writer.WriteRaw(GetSpan_ground_condition());
				writer.Write(value.ground_condition);
				writer.WriteRaw(GetSpan_random_seed());
				writer.Write(value.random_seed);
				writer.WriteRaw(GetSpan_race_scenario());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.race_scenario, options);
			}

			public RaceResultInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				RaceResultInfo raceResultInfo = new RaceResultInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length <= 11)
					{
						if (length != 6)
						{
							if (length != 7)
							{
								if (length == 11 && span.SequenceEqual(GetSpan_random_seed().Slice(1)))
								{
									raceResultInfo.random_seed = reader.ReadInt32();
									continue;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 32199646648558967L)
							{
								raceResultInfo.weather = reader.ReadInt32();
								continue;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 121424956188019L)
						{
							raceResultInfo.season = reader.ReadInt32();
							continue;
						}
					}
					else if (length != 13)
					{
						if (length != 16)
						{
							if (length == 21 && span.SequenceEqual(GetSpan_race_horse_data_array().Slice(1)))
							{
								raceResultInfo.race_horse_data_array = resolver.GetFormatterWithVerify<RaceHorseData[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 7160552358121796199L)
							{
								if (key == 8317701420243706226L && AutomataKeyGen.GetKey(ref span) == 7235419165411926388L)
								{
									raceResultInfo.race_instance_id = reader.ReadInt32();
									continue;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 7957695015292268143L)
							{
								raceResultInfo.ground_condition = reader.ReadInt32();
								continue;
							}
						}
					}
					else if (span.SequenceEqual(GetSpan_race_scenario().Slice(1)))
					{
						raceResultInfo.race_scenario = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return raceResultInfo;
			}
		}

		internal sealed class RaceRewardDataFormatter : IMessagePackFormatter<RaceRewardData>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_item_type()
			{
				return new byte[10] { 169, 105, 116, 101, 109, 95, 116, 121, 112, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_item_id()
			{
				return new byte[8] { 167, 105, 116, 101, 109, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_item_num()
			{
				return new byte[9] { 168, 105, 116, 101, 109, 95, 110, 117, 109 };
			}

			public void Serialize(ref MessagePackWriter writer, RaceRewardData value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_item_type());
				writer.Write(value.item_type);
				writer.WriteRaw(GetSpan_item_id());
				writer.Write(value.item_id);
				writer.WriteRaw(GetSpan_item_num());
				writer.Write(value.item_num);
			}

			public RaceRewardData Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				RaceRewardData raceRewardData = new RaceRewardData();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 9:
						if (span.SequenceEqual(GetSpan_item_type().Slice(1)))
						{
							raceRewardData.item_type = reader.ReadInt32();
							break;
						}
						goto default;
					case 7:
						if (AutomataKeyGen.GetKey(ref span) == 28263356249240681L)
						{
							raceRewardData.item_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 7887331678545605737L)
						{
							raceRewardData.item_num = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return raceRewardData;
			}
		}

		internal sealed class ReleaseNumInfoFormatter : IMessagePackFormatter<ReleaseNumInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_voice_num()
			{
				return new byte[10] { 169, 118, 111, 105, 99, 101, 95, 110, 117, 109 };
			}

			private static ReadOnlySpan<byte> GetSpan_act_num()
			{
				return new byte[8] { 167, 97, 99, 116, 95, 110, 117, 109 };
			}

			private static ReadOnlySpan<byte> GetSpan_good_end_num()
			{
				return new byte[13]
				{
					172, 103, 111, 111, 100, 95, 101, 110, 100, 95,
					110, 117, 109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_music_num()
			{
				return new byte[10] { 169, 109, 117, 115, 105, 99, 95, 110, 117, 109 };
			}

			private static ReadOnlySpan<byte> GetSpan_main_story_num()
			{
				return new byte[15]
				{
					174, 109, 97, 105, 110, 95, 115, 116, 111, 114,
					121, 95, 110, 117, 109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_chara_story_num()
			{
				return new byte[16]
				{
					175, 99, 104, 97, 114, 97, 95, 115, 116, 111,
					114, 121, 95, 110, 117, 109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_card_num()
			{
				return new byte[9] { 168, 99, 97, 114, 100, 95, 110, 117, 109 };
			}

			private static ReadOnlySpan<byte> GetSpan_support_card_num()
			{
				return new byte[17]
				{
					176, 115, 117, 112, 112, 111, 114, 116, 95, 99,
					97, 114, 100, 95, 110, 117, 109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_chara_event_num()
			{
				return new byte[16]
				{
					175, 99, 104, 97, 114, 97, 95, 101, 118, 101,
					110, 116, 95, 110, 117, 109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_support_event_num()
			{
				return new byte[18]
				{
					177, 115, 117, 112, 112, 111, 114, 116, 95, 101,
					118, 101, 110, 116, 95, 110, 117, 109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_scenario_event_num()
			{
				return new byte[19]
				{
					178, 115, 99, 101, 110, 97, 114, 105, 111, 95,
					101, 118, 101, 110, 116, 95, 110, 117, 109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_home_event_num()
			{
				return new byte[15]
				{
					174, 104, 111, 109, 101, 95, 101, 118, 101, 110,
					116, 95, 110, 117, 109
				};
			}

			public void Serialize(ref MessagePackWriter writer, ReleaseNumInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(12);
				writer.WriteRaw(GetSpan_voice_num());
				writer.Write(value.voice_num);
				writer.WriteRaw(GetSpan_act_num());
				writer.Write(value.act_num);
				writer.WriteRaw(GetSpan_good_end_num());
				writer.Write(value.good_end_num);
				writer.WriteRaw(GetSpan_music_num());
				writer.Write(value.music_num);
				writer.WriteRaw(GetSpan_main_story_num());
				writer.Write(value.main_story_num);
				writer.WriteRaw(GetSpan_chara_story_num());
				writer.Write(value.chara_story_num);
				writer.WriteRaw(GetSpan_card_num());
				writer.Write(value.card_num);
				writer.WriteRaw(GetSpan_support_card_num());
				writer.Write(value.support_card_num);
				writer.WriteRaw(GetSpan_chara_event_num());
				writer.Write(value.chara_event_num);
				writer.WriteRaw(GetSpan_support_event_num());
				writer.Write(value.support_event_num);
				writer.WriteRaw(GetSpan_scenario_event_num());
				writer.Write(value.scenario_event_num);
				writer.WriteRaw(GetSpan_home_event_num());
				writer.Write(value.home_event_num);
			}

			public ReleaseNumInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				ReleaseNumInfo releaseNumInfo = new ReleaseNumInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 9:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 8461805630451316077L)
						{
							if (key == 8461805638939930486L && span[0] == 109)
							{
								releaseNumInfo.voice_num = reader.ReadInt32();
								break;
							}
						}
						else if (span[0] == 109)
						{
							releaseNumInfo.music_num = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 7:
						if (AutomataKeyGen.GetKey(ref span) == 30809889369776993L)
						{
							releaseNumInfo.act_num = reader.ReadInt32();
							break;
						}
						goto default;
					case 12:
						if (span.SequenceEqual(GetSpan_good_end_num().Slice(1)))
						{
							releaseNumInfo.good_end_num = reader.ReadInt32();
							break;
						}
						goto default;
					case 14:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7311142505480548200L)
						{
							if (key == 8031170889219924333L && AutomataKeyGen.GetKey(ref span) == 120351130351986L)
							{
								releaseNumInfo.main_story_num = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 120351130350702L)
						{
							releaseNumInfo.home_event_num = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 15:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 8391155402856818787L)
						{
							if (key == 8531329941258725475L && AutomataKeyGen.GetKey(ref span) == 30809889369779813L)
							{
								releaseNumInfo.chara_event_num = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 30809889370108527L)
						{
							releaseNumInfo.chara_story_num = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 7887331678395457891L)
						{
							releaseNumInfo.card_num = reader.ReadInt32();
							break;
						}
						goto default;
					case 16:
						if (span.SequenceEqual(GetSpan_support_card_num().Slice(1)))
						{
							releaseNumInfo.support_card_num = reader.ReadInt32();
							break;
						}
						goto default;
					case 17:
						if (span.SequenceEqual(GetSpan_support_event_num().Slice(1)))
						{
							releaseNumInfo.support_event_num = reader.ReadInt32();
							break;
						}
						goto default;
					case 18:
						if (span.SequenceEqual(GetSpan_scenario_event_num().Slice(1)))
						{
							releaseNumInfo.scenario_event_num = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return releaseNumInfo;
			}
		}

		internal sealed class ResponseCommonFormatter : IMessagePackFormatter<ResponseCommon>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_data_headers()
			{
				return new byte[13]
				{
					172, 100, 97, 116, 97, 95, 104, 101, 97, 100,
					101, 114, 115
				};
			}

			public void Serialize(ref MessagePackWriter writer, ResponseCommon value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(1);
				writer.WriteRaw(GetSpan_data_headers());
				resolver.GetFormatterWithVerify<DataHeader>().Serialize(ref writer, value.data_headers, options);
			}

			public ResponseCommon Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				ResponseCommon responseCommon = new ResponseCommon();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					if (span.Length != 12 || !span.SequenceEqual(GetSpan_data_headers().Slice(1)))
					{
						reader.Skip();
					}
					else
					{
						responseCommon.data_headers = resolver.GetFormatterWithVerify<DataHeader>().Deserialize(ref reader, options);
					}
				}
				reader.Depth--;
				return responseCommon;
			}
		}

		internal sealed class RoomMatchRaceStartResponseFormatter : IMessagePackFormatter<global::Gallop.RoomMatchRaceStartResponse>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_data()
			{
				return new byte[5] { 164, 100, 97, 116, 97 };
			}

			public void Serialize(ref MessagePackWriter writer, global::Gallop.RoomMatchRaceStartResponse value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(1);
				writer.WriteRaw(GetSpan_data());
				resolver.GetFormatterWithVerify<global::Gallop.RoomMatchRaceStartResponse.CommonResponse>().Serialize(ref writer, value.data, options);
			}

			public global::Gallop.RoomMatchRaceStartResponse Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				global::Gallop.RoomMatchRaceStartResponse roomMatchRaceStartResponse = new global::Gallop.RoomMatchRaceStartResponse();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					if (span.Length != 4 || AutomataKeyGen.GetKey(ref span) != 1635017060)
					{
						reader.Skip();
					}
					else
					{
						roomMatchRaceStartResponse.data = resolver.GetFormatterWithVerify<global::Gallop.RoomMatchRaceStartResponse.CommonResponse>().Deserialize(ref reader, options);
					}
				}
				reader.Depth--;
				return roomMatchRaceStartResponse;
			}
		}

		internal sealed class SingleModeArcCommandInfoFormatter : IMessagePackFormatter<SingleModeArcCommandInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_type()
			{
				return new byte[13]
				{
					172, 99, 111, 109, 109, 97, 110, 100, 95, 116,
					121, 112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_id()
			{
				return new byte[11]
				{
					170, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_params_inc_dec_info_array()
			{
				return new byte[26]
				{
					185, 112, 97, 114, 97, 109, 115, 95, 105, 110,
					99, 95, 100, 101, 99, 95, 105, 110, 102, 111,
					95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_add_global_exp()
			{
				return new byte[15]
				{
					174, 97, 100, 100, 95, 103, 108, 111, 98, 97,
					108, 95, 101, 120, 112
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeArcCommandInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(4);
				writer.WriteRaw(GetSpan_command_type());
				writer.Write(value.command_type);
				writer.WriteRaw(GetSpan_command_id());
				writer.Write(value.command_id);
				writer.WriteRaw(GetSpan_params_inc_dec_info_array());
				resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Serialize(ref writer, value.params_inc_dec_info_array, options);
				writer.WriteRaw(GetSpan_add_global_exp());
				writer.Write(value.add_global_exp);
			}

			public SingleModeArcCommandInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeArcCommandInfo singleModeArcCommandInfo = new SingleModeArcCommandInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 12:
						if (span.SequenceEqual(GetSpan_command_type().Slice(1)))
						{
							singleModeArcCommandInfo.command_type = reader.ReadInt32();
							break;
						}
						goto default;
					case 10:
						if (span.SequenceEqual(GetSpan_command_id().Slice(1)))
						{
							singleModeArcCommandInfo.command_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 25:
						if (span.SequenceEqual(GetSpan_params_inc_dec_info_array().Slice(1)))
						{
							singleModeArcCommandInfo.params_inc_dec_info_array = resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 14:
						if (span.SequenceEqual(GetSpan_add_global_exp().Slice(1)))
						{
							singleModeArcCommandInfo.add_global_exp = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleModeArcCommandInfo;
			}
		}

		internal sealed class SingleModeArcDataSetFormatter : IMessagePackFormatter<SingleModeArcDataSet>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_arc_info()
			{
				return new byte[9] { 168, 97, 114, 99, 95, 105, 110, 102, 111 };
			}

			private static ReadOnlySpan<byte> GetSpan_arc_rival_array()
			{
				return new byte[16]
				{
					175, 97, 114, 99, 95, 114, 105, 118, 97, 108,
					95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_rival_race_info_array()
			{
				return new byte[22]
				{
					181, 114, 105, 118, 97, 108, 95, 114, 97, 99,
					101, 95, 105, 110, 102, 111, 95, 97, 114, 114,
					97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_selection_info()
			{
				return new byte[15]
				{
					174, 115, 101, 108, 101, 99, 116, 105, 111, 110,
					95, 105, 110, 102, 111
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_history_array()
			{
				return new byte[19]
				{
					178, 114, 97, 99, 101, 95, 104, 105, 115, 116,
					111, 114, 121, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_info_array()
			{
				return new byte[19]
				{
					178, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					110, 102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_evaluation_info_array()
			{
				return new byte[22]
				{
					181, 101, 118, 97, 108, 117, 97, 116, 105, 111,
					110, 95, 105, 110, 102, 111, 95, 97, 114, 114,
					97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_not_up_arc_parameter_info()
			{
				return new byte[26]
				{
					185, 110, 111, 116, 95, 117, 112, 95, 97, 114,
					99, 95, 112, 97, 114, 97, 109, 101, 116, 101,
					114, 95, 105, 110, 102, 111
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeArcDataSet value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(8);
				writer.WriteRaw(GetSpan_arc_info());
				resolver.GetFormatterWithVerify<SingleModeArcInfo>().Serialize(ref writer, value.arc_info, options);
				writer.WriteRaw(GetSpan_arc_rival_array());
				resolver.GetFormatterWithVerify<SingleModeArcRival[]>().Serialize(ref writer, value.arc_rival_array, options);
				writer.WriteRaw(GetSpan_rival_race_info_array());
				resolver.GetFormatterWithVerify<SingleModeRivalRaceInfo[]>().Serialize(ref writer, value.rival_race_info_array, options);
				writer.WriteRaw(GetSpan_selection_info());
				resolver.GetFormatterWithVerify<SingleModeArcSelectionInfo>().Serialize(ref writer, value.selection_info, options);
				writer.WriteRaw(GetSpan_race_history_array());
				resolver.GetFormatterWithVerify<SingleModeArcRaceHistory[]>().Serialize(ref writer, value.race_history_array, options);
				writer.WriteRaw(GetSpan_command_info_array());
				resolver.GetFormatterWithVerify<SingleModeArcCommandInfo[]>().Serialize(ref writer, value.command_info_array, options);
				writer.WriteRaw(GetSpan_evaluation_info_array());
				resolver.GetFormatterWithVerify<ArcEvaluationInfo[]>().Serialize(ref writer, value.evaluation_info_array, options);
				writer.WriteRaw(GetSpan_not_up_arc_parameter_info());
				resolver.GetFormatterWithVerify<NotUpArcParameterInfo>().Serialize(ref writer, value.not_up_arc_parameter_info, options);
			}

			public SingleModeArcDataSet Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeArcDataSet singleModeArcDataSet = new SingleModeArcDataSet();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 8027224784685462113L)
						{
							singleModeArcDataSet.arc_info = resolver.GetFormatterWithVerify<SingleModeArcInfo>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 15:
						if (span.SequenceEqual(GetSpan_arc_rival_array().Slice(1)))
						{
							singleModeArcDataSet.arc_rival_array = resolver.GetFormatterWithVerify<SingleModeArcRival[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 21:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7021779688120281458L)
						{
							if (key == 7598805628238263909L && span.SequenceEqual(GetSpan_evaluation_info_array().Slice(9)))
							{
								singleModeArcDataSet.evaluation_info_array = resolver.GetFormatterWithVerify<ArcEvaluationInfo[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_rival_race_info_array().Slice(9)))
						{
							singleModeArcDataSet.rival_race_info_array = resolver.GetFormatterWithVerify<SingleModeRivalRaceInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 14:
						if (span.SequenceEqual(GetSpan_selection_info().Slice(1)))
						{
							singleModeArcDataSet.selection_info = resolver.GetFormatterWithVerify<SingleModeArcSelectionInfo>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 18:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6873740296000991075L)
						{
							if (key == 8316292945848525170L && span.SequenceEqual(GetSpan_race_history_array().Slice(9)))
							{
								singleModeArcDataSet.race_history_array = resolver.GetFormatterWithVerify<SingleModeArcRaceHistory[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_command_info_array().Slice(9)))
						{
							singleModeArcDataSet.command_info_array = resolver.GetFormatterWithVerify<SingleModeArcCommandInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 25:
						if (span.SequenceEqual(GetSpan_not_up_arc_parameter_info().Slice(1)))
						{
							singleModeArcDataSet.not_up_arc_parameter_info = resolver.GetFormatterWithVerify<NotUpArcParameterInfo>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleModeArcDataSet;
			}
		}

		internal sealed class SingleModeArcInfoFormatter : IMessagePackFormatter<SingleModeArcInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_approval_rate()
			{
				return new byte[14]
				{
					173, 97, 112, 112, 114, 111, 118, 97, 108, 95,
					114, 97, 116, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_potential_array()
			{
				return new byte[16]
				{
					175, 112, 111, 116, 101, 110, 116, 105, 97, 108,
					95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_global_exp()
			{
				return new byte[11]
				{
					170, 103, 108, 111, 98, 97, 108, 95, 101, 120,
					112
				};
			}

			private static ReadOnlySpan<byte> GetSpan_sp_tag_boost_type()
			{
				return new byte[18]
				{
					177, 115, 112, 95, 116, 97, 103, 95, 98, 111,
					111, 115, 116, 95, 116, 121, 112, 101
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeArcInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(4);
				writer.WriteRaw(GetSpan_approval_rate());
				writer.Write(value.approval_rate);
				writer.WriteRaw(GetSpan_potential_array());
				resolver.GetFormatterWithVerify<ArcPotential[]>().Serialize(ref writer, value.potential_array, options);
				writer.WriteRaw(GetSpan_global_exp());
				writer.Write(value.global_exp);
				writer.WriteRaw(GetSpan_sp_tag_boost_type());
				writer.Write(value.sp_tag_boost_type);
			}

			public SingleModeArcInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeArcInfo singleModeArcInfo = new SingleModeArcInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 13:
						if (span.SequenceEqual(GetSpan_approval_rate().Slice(1)))
						{
							singleModeArcInfo.approval_rate = reader.ReadInt32();
							break;
						}
						goto default;
					case 15:
						if (span.SequenceEqual(GetSpan_potential_array().Slice(1)))
						{
							singleModeArcInfo.potential_array = resolver.GetFormatterWithVerify<ArcPotential[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 10:
						if (span.SequenceEqual(GetSpan_global_exp().Slice(1)))
						{
							singleModeArcInfo.global_exp = reader.ReadInt32();
							break;
						}
						goto default;
					case 17:
						if (span.SequenceEqual(GetSpan_sp_tag_boost_type().Slice(1)))
						{
							singleModeArcInfo.sp_tag_boost_type = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleModeArcInfo;
			}
		}

		internal sealed class SingleModeArcPotentialProgressFormatter : IMessagePackFormatter<SingleModeArcPotentialProgress>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_condition_id()
			{
				return new byte[13]
				{
					172, 99, 111, 110, 100, 105, 116, 105, 111, 110,
					95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_total_count()
			{
				return new byte[12]
				{
					171, 116, 111, 116, 97, 108, 95, 99, 111, 117,
					110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_current_count()
			{
				return new byte[14]
				{
					173, 99, 117, 114, 114, 101, 110, 116, 95, 99,
					111, 117, 110, 116
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeArcPotentialProgress value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_condition_id());
				writer.Write(value.condition_id);
				writer.WriteRaw(GetSpan_total_count());
				writer.Write(value.total_count);
				writer.WriteRaw(GetSpan_current_count());
				writer.Write(value.current_count);
			}

			public SingleModeArcPotentialProgress Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeArcPotentialProgress singleModeArcPotentialProgress = new SingleModeArcPotentialProgress();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 12:
						if (span.SequenceEqual(GetSpan_condition_id().Slice(1)))
						{
							singleModeArcPotentialProgress.condition_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 11:
						if (span.SequenceEqual(GetSpan_total_count().Slice(1)))
						{
							singleModeArcPotentialProgress.total_count = reader.ReadInt32();
							break;
						}
						goto default;
					case 13:
						if (span.SequenceEqual(GetSpan_current_count().Slice(1)))
						{
							singleModeArcPotentialProgress.current_count = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleModeArcPotentialProgress;
			}
		}

		internal sealed class SingleModeArcRaceHistoryFormatter : IMessagePackFormatter<SingleModeArcRaceHistory>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_race_num()
			{
				return new byte[9] { 168, 114, 97, 99, 101, 95, 110, 117, 109 };
			}

			private static ReadOnlySpan<byte> GetSpan_turn()
			{
				return new byte[5] { 164, 116, 117, 114, 110 };
			}

			private static ReadOnlySpan<byte> GetSpan_result_rank()
			{
				return new byte[12]
				{
					171, 114, 101, 115, 117, 108, 116, 95, 114, 97,
					110, 107
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeArcRaceHistory value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_race_num());
				writer.Write(value.race_num);
				writer.WriteRaw(GetSpan_turn());
				writer.Write(value.turn);
				writer.WriteRaw(GetSpan_result_rank());
				writer.Write(value.result_rank);
			}

			public SingleModeArcRaceHistory Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeArcRaceHistory singleModeArcRaceHistory = new SingleModeArcRaceHistory();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 4)
					{
						if (length != 8)
						{
							if (length == 11 && span.SequenceEqual(GetSpan_result_rank().Slice(1)))
							{
								singleModeArcRaceHistory.result_rank = reader.ReadInt32();
								continue;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 7887331678411252082L)
						{
							singleModeArcRaceHistory.race_num = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 1852994932)
					{
						singleModeArcRaceHistory.turn = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeArcRaceHistory;
			}
		}

		internal sealed class SingleModeArcRivalFormatter : IMessagePackFormatter<SingleModeArcRival>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_speed()
			{
				return new byte[6] { 165, 115, 112, 101, 101, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_stamina()
			{
				return new byte[8] { 167, 115, 116, 97, 109, 105, 110, 97 };
			}

			private static ReadOnlySpan<byte> GetSpan_power()
			{
				return new byte[6] { 165, 112, 111, 119, 101, 114 };
			}

			private static ReadOnlySpan<byte> GetSpan_guts()
			{
				return new byte[5] { 164, 103, 117, 116, 115 };
			}

			private static ReadOnlySpan<byte> GetSpan_wiz()
			{
				return new byte[4] { 163, 119, 105, 122 };
			}

			private static ReadOnlySpan<byte> GetSpan_command_id()
			{
				return new byte[11]
				{
					170, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_rival_boost()
			{
				return new byte[12]
				{
					171, 114, 105, 118, 97, 108, 95, 98, 111, 111,
					115, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_star_lv()
			{
				return new byte[8] { 167, 115, 116, 97, 114, 95, 108, 118 };
			}

			private static ReadOnlySpan<byte> GetSpan_rank()
			{
				return new byte[5] { 164, 114, 97, 110, 107 };
			}

			private static ReadOnlySpan<byte> GetSpan_approval_point()
			{
				return new byte[15]
				{
					174, 97, 112, 112, 114, 111, 118, 97, 108, 95,
					112, 111, 105, 110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_potential_array()
			{
				return new byte[16]
				{
					175, 112, 111, 116, 101, 110, 116, 105, 97, 108,
					95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_selection_peff_array()
			{
				return new byte[21]
				{
					180, 115, 101, 108, 101, 99, 116, 105, 111, 110,
					95, 112, 101, 102, 102, 95, 97, 114, 114, 97,
					121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeArcRival value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(13);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
				writer.WriteRaw(GetSpan_speed());
				writer.Write(value.speed);
				writer.WriteRaw(GetSpan_stamina());
				writer.Write(value.stamina);
				writer.WriteRaw(GetSpan_power());
				writer.Write(value.power);
				writer.WriteRaw(GetSpan_guts());
				writer.Write(value.guts);
				writer.WriteRaw(GetSpan_wiz());
				writer.Write(value.wiz);
				writer.WriteRaw(GetSpan_command_id());
				writer.Write(value.command_id);
				writer.WriteRaw(GetSpan_rival_boost());
				writer.Write(value.rival_boost);
				writer.WriteRaw(GetSpan_star_lv());
				writer.Write(value.star_lv);
				writer.WriteRaw(GetSpan_rank());
				writer.Write(value.rank);
				writer.WriteRaw(GetSpan_approval_point());
				writer.Write(value.approval_point);
				writer.WriteRaw(GetSpan_potential_array());
				resolver.GetFormatterWithVerify<ArcRivalPotential[]>().Serialize(ref writer, value.potential_array, options);
				writer.WriteRaw(GetSpan_selection_peff_array());
				resolver.GetFormatterWithVerify<ArcSelectionPeff[]>().Serialize(ref writer, value.selection_peff_array, options);
			}

			public SingleModeArcRival Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeArcRival singleModeArcRival = new SingleModeArcRival();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 7235419148482865251L)
						{
							singleModeArcRival.chara_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 5:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 431197876339uL:
							singleModeArcRival.speed = reader.ReadInt32();
							goto end_IL_0046;
						case 491328597872uL:
							singleModeArcRival.power = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 7:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 27424471826658419uL:
							singleModeArcRival.stamina = reader.ReadInt32();
							goto end_IL_0046;
						case 33333204448539763uL:
							singleModeArcRival.star_lv = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 4:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 1937012071uL:
							singleModeArcRival.guts = reader.ReadInt32();
							goto end_IL_0046;
						case 1802396018uL:
							singleModeArcRival.rank = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 3:
						if (AutomataKeyGen.GetKey(ref span) == 8022391)
						{
							singleModeArcRival.wiz = reader.ReadInt32();
							break;
						}
						goto default;
					case 10:
						if (span.SequenceEqual(GetSpan_command_id().Slice(1)))
						{
							singleModeArcRival.command_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 11:
						if (span.SequenceEqual(GetSpan_rival_boost().Slice(1)))
						{
							singleModeArcRival.rival_boost = reader.ReadInt32();
							break;
						}
						goto default;
					case 14:
						if (span.SequenceEqual(GetSpan_approval_point().Slice(1)))
						{
							singleModeArcRival.approval_point = reader.ReadInt32();
							break;
						}
						goto default;
					case 15:
						if (span.SequenceEqual(GetSpan_potential_array().Slice(1)))
						{
							singleModeArcRival.potential_array = resolver.GetFormatterWithVerify<ArcRivalPotential[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 20:
						{
							if (span.SequenceEqual(GetSpan_selection_peff_array().Slice(1)))
							{
								singleModeArcRival.selection_peff_array = resolver.GetFormatterWithVerify<ArcSelectionPeff[]>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						}
						end_IL_0046:
						break;
					}
				}
				reader.Depth--;
				return singleModeArcRival;
			}
		}

		internal sealed class SingleModeArcSelectionInfoFormatter : IMessagePackFormatter<SingleModeArcSelectionInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_all_win_approval_point()
			{
				return new byte[23]
				{
					182, 97, 108, 108, 95, 119, 105, 110, 95, 97,
					112, 112, 114, 111, 118, 97, 108, 95, 112, 111,
					105, 110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_params_inc_dec_info_array()
			{
				return new byte[26]
				{
					185, 112, 97, 114, 97, 109, 115, 95, 105, 110,
					99, 95, 100, 101, 99, 95, 105, 110, 102, 111,
					95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_selection_rival_info_array()
			{
				return new byte[27]
				{
					186, 115, 101, 108, 101, 99, 116, 105, 111, 110,
					95, 114, 105, 118, 97, 108, 95, 105, 110, 102,
					111, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_is_special_match()
			{
				return new byte[17]
				{
					176, 105, 115, 95, 115, 112, 101, 99, 105, 97,
					108, 95, 109, 97, 116, 99, 104
				};
			}

			private static ReadOnlySpan<byte> GetSpan_bonus_params_inc_dec_info_array()
			{
				return new byte[32]
				{
					191, 98, 111, 110, 117, 115, 95, 112, 97, 114,
					97, 109, 115, 95, 105, 110, 99, 95, 100, 101,
					99, 95, 105, 110, 102, 111, 95, 97, 114, 114,
					97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeArcSelectionInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(5);
				writer.WriteRaw(GetSpan_all_win_approval_point());
				writer.Write(value.all_win_approval_point);
				writer.WriteRaw(GetSpan_params_inc_dec_info_array());
				resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Serialize(ref writer, value.params_inc_dec_info_array, options);
				writer.WriteRaw(GetSpan_selection_rival_info_array());
				resolver.GetFormatterWithVerify<SingleModeArcSelectionRivalInfo[]>().Serialize(ref writer, value.selection_rival_info_array, options);
				writer.WriteRaw(GetSpan_is_special_match());
				writer.Write(value.is_special_match);
				writer.WriteRaw(GetSpan_bonus_params_inc_dec_info_array());
				resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Serialize(ref writer, value.bonus_params_inc_dec_info_array, options);
			}

			public SingleModeArcSelectionInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeArcSelectionInfo singleModeArcSelectionInfo = new SingleModeArcSelectionInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 22:
						if (span.SequenceEqual(GetSpan_all_win_approval_point().Slice(1)))
						{
							singleModeArcSelectionInfo.all_win_approval_point = reader.ReadInt32();
							break;
						}
						goto default;
					case 25:
						if (span.SequenceEqual(GetSpan_params_inc_dec_info_array().Slice(1)))
						{
							singleModeArcSelectionInfo.params_inc_dec_info_array = resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 26:
						if (span.SequenceEqual(GetSpan_selection_rival_info_array().Slice(1)))
						{
							singleModeArcSelectionInfo.selection_rival_info_array = resolver.GetFormatterWithVerify<SingleModeArcSelectionRivalInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 16:
						if (span.SequenceEqual(GetSpan_is_special_match().Slice(1)))
						{
							singleModeArcSelectionInfo.is_special_match = reader.ReadInt32();
							break;
						}
						goto default;
					case 31:
						if (span.SequenceEqual(GetSpan_bonus_params_inc_dec_info_array().Slice(1)))
						{
							singleModeArcSelectionInfo.bonus_params_inc_dec_info_array = resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleModeArcSelectionInfo;
			}
		}

		internal sealed class SingleModeArcSelectionRivalInfoFormatter : IMessagePackFormatter<SingleModeArcSelectionRivalInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_mark()
			{
				return new byte[5] { 164, 109, 97, 114, 107 };
			}

			private static ReadOnlySpan<byte> GetSpan_win_approval_point()
			{
				return new byte[19]
				{
					178, 119, 105, 110, 95, 97, 112, 112, 114, 111,
					118, 97, 108, 95, 112, 111, 105, 110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_lose_approval_point()
			{
				return new byte[20]
				{
					179, 108, 111, 115, 101, 95, 97, 112, 112, 114,
					111, 118, 97, 108, 95, 112, 111, 105, 110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_rival_win_approval_point()
			{
				return new byte[25]
				{
					184, 114, 105, 118, 97, 108, 95, 119, 105, 110,
					95, 97, 112, 112, 114, 111, 118, 97, 108, 95,
					112, 111, 105, 110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_rival_lose_approval_point()
			{
				return new byte[26]
				{
					185, 114, 105, 118, 97, 108, 95, 108, 111, 115,
					101, 95, 97, 112, 112, 114, 111, 118, 97, 108,
					95, 112, 111, 105, 110, 116
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeArcSelectionRivalInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(6);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
				writer.WriteRaw(GetSpan_mark());
				writer.Write(value.mark);
				writer.WriteRaw(GetSpan_win_approval_point());
				writer.Write(value.win_approval_point);
				writer.WriteRaw(GetSpan_lose_approval_point());
				writer.Write(value.lose_approval_point);
				writer.WriteRaw(GetSpan_rival_win_approval_point());
				writer.Write(value.rival_win_approval_point);
				writer.WriteRaw(GetSpan_rival_lose_approval_point());
				writer.Write(value.rival_lose_approval_point);
			}

			public SingleModeArcSelectionRivalInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeArcSelectionRivalInfo singleModeArcSelectionRivalInfo = new SingleModeArcSelectionRivalInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length <= 18)
					{
						if (length != 4)
						{
							if (length != 8)
							{
								if (length == 18 && span.SequenceEqual(GetSpan_win_approval_point().Slice(1)))
								{
									singleModeArcSelectionRivalInfo.win_approval_point = reader.ReadInt32();
									continue;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 7235419148482865251L)
							{
								singleModeArcSelectionRivalInfo.chara_id = reader.ReadInt32();
								continue;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 1802658157)
						{
							singleModeArcSelectionRivalInfo.mark = reader.ReadInt32();
							continue;
						}
					}
					else if (length != 19)
					{
						if (length != 24)
						{
							if (length == 25 && span.SequenceEqual(GetSpan_rival_lose_approval_point().Slice(1)))
							{
								singleModeArcSelectionRivalInfo.rival_lose_approval_point = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_rival_win_approval_point().Slice(1)))
						{
							singleModeArcSelectionRivalInfo.rival_win_approval_point = reader.ReadInt32();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_lose_approval_point().Slice(1)))
					{
						singleModeArcSelectionRivalInfo.lose_approval_point = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeArcSelectionRivalInfo;
			}
		}

		internal sealed class SingleModeCharaFormatter : IMessagePackFormatter<SingleModeChara>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_single_mode_chara_id()
			{
				return new byte[21]
				{
					180, 115, 105, 110, 103, 108, 101, 95, 109, 111,
					100, 101, 95, 99, 104, 97, 114, 97, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_card_id()
			{
				return new byte[8] { 167, 99, 97, 114, 100, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_chara_grade()
			{
				return new byte[12]
				{
					171, 99, 104, 97, 114, 97, 95, 103, 114, 97,
					100, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_speed()
			{
				return new byte[6] { 165, 115, 112, 101, 101, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_stamina()
			{
				return new byte[8] { 167, 115, 116, 97, 109, 105, 110, 97 };
			}

			private static ReadOnlySpan<byte> GetSpan_power()
			{
				return new byte[6] { 165, 112, 111, 119, 101, 114 };
			}

			private static ReadOnlySpan<byte> GetSpan_wiz()
			{
				return new byte[4] { 163, 119, 105, 122 };
			}

			private static ReadOnlySpan<byte> GetSpan_guts()
			{
				return new byte[5] { 164, 103, 117, 116, 115 };
			}

			private static ReadOnlySpan<byte> GetSpan_vital()
			{
				return new byte[6] { 165, 118, 105, 116, 97, 108 };
			}

			private static ReadOnlySpan<byte> GetSpan_max_speed()
			{
				return new byte[10] { 169, 109, 97, 120, 95, 115, 112, 101, 101, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_max_stamina()
			{
				return new byte[12]
				{
					171, 109, 97, 120, 95, 115, 116, 97, 109, 105,
					110, 97
				};
			}

			private static ReadOnlySpan<byte> GetSpan_max_power()
			{
				return new byte[10] { 169, 109, 97, 120, 95, 112, 111, 119, 101, 114 };
			}

			private static ReadOnlySpan<byte> GetSpan_max_wiz()
			{
				return new byte[8] { 167, 109, 97, 120, 95, 119, 105, 122 };
			}

			private static ReadOnlySpan<byte> GetSpan_max_guts()
			{
				return new byte[9] { 168, 109, 97, 120, 95, 103, 117, 116, 115 };
			}

			private static ReadOnlySpan<byte> GetSpan_default_max_speed()
			{
				return new byte[18]
				{
					177, 100, 101, 102, 97, 117, 108, 116, 95, 109,
					97, 120, 95, 115, 112, 101, 101, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_default_max_stamina()
			{
				return new byte[20]
				{
					179, 100, 101, 102, 97, 117, 108, 116, 95, 109,
					97, 120, 95, 115, 116, 97, 109, 105, 110, 97
				};
			}

			private static ReadOnlySpan<byte> GetSpan_default_max_power()
			{
				return new byte[18]
				{
					177, 100, 101, 102, 97, 117, 108, 116, 95, 109,
					97, 120, 95, 112, 111, 119, 101, 114
				};
			}

			private static ReadOnlySpan<byte> GetSpan_default_max_wiz()
			{
				return new byte[16]
				{
					175, 100, 101, 102, 97, 117, 108, 116, 95, 109,
					97, 120, 95, 119, 105, 122
				};
			}

			private static ReadOnlySpan<byte> GetSpan_default_max_guts()
			{
				return new byte[17]
				{
					176, 100, 101, 102, 97, 117, 108, 116, 95, 109,
					97, 120, 95, 103, 117, 116, 115
				};
			}

			private static ReadOnlySpan<byte> GetSpan_max_vital()
			{
				return new byte[10] { 169, 109, 97, 120, 95, 118, 105, 116, 97, 108 };
			}

			private static ReadOnlySpan<byte> GetSpan_motivation()
			{
				return new byte[11]
				{
					170, 109, 111, 116, 105, 118, 97, 116, 105, 111,
					110
				};
			}

			private static ReadOnlySpan<byte> GetSpan_fans()
			{
				return new byte[5] { 164, 102, 97, 110, 115 };
			}

			private static ReadOnlySpan<byte> GetSpan_rarity()
			{
				return new byte[7] { 166, 114, 97, 114, 105, 116, 121 };
			}

			private static ReadOnlySpan<byte> GetSpan_race_program_id()
			{
				return new byte[16]
				{
					175, 114, 97, 99, 101, 95, 112, 114, 111, 103,
					114, 97, 109, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_reserve_race_program_id()
			{
				return new byte[24]
				{
					183, 114, 101, 115, 101, 114, 118, 101, 95, 114,
					97, 99, 101, 95, 112, 114, 111, 103, 114, 97,
					109, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_running_style()
			{
				return new byte[19]
				{
					178, 114, 97, 99, 101, 95, 114, 117, 110, 110,
					105, 110, 103, 95, 115, 116, 121, 108, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_is_short_race()
			{
				return new byte[14]
				{
					173, 105, 115, 95, 115, 104, 111, 114, 116, 95,
					114, 97, 99, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_talent_level()
			{
				return new byte[13]
				{
					172, 116, 97, 108, 101, 110, 116, 95, 108, 101,
					118, 101, 108
				};
			}

			private static ReadOnlySpan<byte> GetSpan_skill_array()
			{
				return new byte[12]
				{
					171, 115, 107, 105, 108, 108, 95, 97, 114, 114,
					97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_disable_skill_id_array()
			{
				return new byte[23]
				{
					182, 100, 105, 115, 97, 98, 108, 101, 95, 115,
					107, 105, 108, 108, 95, 105, 100, 95, 97, 114,
					114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_skill_tips_array()
			{
				return new byte[17]
				{
					176, 115, 107, 105, 108, 108, 95, 116, 105, 112,
					115, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_support_card_array()
			{
				return new byte[19]
				{
					178, 115, 117, 112, 112, 111, 114, 116, 95, 99,
					97, 114, 100, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_succession_trained_chara_id_1()
			{
				return new byte[30]
				{
					189, 115, 117, 99, 99, 101, 115, 115, 105, 111,
					110, 95, 116, 114, 97, 105, 110, 101, 100, 95,
					99, 104, 97, 114, 97, 95, 105, 100, 95, 49
				};
			}

			private static ReadOnlySpan<byte> GetSpan_succession_trained_chara_id_2()
			{
				return new byte[30]
				{
					189, 115, 117, 99, 99, 101, 115, 115, 105, 111,
					110, 95, 116, 114, 97, 105, 110, 101, 100, 95,
					99, 104, 97, 114, 97, 95, 105, 100, 95, 50
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_short()
			{
				return new byte[22]
				{
					181, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 115, 104, 111,
					114, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_mile()
			{
				return new byte[21]
				{
					180, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 109, 105, 108,
					101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_middle()
			{
				return new byte[23]
				{
					182, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 109, 105, 100,
					100, 108, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_long()
			{
				return new byte[21]
				{
					180, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 108, 111, 110,
					103
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_nige()
			{
				return new byte[26]
				{
					185, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 110, 105, 103, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_senko()
			{
				return new byte[27]
				{
					186, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 115, 101, 110, 107, 111
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_sashi()
			{
				return new byte[27]
				{
					186, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 115, 97, 115, 104, 105
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_oikomi()
			{
				return new byte[28]
				{
					187, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 111, 105, 107, 111, 109, 105
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_ground_turf()
			{
				return new byte[19]
				{
					178, 112, 114, 111, 112, 101, 114, 95, 103, 114,
					111, 117, 110, 100, 95, 116, 117, 114, 102
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_ground_dirt()
			{
				return new byte[19]
				{
					178, 112, 114, 111, 112, 101, 114, 95, 103, 114,
					111, 117, 110, 100, 95, 100, 105, 114, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_turn()
			{
				return new byte[5] { 164, 116, 117, 114, 110 };
			}

			private static ReadOnlySpan<byte> GetSpan_skill_point()
			{
				return new byte[12]
				{
					171, 115, 107, 105, 108, 108, 95, 112, 111, 105,
					110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_short_cut_state()
			{
				return new byte[16]
				{
					175, 115, 104, 111, 114, 116, 95, 99, 117, 116,
					95, 115, 116, 97, 116, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_state()
			{
				return new byte[6] { 165, 115, 116, 97, 116, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_playing_state()
			{
				return new byte[14]
				{
					173, 112, 108, 97, 121, 105, 110, 103, 95, 115,
					116, 97, 116, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_scenario_id()
			{
				return new byte[12]
				{
					171, 115, 99, 101, 110, 97, 114, 105, 111, 95,
					105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_route_id()
			{
				return new byte[9] { 168, 114, 111, 117, 116, 101, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_start_time()
			{
				return new byte[11]
				{
					170, 115, 116, 97, 114, 116, 95, 116, 105, 109,
					101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_evaluation_info_array()
			{
				return new byte[22]
				{
					181, 101, 118, 97, 108, 117, 97, 116, 105, 111,
					110, 95, 105, 110, 102, 111, 95, 97, 114, 114,
					97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_training_level_info_array()
			{
				return new byte[26]
				{
					185, 116, 114, 97, 105, 110, 105, 110, 103, 95,
					108, 101, 118, 101, 108, 95, 105, 110, 102, 111,
					95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_nickname_id_array()
			{
				return new byte[18]
				{
					177, 110, 105, 99, 107, 110, 97, 109, 101, 95,
					105, 100, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_chara_effect_id_array()
			{
				return new byte[22]
				{
					181, 99, 104, 97, 114, 97, 95, 101, 102, 102,
					101, 99, 116, 95, 105, 100, 95, 97, 114, 114,
					97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_route_race_id_array()
			{
				return new byte[20]
				{
					179, 114, 111, 117, 116, 101, 95, 114, 97, 99,
					101, 95, 105, 100, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_guest_outing_info_array()
			{
				return new byte[24]
				{
					183, 103, 117, 101, 115, 116, 95, 111, 117, 116,
					105, 110, 103, 95, 105, 110, 102, 111, 95, 97,
					114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_skill_upgrade_info_array()
			{
				return new byte[25]
				{
					184, 115, 107, 105, 108, 108, 95, 117, 112, 103,
					114, 97, 100, 101, 95, 105, 110, 102, 111, 95,
					97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeChara value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(59);
				writer.WriteRaw(GetSpan_single_mode_chara_id());
				writer.Write(value.single_mode_chara_id);
				writer.WriteRaw(GetSpan_card_id());
				writer.Write(value.card_id);
				writer.WriteRaw(GetSpan_chara_grade());
				writer.Write(value.chara_grade);
				writer.WriteRaw(GetSpan_speed());
				writer.Write(value.speed);
				writer.WriteRaw(GetSpan_stamina());
				writer.Write(value.stamina);
				writer.WriteRaw(GetSpan_power());
				writer.Write(value.power);
				writer.WriteRaw(GetSpan_wiz());
				writer.Write(value.wiz);
				writer.WriteRaw(GetSpan_guts());
				writer.Write(value.guts);
				writer.WriteRaw(GetSpan_vital());
				writer.Write(value.vital);
				writer.WriteRaw(GetSpan_max_speed());
				writer.Write(value.max_speed);
				writer.WriteRaw(GetSpan_max_stamina());
				writer.Write(value.max_stamina);
				writer.WriteRaw(GetSpan_max_power());
				writer.Write(value.max_power);
				writer.WriteRaw(GetSpan_max_wiz());
				writer.Write(value.max_wiz);
				writer.WriteRaw(GetSpan_max_guts());
				writer.Write(value.max_guts);
				writer.WriteRaw(GetSpan_default_max_speed());
				writer.Write(value.default_max_speed);
				writer.WriteRaw(GetSpan_default_max_stamina());
				writer.Write(value.default_max_stamina);
				writer.WriteRaw(GetSpan_default_max_power());
				writer.Write(value.default_max_power);
				writer.WriteRaw(GetSpan_default_max_wiz());
				writer.Write(value.default_max_wiz);
				writer.WriteRaw(GetSpan_default_max_guts());
				writer.Write(value.default_max_guts);
				writer.WriteRaw(GetSpan_max_vital());
				writer.Write(value.max_vital);
				writer.WriteRaw(GetSpan_motivation());
				writer.Write(value.motivation);
				writer.WriteRaw(GetSpan_fans());
				writer.Write(value.fans);
				writer.WriteRaw(GetSpan_rarity());
				writer.Write(value.rarity);
				writer.WriteRaw(GetSpan_race_program_id());
				writer.Write(value.race_program_id);
				writer.WriteRaw(GetSpan_reserve_race_program_id());
				writer.Write(value.reserve_race_program_id);
				writer.WriteRaw(GetSpan_race_running_style());
				writer.Write(value.race_running_style);
				writer.WriteRaw(GetSpan_is_short_race());
				writer.Write(value.is_short_race);
				writer.WriteRaw(GetSpan_talent_level());
				writer.Write(value.talent_level);
				writer.WriteRaw(GetSpan_skill_array());
				resolver.GetFormatterWithVerify<SkillData[]>().Serialize(ref writer, value.skill_array, options);
				writer.WriteRaw(GetSpan_disable_skill_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.disable_skill_id_array, options);
				writer.WriteRaw(GetSpan_skill_tips_array());
				resolver.GetFormatterWithVerify<SkillTips[]>().Serialize(ref writer, value.skill_tips_array, options);
				writer.WriteRaw(GetSpan_support_card_array());
				resolver.GetFormatterWithVerify<SingleModeSupportCard[]>().Serialize(ref writer, value.support_card_array, options);
				writer.WriteRaw(GetSpan_succession_trained_chara_id_1());
				writer.Write(value.succession_trained_chara_id_1);
				writer.WriteRaw(GetSpan_succession_trained_chara_id_2());
				writer.Write(value.succession_trained_chara_id_2);
				writer.WriteRaw(GetSpan_proper_distance_short());
				writer.Write(value.proper_distance_short);
				writer.WriteRaw(GetSpan_proper_distance_mile());
				writer.Write(value.proper_distance_mile);
				writer.WriteRaw(GetSpan_proper_distance_middle());
				writer.Write(value.proper_distance_middle);
				writer.WriteRaw(GetSpan_proper_distance_long());
				writer.Write(value.proper_distance_long);
				writer.WriteRaw(GetSpan_proper_running_style_nige());
				writer.Write(value.proper_running_style_nige);
				writer.WriteRaw(GetSpan_proper_running_style_senko());
				writer.Write(value.proper_running_style_senko);
				writer.WriteRaw(GetSpan_proper_running_style_sashi());
				writer.Write(value.proper_running_style_sashi);
				writer.WriteRaw(GetSpan_proper_running_style_oikomi());
				writer.Write(value.proper_running_style_oikomi);
				writer.WriteRaw(GetSpan_proper_ground_turf());
				writer.Write(value.proper_ground_turf);
				writer.WriteRaw(GetSpan_proper_ground_dirt());
				writer.Write(value.proper_ground_dirt);
				writer.WriteRaw(GetSpan_turn());
				writer.Write(value.turn);
				writer.WriteRaw(GetSpan_skill_point());
				writer.Write(value.skill_point);
				writer.WriteRaw(GetSpan_short_cut_state());
				writer.Write(value.short_cut_state);
				writer.WriteRaw(GetSpan_state());
				writer.Write(value.state);
				writer.WriteRaw(GetSpan_playing_state());
				writer.Write(value.playing_state);
				writer.WriteRaw(GetSpan_scenario_id());
				writer.Write(value.scenario_id);
				writer.WriteRaw(GetSpan_route_id());
				writer.Write(value.route_id);
				writer.WriteRaw(GetSpan_start_time());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.start_time, options);
				writer.WriteRaw(GetSpan_evaluation_info_array());
				resolver.GetFormatterWithVerify<EvaluationInfo[]>().Serialize(ref writer, value.evaluation_info_array, options);
				writer.WriteRaw(GetSpan_training_level_info_array());
				resolver.GetFormatterWithVerify<TrainingLevelInfo[]>().Serialize(ref writer, value.training_level_info_array, options);
				writer.WriteRaw(GetSpan_nickname_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.nickname_id_array, options);
				writer.WriteRaw(GetSpan_chara_effect_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.chara_effect_id_array, options);
				writer.WriteRaw(GetSpan_route_race_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.route_race_id_array, options);
				writer.WriteRaw(GetSpan_guest_outing_info_array());
				resolver.GetFormatterWithVerify<GuestOutingInfo[]>().Serialize(ref writer, value.guest_outing_info_array, options);
				writer.WriteRaw(GetSpan_skill_upgrade_info_array());
				resolver.GetFormatterWithVerify<SkillUpgradeInfo[]>().Serialize(ref writer, value.skill_upgrade_info_array, options);
			}

			public SingleModeChara Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeChara singleModeChara = new SingleModeChara();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 20:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7232625306583921264L)
						{
							if (key == 7881129389187819891L && span.SequenceEqual(GetSpan_single_mode_chara_id().Slice(9)))
							{
								singleModeChara.single_mode_chara_id = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 6874009731983504233L)
						{
							switch (AutomataKeyGen.GetKey(ref span))
							{
							case 1701603693uL:
								singleModeChara.proper_distance_mile = reader.ReadInt32();
								goto end_IL_0046;
							case 1735290732uL:
								singleModeChara.proper_distance_long = reader.ReadInt32();
								goto end_IL_0046;
							}
						}
						goto default;
					}
					case 7:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 28263356099092835uL:
							singleModeChara.card_id = reader.ReadInt32();
							goto end_IL_0046;
						case 27424471826658419uL:
							singleModeChara.stamina = reader.ReadInt32();
							goto end_IL_0046;
						case 34455908582449517uL:
							singleModeChara.max_wiz = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 11:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key <= 8028073573554152307L)
						{
							if (key != 7881708861746864493L)
							{
								if (key == 8028073573554152307L && AutomataKeyGen.GetKey(ref span) == 6580575)
								{
									singleModeChara.scenario_id = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 6385257)
							{
								singleModeChara.max_stamina = reader.ReadInt32();
								break;
							}
						}
						else if (key != 8030023054881549171L)
						{
							if (key != 8241973712344673139L)
							{
								if (key == 8243662515060435043L && AutomataKeyGen.GetKey(ref span) == 6644833)
								{
									singleModeChara.chara_grade = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 7954802)
							{
								singleModeChara.skill_array = resolver.GetFormatterWithVerify<SkillData[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 7630441)
						{
							singleModeChara.skill_point = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 5:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 431197876339uL:
							singleModeChara.speed = reader.ReadInt32();
							goto end_IL_0046;
						case 491328597872uL:
							singleModeChara.power = reader.ReadInt32();
							goto end_IL_0046;
						case 465491487094uL:
							singleModeChara.vital = reader.ReadInt32();
							goto end_IL_0046;
						case 435744240755uL:
							singleModeChara.state = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 3:
						if (AutomataKeyGen.GetKey(ref span) == 8022391)
						{
							singleModeChara.wiz = reader.ReadInt32();
							break;
						}
						goto default;
					case 4:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 1937012071uL:
							singleModeChara.guts = reader.ReadInt32();
							goto end_IL_0046;
						case 1936613734uL:
							singleModeChara.fans = reader.ReadInt32();
							goto end_IL_0046;
						case 1852994932uL:
							singleModeChara.turn = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 9:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7022353676106228077L)
						{
							if (key != 7306369611303772525L)
							{
								if (key == 7311435048488034669L && span[0] == 114)
								{
									singleModeChara.max_power = reader.ReadInt32();
									break;
								}
							}
							else if (span[0] == 100)
							{
								singleModeChara.max_speed = reader.ReadInt32();
								break;
							}
						}
						else if (span[0] == 108)
						{
							singleModeChara.max_vital = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 8:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 8319403498503954797uL:
							singleModeChara.max_guts = reader.ReadInt32();
							goto end_IL_0046;
						case 7235419165697601394uL:
							singleModeChara.route_id = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 17:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6878241782302664036L)
						{
							if (key == 7308604897168157038L && span.SequenceEqual(GetSpan_nickname_id_array().Slice(9)))
							{
								singleModeChara.nickname_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else
						{
							ulong key2 = AutomataKeyGen.GetKey(ref span);
							if (key2 != 7306369611303772525L)
							{
								if (key2 == 7311435048488034669L && span[0] == 114)
								{
									singleModeChara.default_max_power = reader.ReadInt32();
									break;
								}
							}
							else if (span[0] == 100)
							{
								singleModeChara.default_max_speed = reader.ReadInt32();
								break;
							}
						}
						goto default;
					}
					case 19:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6878241782302664036L)
						{
							if (key == 7021779658374213490L && span.SequenceEqual(GetSpan_route_race_id_array().Slice(9)))
							{
								singleModeChara.route_race_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_default_max_stamina().Slice(9)))
						{
							singleModeChara.default_max_stamina = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 15:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6878241782302664036L)
						{
							if (key != 8030604640580231538L)
							{
								if (key == 8458709478872672371L && AutomataKeyGen.GetKey(ref span) == 28556934562144116L)
								{
									singleModeChara.short_cut_state = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 28263356248978023L)
							{
								singleModeChara.race_program_id = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 34455908582449517L)
						{
							singleModeChara.default_max_wiz = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 16:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6878241782302664036L)
						{
							if (key == 7598803390560824179L && AutomataKeyGen.GetKey(ref span) == 8746397786915697520L)
							{
								singleModeChara.skill_tips_array = resolver.GetFormatterWithVerify<SkillTips[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 8319403498503954797L)
						{
							singleModeChara.default_max_guts = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 10:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7598803425020703859L)
						{
							if (key == 7598805632484142957L && AutomataKeyGen.GetKey(ref span) == 28271)
							{
								singleModeChara.motivation = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 25965)
						{
							singleModeChara.start_time = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 6:
						if (AutomataKeyGen.GetKey(ref span) == 133540892270962L)
						{
							singleModeChara.rarity = reader.ReadInt32();
							break;
						}
						goto default;
					case 23:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6874030639951340914L)
						{
							if (key == 8462087178609325415L && span.SequenceEqual(GetSpan_guest_outing_info_array().Slice(9)))
							{
								singleModeChara.guest_outing_info_array = resolver.GetFormatterWithVerify<GuestOutingInfo[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_reserve_race_program_id().Slice(9)))
						{
							singleModeChara.reserve_race_program_id = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 18:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6878248353854944627L)
						{
							if (key != 7448798088697705072L)
							{
								if (key == 7959393670495691122L && span.SequenceEqual(GetSpan_race_running_style().Slice(9)))
								{
									singleModeChara.race_running_style = reader.ReadInt32();
									break;
								}
							}
							else
							{
								ulong key2 = AutomataKeyGen.GetKey(ref span);
								if (key2 != 7594299756608057202L)
								{
									if (key2 == 8463494484690562930L && AutomataKeyGen.GetKey(ref span) == 26226)
									{
										singleModeChara.proper_ground_turf = reader.ReadInt32();
										break;
									}
								}
								else if (AutomataKeyGen.GetKey(ref span) == 29810)
								{
									singleModeChara.proper_ground_dirt = reader.ReadInt32();
									break;
								}
							}
						}
						else if (span.SequenceEqual(GetSpan_support_card_array().Slice(9)))
						{
							singleModeChara.support_card_array = resolver.GetFormatterWithVerify<SingleModeSupportCard[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 13:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6874584755491400816L)
						{
							if (key == 8390891550147572585L && AutomataKeyGen.GetKey(ref span) == 435459027551L)
							{
								singleModeChara.is_short_race = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 435744240755L)
						{
							singleModeChara.playing_state = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 12:
						if (span.SequenceEqual(GetSpan_talent_level().Slice(1)))
						{
							singleModeChara.talent_level = reader.ReadInt32();
							break;
						}
						goto default;
					case 22:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6874019576048478564L)
						{
							if (key == 7232625306583921264L && span.SequenceEqual(GetSpan_proper_distance_middle().Slice(9)))
							{
								singleModeChara.proper_distance_middle = reader.ReadInt32();
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_disable_skill_id_array().Slice(9)))
						{
							singleModeChara.disable_skill_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 29:
						if (AutomataKeyGen.GetKey(ref span) == 7598543875600512371L && AutomataKeyGen.GetKey(ref span) == 7955997360933269103L && AutomataKeyGen.GetKey(ref span) == 7021781869995713637L)
						{
							switch (AutomataKeyGen.GetKey(ref span))
							{
							case 212053813599uL:
								singleModeChara.succession_trained_chara_id_1 = reader.ReadInt32();
								goto end_IL_0046;
							case 216348780895uL:
								singleModeChara.succession_trained_chara_id_2 = reader.ReadInt32();
								goto end_IL_0046;
							}
						}
						goto default;
					case 21:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7232625306583921264L)
						{
							if (key != 7378408436651878499L)
							{
								if (key == 7598805628238263909L && span.SequenceEqual(GetSpan_evaluation_info_array().Slice(9)))
								{
									singleModeChara.evaluation_info_array = resolver.GetFormatterWithVerify<EvaluationInfo[]>().Deserialize(ref reader, options);
									break;
								}
							}
							else if (span.SequenceEqual(GetSpan_chara_effect_id_array().Slice(9)))
							{
								singleModeChara.chara_effect_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_proper_distance_short().Slice(9)))
						{
							singleModeChara.proper_distance_short = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 25:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7453010356280062580L)
						{
							if (key == 8241431623114912368L && span.SequenceEqual(GetSpan_proper_running_style_nige().Slice(9)))
							{
								singleModeChara.proper_running_style_nige = reader.ReadInt32();
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_training_level_info_array().Slice(9)))
						{
							singleModeChara.training_level_info_array = resolver.GetFormatterWithVerify<TrainingLevelInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 26:
						if (AutomataKeyGen.GetKey(ref span) == 8241431623114912368L && AutomataKeyGen.GetKey(ref span) == 8313477161062133365L)
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 7954891170380544372L)
							{
								if (key == 8314053240663341428L && AutomataKeyGen.GetKey(ref span) == 26984)
								{
									singleModeChara.proper_running_style_sashi = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 28523)
							{
								singleModeChara.proper_running_style_senko = reader.ReadInt32();
								break;
							}
						}
						goto default;
					case 27:
						if (span.SequenceEqual(GetSpan_proper_running_style_oikomi().Slice(1)))
						{
							singleModeChara.proper_running_style_oikomi = reader.ReadInt32();
							break;
						}
						goto default;
					case 24:
						{
							if (span.SequenceEqual(GetSpan_skill_upgrade_info_array().Slice(1)))
							{
								singleModeChara.skill_upgrade_info_array = resolver.GetFormatterWithVerify<SkillUpgradeInfo[]>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						}
						end_IL_0046:
						break;
					}
				}
				reader.Depth--;
				return singleModeChara;
			}
		}

		internal sealed class SingleModeChoiceRequestFormatter : IMessagePackFormatter<SingleModeChoiceRequest>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_event_id()
			{
				return new byte[9] { 168, 101, 118, 101, 110, 116, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_choice_number()
			{
				return new byte[14]
				{
					173, 99, 104, 111, 105, 99, 101, 95, 110, 117,
					109, 98, 101, 114
				};
			}

			private static ReadOnlySpan<byte> GetSpan_current_turn()
			{
				return new byte[13]
				{
					172, 99, 117, 114, 114, 101, 110, 116, 95, 116,
					117, 114, 110
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeChoiceRequest value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(4);
				writer.WriteRaw(GetSpan_event_id());
				writer.Write(value.event_id);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
				writer.WriteRaw(GetSpan_choice_number());
				writer.Write(value.choice_number);
				writer.WriteRaw(GetSpan_current_turn());
				writer.Write(value.current_turn);
			}

			public SingleModeChoiceRequest Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeChoiceRequest singleModeChoiceRequest = new SingleModeChoiceRequest();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 8)
					{
						if (length != 12)
						{
							if (length == 13 && span.SequenceEqual(GetSpan_choice_number().Slice(1)))
							{
								singleModeChoiceRequest.choice_number = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_current_turn().Slice(1)))
						{
							singleModeChoiceRequest.current_turn = reader.ReadInt32();
							continue;
						}
					}
					else
					{
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 7235419230020400741uL:
							singleModeChoiceRequest.event_id = reader.ReadInt32();
							continue;
						case 7235419148482865251uL:
							singleModeChoiceRequest.chara_id = reader.ReadInt32();
							continue;
						}
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeChoiceRequest;
			}
		}

		internal sealed class SingleModeCommandInfoFormatter : IMessagePackFormatter<SingleModeCommandInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_type()
			{
				return new byte[13]
				{
					172, 99, 111, 109, 109, 97, 110, 100, 95, 116,
					121, 112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_id()
			{
				return new byte[11]
				{
					170, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_is_enable()
			{
				return new byte[10] { 169, 105, 115, 95, 101, 110, 97, 98, 108, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_training_partner_array()
			{
				return new byte[23]
				{
					182, 116, 114, 97, 105, 110, 105, 110, 103, 95,
					112, 97, 114, 116, 110, 101, 114, 95, 97, 114,
					114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_tips_event_partner_array()
			{
				return new byte[25]
				{
					184, 116, 105, 112, 115, 95, 101, 118, 101, 110,
					116, 95, 112, 97, 114, 116, 110, 101, 114, 95,
					97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_params_inc_dec_info_array()
			{
				return new byte[26]
				{
					185, 112, 97, 114, 97, 109, 115, 95, 105, 110,
					99, 95, 100, 101, 99, 95, 105, 110, 102, 111,
					95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_failure_rate()
			{
				return new byte[13]
				{
					172, 102, 97, 105, 108, 117, 114, 101, 95, 114,
					97, 116, 101
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeCommandInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(7);
				writer.WriteRaw(GetSpan_command_type());
				writer.Write(value.command_type);
				writer.WriteRaw(GetSpan_command_id());
				writer.Write(value.command_id);
				writer.WriteRaw(GetSpan_is_enable());
				writer.Write(value.is_enable);
				writer.WriteRaw(GetSpan_training_partner_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.training_partner_array, options);
				writer.WriteRaw(GetSpan_tips_event_partner_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.tips_event_partner_array, options);
				writer.WriteRaw(GetSpan_params_inc_dec_info_array());
				resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Serialize(ref writer, value.params_inc_dec_info_array, options);
				writer.WriteRaw(GetSpan_failure_rate());
				writer.Write(value.failure_rate);
			}

			public SingleModeCommandInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeCommandInfo singleModeCommandInfo = new SingleModeCommandInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 12:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6873740296000991075L)
						{
							if (key == 6874026254906515814L && AutomataKeyGen.GetKey(ref span) == 1702125938)
							{
								singleModeCommandInfo.failure_rate = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 1701869940)
						{
							singleModeCommandInfo.command_type = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 10:
						if (span.SequenceEqual(GetSpan_command_id().Slice(1)))
						{
							singleModeCommandInfo.command_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 9:
						if (span.SequenceEqual(GetSpan_is_enable().Slice(1)))
						{
							singleModeCommandInfo.is_enable = reader.ReadInt32();
							break;
						}
						goto default;
					case 22:
						if (span.SequenceEqual(GetSpan_training_partner_array().Slice(1)))
						{
							singleModeCommandInfo.training_partner_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 24:
						if (span.SequenceEqual(GetSpan_tips_event_partner_array().Slice(1)))
						{
							singleModeCommandInfo.tips_event_partner_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 25:
						if (span.SequenceEqual(GetSpan_params_inc_dec_info_array().Slice(1)))
						{
							singleModeCommandInfo.params_inc_dec_info_array = resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleModeCommandInfo;
			}
		}

		internal sealed class SingleModeEventInfoFormatter : IMessagePackFormatter<SingleModeEventInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_event_id()
			{
				return new byte[9] { 168, 101, 118, 101, 110, 116, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_story_id()
			{
				return new byte[9] { 168, 115, 116, 111, 114, 121, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_play_timing()
			{
				return new byte[12]
				{
					171, 112, 108, 97, 121, 95, 116, 105, 109, 105,
					110, 103
				};
			}

			private static ReadOnlySpan<byte> GetSpan_event_contents_info()
			{
				return new byte[20]
				{
					179, 101, 118, 101, 110, 116, 95, 99, 111, 110,
					116, 101, 110, 116, 115, 95, 105, 110, 102, 111
				};
			}

			private static ReadOnlySpan<byte> GetSpan_succession_event_info()
			{
				return new byte[22]
				{
					181, 115, 117, 99, 99, 101, 115, 115, 105, 111,
					110, 95, 101, 118, 101, 110, 116, 95, 105, 110,
					102, 111
				};
			}

			private static ReadOnlySpan<byte> GetSpan_minigame_result()
			{
				return new byte[16]
				{
					175, 109, 105, 110, 105, 103, 97, 109, 101, 95,
					114, 101, 115, 117, 108, 116
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeEventInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(7);
				writer.WriteRaw(GetSpan_event_id());
				writer.Write(value.event_id);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
				writer.WriteRaw(GetSpan_story_id());
				writer.Write(value.story_id);
				writer.WriteRaw(GetSpan_play_timing());
				writer.Write(value.play_timing);
				writer.WriteRaw(GetSpan_event_contents_info());
				resolver.GetFormatterWithVerify<EventContentsInfo>().Serialize(ref writer, value.event_contents_info, options);
				writer.WriteRaw(GetSpan_succession_event_info());
				resolver.GetFormatterWithVerify<SingleModeSuccessionEventInfo>().Serialize(ref writer, value.succession_event_info, options);
				writer.WriteRaw(GetSpan_minigame_result());
				resolver.GetFormatterWithVerify<MinigameResult>().Serialize(ref writer, value.minigame_result, options);
			}

			public SingleModeEventInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeEventInfo singleModeEventInfo = new SingleModeEventInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length <= 11)
					{
						if (length != 8)
						{
							if (length == 11 && span.SequenceEqual(GetSpan_play_timing().Slice(1)))
							{
								singleModeEventInfo.play_timing = reader.ReadInt32();
								continue;
							}
						}
						else
						{
							switch (AutomataKeyGen.GetKey(ref span))
							{
							case 7235419230020400741uL:
								singleModeEventInfo.event_id = reader.ReadInt32();
								continue;
							case 7235419148482865251uL:
								singleModeEventInfo.chara_id = reader.ReadInt32();
								continue;
							case 7235419251563000947uL:
								singleModeEventInfo.story_id = reader.ReadInt32();
								continue;
							}
						}
					}
					else if (length != 15)
					{
						if (length != 19)
						{
							if (length == 21 && span.SequenceEqual(GetSpan_succession_event_info().Slice(1)))
							{
								singleModeEventInfo.succession_event_info = resolver.GetFormatterWithVerify<SingleModeSuccessionEventInfo>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_event_contents_info().Slice(1)))
						{
							singleModeEventInfo.event_contents_info = resolver.GetFormatterWithVerify<EventContentsInfo>().Deserialize(ref reader, options);
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_minigame_result().Slice(1)))
					{
						singleModeEventInfo.minigame_result = resolver.GetFormatterWithVerify<MinigameResult>().Deserialize(ref reader, options);
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeEventInfo;
			}
		}

		internal sealed class SingleModeExecCommandRequestFormatter : IMessagePackFormatter<SingleModeExecCommandRequest>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_type()
			{
				return new byte[13]
				{
					172, 99, 111, 109, 109, 97, 110, 100, 95, 116,
					121, 112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_id()
			{
				return new byte[11]
				{
					170, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_group_id()
			{
				return new byte[17]
				{
					176, 99, 111, 109, 109, 97, 110, 100, 95, 103,
					114, 111, 117, 112, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_select_id()
			{
				return new byte[10] { 169, 115, 101, 108, 101, 99, 116, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_current_turn()
			{
				return new byte[13]
				{
					172, 99, 117, 114, 114, 101, 110, 116, 95, 116,
					117, 114, 110
				};
			}

			private static ReadOnlySpan<byte> GetSpan_current_vital()
			{
				return new byte[14]
				{
					173, 99, 117, 114, 114, 101, 110, 116, 95, 118,
					105, 116, 97, 108
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeExecCommandRequest value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(6);
				writer.WriteRaw(GetSpan_command_type());
				writer.Write(value.command_type);
				writer.WriteRaw(GetSpan_command_id());
				writer.Write(value.command_id);
				writer.WriteRaw(GetSpan_command_group_id());
				writer.Write(value.command_group_id);
				writer.WriteRaw(GetSpan_select_id());
				writer.Write(value.select_id);
				writer.WriteRaw(GetSpan_current_turn());
				writer.Write(value.current_turn);
				writer.WriteRaw(GetSpan_current_vital());
				writer.Write(value.current_vital);
			}

			public SingleModeExecCommandRequest Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeExecCommandRequest singleModeExecCommandRequest = new SingleModeExecCommandRequest();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 12:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6873740296000991075L)
						{
							if (key == 6878243912892446051L && AutomataKeyGen.GetKey(ref span) == 1852994932)
							{
								singleModeExecCommandRequest.current_turn = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 1701869940)
						{
							singleModeExecCommandRequest.command_type = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 10:
						if (span.SequenceEqual(GetSpan_command_id().Slice(1)))
						{
							singleModeExecCommandRequest.command_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 16:
						if (span.SequenceEqual(GetSpan_command_group_id().Slice(1)))
						{
							singleModeExecCommandRequest.command_group_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 9:
						if (span.SequenceEqual(GetSpan_select_id().Slice(1)))
						{
							singleModeExecCommandRequest.select_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 13:
						if (span.SequenceEqual(GetSpan_current_vital().Slice(1)))
						{
							singleModeExecCommandRequest.current_vital = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleModeExecCommandRequest;
			}
		}

		internal sealed class SingleModeFreeCommandInfoFormatter : IMessagePackFormatter<SingleModeFreeCommandInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_type()
			{
				return new byte[13]
				{
					172, 99, 111, 109, 109, 97, 110, 100, 95, 116,
					121, 112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_id()
			{
				return new byte[11]
				{
					170, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_params_inc_dec_info_array()
			{
				return new byte[26]
				{
					185, 112, 97, 114, 97, 109, 115, 95, 105, 110,
					99, 95, 100, 101, 99, 95, 105, 110, 102, 111,
					95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeFreeCommandInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_command_type());
				writer.Write(value.command_type);
				writer.WriteRaw(GetSpan_command_id());
				writer.Write(value.command_id);
				writer.WriteRaw(GetSpan_params_inc_dec_info_array());
				resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Serialize(ref writer, value.params_inc_dec_info_array, options);
			}

			public SingleModeFreeCommandInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeFreeCommandInfo singleModeFreeCommandInfo = new SingleModeFreeCommandInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 10)
					{
						if (length != 12)
						{
							if (length == 25 && span.SequenceEqual(GetSpan_params_inc_dec_info_array().Slice(1)))
							{
								singleModeFreeCommandInfo.params_inc_dec_info_array = resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_command_type().Slice(1)))
						{
							singleModeFreeCommandInfo.command_type = reader.ReadInt32();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_command_id().Slice(1)))
					{
						singleModeFreeCommandInfo.command_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeFreeCommandInfo;
			}
		}

		internal sealed class SingleModeFreeDataSetFormatter : IMessagePackFormatter<SingleModeFreeDataSet>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_shop_id()
			{
				return new byte[8] { 167, 115, 104, 111, 112, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_sale_value()
			{
				return new byte[11]
				{
					170, 115, 97, 108, 101, 95, 118, 97, 108, 117,
					101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_win_points()
			{
				return new byte[11]
				{
					170, 119, 105, 110, 95, 112, 111, 105, 110, 116,
					115
				};
			}

			private static ReadOnlySpan<byte> GetSpan_gained_coin_num()
			{
				return new byte[16]
				{
					175, 103, 97, 105, 110, 101, 100, 95, 99, 111,
					105, 110, 95, 110, 117, 109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_coin_num()
			{
				return new byte[9] { 168, 99, 111, 105, 110, 95, 110, 117, 109 };
			}

			private static ReadOnlySpan<byte> GetSpan_twinkle_race_ranking()
			{
				return new byte[21]
				{
					180, 116, 119, 105, 110, 107, 108, 101, 95, 114,
					97, 99, 101, 95, 114, 97, 110, 107, 105, 110,
					103
				};
			}

			private static ReadOnlySpan<byte> GetSpan_user_item_info_array()
			{
				return new byte[21]
				{
					180, 117, 115, 101, 114, 95, 105, 116, 101, 109,
					95, 105, 110, 102, 111, 95, 97, 114, 114, 97,
					121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_pick_up_item_info_array()
			{
				return new byte[24]
				{
					183, 112, 105, 99, 107, 95, 117, 112, 95, 105,
					116, 101, 109, 95, 105, 110, 102, 111, 95, 97,
					114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_twinkle_race_npc_info_array()
			{
				return new byte[28]
				{
					187, 116, 119, 105, 110, 107, 108, 101, 95, 114,
					97, 99, 101, 95, 110, 112, 99, 95, 105, 110,
					102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_item_effect_array()
			{
				return new byte[18]
				{
					177, 105, 116, 101, 109, 95, 101, 102, 102, 101,
					99, 116, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_twinkle_race_npc_result_array()
			{
				return new byte[30]
				{
					189, 116, 119, 105, 110, 107, 108, 101, 95, 114,
					97, 99, 101, 95, 110, 112, 99, 95, 114, 101,
					115, 117, 108, 116, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_rival_race_info_array()
			{
				return new byte[22]
				{
					181, 114, 105, 118, 97, 108, 95, 114, 97, 99,
					101, 95, 105, 110, 102, 111, 95, 97, 114, 114,
					97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_info_array()
			{
				return new byte[19]
				{
					178, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					110, 102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_unchecked_event_achievement_id()
			{
				return new byte[31]
				{
					190, 117, 110, 99, 104, 101, 99, 107, 101, 100,
					95, 101, 118, 101, 110, 116, 95, 97, 99, 104,
					105, 101, 118, 101, 109, 101, 110, 116, 95, 105,
					100
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeFreeDataSet value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(14);
				writer.WriteRaw(GetSpan_shop_id());
				writer.Write(value.shop_id);
				writer.WriteRaw(GetSpan_sale_value());
				writer.Write(value.sale_value);
				writer.WriteRaw(GetSpan_win_points());
				writer.Write(value.win_points);
				writer.WriteRaw(GetSpan_gained_coin_num());
				writer.Write(value.gained_coin_num);
				writer.WriteRaw(GetSpan_coin_num());
				writer.Write(value.coin_num);
				writer.WriteRaw(GetSpan_twinkle_race_ranking());
				writer.Write(value.twinkle_race_ranking);
				writer.WriteRaw(GetSpan_user_item_info_array());
				resolver.GetFormatterWithVerify<SingleModeFreeUserItem[]>().Serialize(ref writer, value.user_item_info_array, options);
				writer.WriteRaw(GetSpan_pick_up_item_info_array());
				resolver.GetFormatterWithVerify<SingleModeFreePickUpItem[]>().Serialize(ref writer, value.pick_up_item_info_array, options);
				writer.WriteRaw(GetSpan_twinkle_race_npc_info_array());
				resolver.GetFormatterWithVerify<SingleModeFreeTwinkleRaceNpcInfo[]>().Serialize(ref writer, value.twinkle_race_npc_info_array, options);
				writer.WriteRaw(GetSpan_item_effect_array());
				resolver.GetFormatterWithVerify<SingleModeFreeItemEffect[]>().Serialize(ref writer, value.item_effect_array, options);
				writer.WriteRaw(GetSpan_twinkle_race_npc_result_array());
				resolver.GetFormatterWithVerify<SingleModeTwikleRaceNpcResult[]>().Serialize(ref writer, value.twinkle_race_npc_result_array, options);
				writer.WriteRaw(GetSpan_rival_race_info_array());
				resolver.GetFormatterWithVerify<SingleModeRivalRaceInfo[]>().Serialize(ref writer, value.rival_race_info_array, options);
				writer.WriteRaw(GetSpan_command_info_array());
				resolver.GetFormatterWithVerify<SingleModeFreeCommandInfo[]>().Serialize(ref writer, value.command_info_array, options);
				writer.WriteRaw(GetSpan_unchecked_event_achievement_id());
				resolver.GetFormatterWithVerify<int?>().Serialize(ref writer, value.unchecked_event_achievement_id, options);
			}

			public SingleModeFreeDataSet Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeFreeDataSet singleModeFreeDataSet = new SingleModeFreeDataSet();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 7:
						if (AutomataKeyGen.GetKey(ref span) == 28263356300224627L)
						{
							singleModeFreeDataSet.shop_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 10:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7809653380932723059L)
						{
							if (key == 7956012745154783607L && AutomataKeyGen.GetKey(ref span) == 29556)
							{
								singleModeFreeDataSet.win_points = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 25973)
						{
							singleModeFreeDataSet.sale_value = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 15:
						if (span.SequenceEqual(GetSpan_gained_coin_num().Slice(1)))
						{
							singleModeFreeDataSet.gained_coin_num = reader.ReadInt32();
							break;
						}
						goto default;
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 7887331678562643811L)
						{
							singleModeFreeDataSet.coin_num = reader.ReadInt32();
							break;
						}
						goto default;
					case 20:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6874019614920636276L)
						{
							if (key == 7310583953791218549L && span.SequenceEqual(GetSpan_user_item_info_array().Slice(9)))
							{
								singleModeFreeDataSet.user_item_info_array = resolver.GetFormatterWithVerify<SingleModeFreeUserItem[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_twinkle_race_ranking().Slice(9)))
						{
							singleModeFreeDataSet.twinkle_race_ranking = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 23:
						if (span.SequenceEqual(GetSpan_pick_up_item_info_array().Slice(1)))
						{
							singleModeFreeDataSet.pick_up_item_info_array = resolver.GetFormatterWithVerify<SingleModeFreePickUpItem[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 27:
						if (span.SequenceEqual(GetSpan_twinkle_race_npc_info_array().Slice(1)))
						{
							singleModeFreeDataSet.twinkle_race_npc_info_array = resolver.GetFormatterWithVerify<SingleModeFreeTwinkleRaceNpcInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 17:
						if (span.SequenceEqual(GetSpan_item_effect_array().Slice(1)))
						{
							singleModeFreeDataSet.item_effect_array = resolver.GetFormatterWithVerify<SingleModeFreeItemEffect[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 29:
						if (span.SequenceEqual(GetSpan_twinkle_race_npc_result_array().Slice(1)))
						{
							singleModeFreeDataSet.twinkle_race_npc_result_array = resolver.GetFormatterWithVerify<SingleModeTwikleRaceNpcResult[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 21:
						if (span.SequenceEqual(GetSpan_rival_race_info_array().Slice(1)))
						{
							singleModeFreeDataSet.rival_race_info_array = resolver.GetFormatterWithVerify<SingleModeRivalRaceInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 18:
						if (span.SequenceEqual(GetSpan_command_info_array().Slice(1)))
						{
							singleModeFreeDataSet.command_info_array = resolver.GetFormatterWithVerify<SingleModeFreeCommandInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 30:
						if (span.SequenceEqual(GetSpan_unchecked_event_achievement_id().Slice(1)))
						{
							singleModeFreeDataSet.unchecked_event_achievement_id = resolver.GetFormatterWithVerify<int?>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleModeFreeDataSet;
			}
		}

		internal sealed class SingleModeFreeItemEffectFormatter : IMessagePackFormatter<SingleModeFreeItemEffect>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_use_id()
			{
				return new byte[7] { 166, 117, 115, 101, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_item_id()
			{
				return new byte[8] { 167, 105, 116, 101, 109, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_effect_type()
			{
				return new byte[12]
				{
					171, 101, 102, 102, 101, 99, 116, 95, 116, 121,
					112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_effect_value_1()
			{
				return new byte[15]
				{
					174, 101, 102, 102, 101, 99, 116, 95, 118, 97,
					108, 117, 101, 95, 49
				};
			}

			private static ReadOnlySpan<byte> GetSpan_effect_value_2()
			{
				return new byte[15]
				{
					174, 101, 102, 102, 101, 99, 116, 95, 118, 97,
					108, 117, 101, 95, 50
				};
			}

			private static ReadOnlySpan<byte> GetSpan_effect_value_3()
			{
				return new byte[15]
				{
					174, 101, 102, 102, 101, 99, 116, 95, 118, 97,
					108, 117, 101, 95, 51
				};
			}

			private static ReadOnlySpan<byte> GetSpan_effect_value_4()
			{
				return new byte[15]
				{
					174, 101, 102, 102, 101, 99, 116, 95, 118, 97,
					108, 117, 101, 95, 52
				};
			}

			private static ReadOnlySpan<byte> GetSpan_begin_turn()
			{
				return new byte[11]
				{
					170, 98, 101, 103, 105, 110, 95, 116, 117, 114,
					110
				};
			}

			private static ReadOnlySpan<byte> GetSpan_end_turn()
			{
				return new byte[9] { 168, 101, 110, 100, 95, 116, 117, 114, 110 };
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeFreeItemEffect value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(9);
				writer.WriteRaw(GetSpan_use_id());
				writer.Write(value.use_id);
				writer.WriteRaw(GetSpan_item_id());
				writer.Write(value.item_id);
				writer.WriteRaw(GetSpan_effect_type());
				writer.Write(value.effect_type);
				writer.WriteRaw(GetSpan_effect_value_1());
				writer.Write(value.effect_value_1);
				writer.WriteRaw(GetSpan_effect_value_2());
				writer.Write(value.effect_value_2);
				writer.WriteRaw(GetSpan_effect_value_3());
				writer.Write(value.effect_value_3);
				writer.WriteRaw(GetSpan_effect_value_4());
				writer.Write(value.effect_value_4);
				writer.WriteRaw(GetSpan_begin_turn());
				writer.Write(value.begin_turn);
				writer.WriteRaw(GetSpan_end_turn());
				writer.Write(value.end_turn);
			}

			public SingleModeFreeItemEffect Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeFreeItemEffect singleModeFreeItemEffect = new SingleModeFreeItemEffect();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 6:
						if (AutomataKeyGen.GetKey(ref span) == 110403734827893L)
						{
							singleModeFreeItemEffect.use_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 7:
						if (AutomataKeyGen.GetKey(ref span) == 28263356249240681L)
						{
							singleModeFreeItemEffect.item_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 11:
						if (span.SequenceEqual(GetSpan_effect_type().Slice(1)))
						{
							singleModeFreeItemEffect.effect_type = reader.ReadInt32();
							break;
						}
						goto default;
					case 14:
						if (AutomataKeyGen.GetKey(ref span) == 8529664189514802789L)
						{
							switch (AutomataKeyGen.GetKey(ref span))
							{
							case 54285793848417uL:
								singleModeFreeItemEffect.effect_value_1 = reader.ReadInt32();
								goto end_IL_003e;
							case 55385305476193uL:
								singleModeFreeItemEffect.effect_value_2 = reader.ReadInt32();
								goto end_IL_003e;
							case 56484817103969uL:
								singleModeFreeItemEffect.effect_value_3 = reader.ReadInt32();
								goto end_IL_003e;
							case 57584328731745uL:
								singleModeFreeItemEffect.effect_value_4 = reader.ReadInt32();
								goto end_IL_003e;
							}
						}
						goto default;
					case 10:
						if (span.SequenceEqual(GetSpan_begin_turn().Slice(1)))
						{
							singleModeFreeItemEffect.begin_turn = reader.ReadInt32();
							break;
						}
						goto default;
					case 8:
						{
							if (AutomataKeyGen.GetKey(ref span) == 7958552634194161253L)
							{
								singleModeFreeItemEffect.end_turn = reader.ReadInt32();
								break;
							}
							goto default;
						}
						end_IL_003e:
						break;
					}
				}
				reader.Depth--;
				return singleModeFreeItemEffect;
			}
		}

		internal sealed class SingleModeFreePickUpItemFormatter : IMessagePackFormatter<SingleModeFreePickUpItem>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_shop_item_id()
			{
				return new byte[13]
				{
					172, 115, 104, 111, 112, 95, 105, 116, 101, 109,
					95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_item_id()
			{
				return new byte[8] { 167, 105, 116, 101, 109, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_coin_num()
			{
				return new byte[9] { 168, 99, 111, 105, 110, 95, 110, 117, 109 };
			}

			private static ReadOnlySpan<byte> GetSpan_original_coin_num()
			{
				return new byte[18]
				{
					177, 111, 114, 105, 103, 105, 110, 97, 108, 95,
					99, 111, 105, 110, 95, 110, 117, 109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_item_buy_num()
			{
				return new byte[13]
				{
					172, 105, 116, 101, 109, 95, 98, 117, 121, 95,
					110, 117, 109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_limit_buy_count()
			{
				return new byte[16]
				{
					175, 108, 105, 109, 105, 116, 95, 98, 117, 121,
					95, 99, 111, 117, 110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_limit_turn()
			{
				return new byte[11]
				{
					170, 108, 105, 109, 105, 116, 95, 116, 117, 114,
					110
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeFreePickUpItem value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(7);
				writer.WriteRaw(GetSpan_shop_item_id());
				writer.Write(value.shop_item_id);
				writer.WriteRaw(GetSpan_item_id());
				writer.Write(value.item_id);
				writer.WriteRaw(GetSpan_coin_num());
				writer.Write(value.coin_num);
				writer.WriteRaw(GetSpan_original_coin_num());
				writer.Write(value.original_coin_num);
				writer.WriteRaw(GetSpan_item_buy_num());
				writer.Write(value.item_buy_num);
				writer.WriteRaw(GetSpan_limit_buy_count());
				writer.Write(value.limit_buy_count);
				writer.WriteRaw(GetSpan_limit_turn());
				writer.Write(value.limit_turn);
			}

			public SingleModeFreePickUpItem Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeFreePickUpItem singleModeFreePickUpItem = new SingleModeFreePickUpItem();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 12:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7310583953758316659L)
						{
							if (key == 8752009612861207657L && AutomataKeyGen.GetKey(ref span) == 1836412511)
							{
								singleModeFreePickUpItem.item_buy_num = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 1684627309)
						{
							singleModeFreePickUpItem.shop_item_id = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 7:
						if (AutomataKeyGen.GetKey(ref span) == 28263356249240681L)
						{
							singleModeFreePickUpItem.item_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 7887331678562643811L)
						{
							singleModeFreePickUpItem.coin_num = reader.ReadInt32();
							break;
						}
						goto default;
					case 17:
						if (span.SequenceEqual(GetSpan_original_coin_num().Slice(1)))
						{
							singleModeFreePickUpItem.original_coin_num = reader.ReadInt32();
							break;
						}
						goto default;
					case 15:
						if (span.SequenceEqual(GetSpan_limit_buy_count().Slice(1)))
						{
							singleModeFreePickUpItem.limit_buy_count = reader.ReadInt32();
							break;
						}
						goto default;
					case 10:
						if (span.SequenceEqual(GetSpan_limit_turn().Slice(1)))
						{
							singleModeFreePickUpItem.limit_turn = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleModeFreePickUpItem;
			}
		}

		internal sealed class SingleModeFreeTwinkleRaceNpcInfoFormatter : IMessagePackFormatter<SingleModeFreeTwinkleRaceNpcInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_npc_id()
			{
				return new byte[7] { 166, 110, 112, 99, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_dress_id()
			{
				return new byte[9] { 168, 100, 114, 101, 115, 115, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_talent_level()
			{
				return new byte[13]
				{
					172, 116, 97, 108, 101, 110, 116, 95, 108, 101,
					118, 101, 108
				};
			}

			private static ReadOnlySpan<byte> GetSpan_win_points()
			{
				return new byte[11]
				{
					170, 119, 105, 110, 95, 112, 111, 105, 110, 116,
					115
				};
			}

			private static ReadOnlySpan<byte> GetSpan_speed()
			{
				return new byte[6] { 165, 115, 112, 101, 101, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_stamina()
			{
				return new byte[8] { 167, 115, 116, 97, 109, 105, 110, 97 };
			}

			private static ReadOnlySpan<byte> GetSpan_power()
			{
				return new byte[6] { 165, 112, 111, 119, 101, 114 };
			}

			private static ReadOnlySpan<byte> GetSpan_guts()
			{
				return new byte[5] { 164, 103, 117, 116, 115 };
			}

			private static ReadOnlySpan<byte> GetSpan_wiz()
			{
				return new byte[4] { 163, 119, 105, 122 };
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_short()
			{
				return new byte[22]
				{
					181, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 115, 104, 111,
					114, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_mile()
			{
				return new byte[21]
				{
					180, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 109, 105, 108,
					101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_middle()
			{
				return new byte[23]
				{
					182, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 109, 105, 100,
					100, 108, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_long()
			{
				return new byte[21]
				{
					180, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 108, 111, 110,
					103
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_nige()
			{
				return new byte[26]
				{
					185, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 110, 105, 103, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_senko()
			{
				return new byte[27]
				{
					186, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 115, 101, 110, 107, 111
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_sashi()
			{
				return new byte[27]
				{
					186, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 115, 97, 115, 104, 105
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_oikomi()
			{
				return new byte[28]
				{
					187, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 111, 105, 107, 111, 109, 105
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_ground_turf()
			{
				return new byte[19]
				{
					178, 112, 114, 111, 112, 101, 114, 95, 103, 114,
					111, 117, 110, 100, 95, 116, 117, 114, 102
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_ground_dirt()
			{
				return new byte[19]
				{
					178, 112, 114, 111, 112, 101, 114, 95, 103, 114,
					111, 117, 110, 100, 95, 100, 105, 114, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_skill_array()
			{
				return new byte[12]
				{
					171, 115, 107, 105, 108, 108, 95, 97, 114, 114,
					97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeFreeTwinkleRaceNpcInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(21);
				writer.WriteRaw(GetSpan_npc_id());
				writer.Write(value.npc_id);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
				writer.WriteRaw(GetSpan_dress_id());
				writer.Write(value.dress_id);
				writer.WriteRaw(GetSpan_talent_level());
				writer.Write(value.talent_level);
				writer.WriteRaw(GetSpan_win_points());
				writer.Write(value.win_points);
				writer.WriteRaw(GetSpan_speed());
				writer.Write(value.speed);
				writer.WriteRaw(GetSpan_stamina());
				writer.Write(value.stamina);
				writer.WriteRaw(GetSpan_power());
				writer.Write(value.power);
				writer.WriteRaw(GetSpan_guts());
				writer.Write(value.guts);
				writer.WriteRaw(GetSpan_wiz());
				writer.Write(value.wiz);
				writer.WriteRaw(GetSpan_proper_distance_short());
				writer.Write(value.proper_distance_short);
				writer.WriteRaw(GetSpan_proper_distance_mile());
				writer.Write(value.proper_distance_mile);
				writer.WriteRaw(GetSpan_proper_distance_middle());
				writer.Write(value.proper_distance_middle);
				writer.WriteRaw(GetSpan_proper_distance_long());
				writer.Write(value.proper_distance_long);
				writer.WriteRaw(GetSpan_proper_running_style_nige());
				writer.Write(value.proper_running_style_nige);
				writer.WriteRaw(GetSpan_proper_running_style_senko());
				writer.Write(value.proper_running_style_senko);
				writer.WriteRaw(GetSpan_proper_running_style_sashi());
				writer.Write(value.proper_running_style_sashi);
				writer.WriteRaw(GetSpan_proper_running_style_oikomi());
				writer.Write(value.proper_running_style_oikomi);
				writer.WriteRaw(GetSpan_proper_ground_turf());
				writer.Write(value.proper_ground_turf);
				writer.WriteRaw(GetSpan_proper_ground_dirt());
				writer.Write(value.proper_ground_dirt);
				writer.WriteRaw(GetSpan_skill_array());
				resolver.GetFormatterWithVerify<SkillData[]>().Serialize(ref writer, value.skill_array, options);
			}

			public SingleModeFreeTwinkleRaceNpcInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeFreeTwinkleRaceNpcInfo singleModeFreeTwinkleRaceNpcInfo = new SingleModeFreeTwinkleRaceNpcInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 6:
						if (AutomataKeyGen.GetKey(ref span) == 110403734696046L)
						{
							singleModeFreeTwinkleRaceNpcInfo.npc_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 8:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 7235419148482865251uL:
							singleModeFreeTwinkleRaceNpcInfo.chara_id = reader.ReadInt32();
							goto end_IL_0046;
						case 7235419225809318500uL:
							singleModeFreeTwinkleRaceNpcInfo.dress_id = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 12:
						if (span.SequenceEqual(GetSpan_talent_level().Slice(1)))
						{
							singleModeFreeTwinkleRaceNpcInfo.talent_level = reader.ReadInt32();
							break;
						}
						goto default;
					case 10:
						if (span.SequenceEqual(GetSpan_win_points().Slice(1)))
						{
							singleModeFreeTwinkleRaceNpcInfo.win_points = reader.ReadInt32();
							break;
						}
						goto default;
					case 5:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 431197876339uL:
							singleModeFreeTwinkleRaceNpcInfo.speed = reader.ReadInt32();
							goto end_IL_0046;
						case 491328597872uL:
							singleModeFreeTwinkleRaceNpcInfo.power = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 7:
						if (AutomataKeyGen.GetKey(ref span) == 27424471826658419L)
						{
							singleModeFreeTwinkleRaceNpcInfo.stamina = reader.ReadInt32();
							break;
						}
						goto default;
					case 4:
						if (AutomataKeyGen.GetKey(ref span) == 1937012071)
						{
							singleModeFreeTwinkleRaceNpcInfo.guts = reader.ReadInt32();
							break;
						}
						goto default;
					case 3:
						if (AutomataKeyGen.GetKey(ref span) == 8022391)
						{
							singleModeFreeTwinkleRaceNpcInfo.wiz = reader.ReadInt32();
							break;
						}
						goto default;
					case 21:
						if (span.SequenceEqual(GetSpan_proper_distance_short().Slice(1)))
						{
							singleModeFreeTwinkleRaceNpcInfo.proper_distance_short = reader.ReadInt32();
							break;
						}
						goto default;
					case 20:
						if (AutomataKeyGen.GetKey(ref span) == 7232625306583921264L && AutomataKeyGen.GetKey(ref span) == 6874009731983504233L)
						{
							switch (AutomataKeyGen.GetKey(ref span))
							{
							case 1701603693uL:
								singleModeFreeTwinkleRaceNpcInfo.proper_distance_mile = reader.ReadInt32();
								goto end_IL_0046;
							case 1735290732uL:
								singleModeFreeTwinkleRaceNpcInfo.proper_distance_long = reader.ReadInt32();
								goto end_IL_0046;
							}
						}
						goto default;
					case 22:
						if (span.SequenceEqual(GetSpan_proper_distance_middle().Slice(1)))
						{
							singleModeFreeTwinkleRaceNpcInfo.proper_distance_middle = reader.ReadInt32();
							break;
						}
						goto default;
					case 25:
						if (span.SequenceEqual(GetSpan_proper_running_style_nige().Slice(1)))
						{
							singleModeFreeTwinkleRaceNpcInfo.proper_running_style_nige = reader.ReadInt32();
							break;
						}
						goto default;
					case 26:
						if (AutomataKeyGen.GetKey(ref span) == 8241431623114912368L && AutomataKeyGen.GetKey(ref span) == 8313477161062133365L)
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 7954891170380544372L)
							{
								if (key == 8314053240663341428L && AutomataKeyGen.GetKey(ref span) == 26984)
								{
									singleModeFreeTwinkleRaceNpcInfo.proper_running_style_sashi = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 28523)
							{
								singleModeFreeTwinkleRaceNpcInfo.proper_running_style_senko = reader.ReadInt32();
								break;
							}
						}
						goto default;
					case 27:
						if (span.SequenceEqual(GetSpan_proper_running_style_oikomi().Slice(1)))
						{
							singleModeFreeTwinkleRaceNpcInfo.proper_running_style_oikomi = reader.ReadInt32();
							break;
						}
						goto default;
					case 18:
						if (AutomataKeyGen.GetKey(ref span) == 7448798088697705072L)
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 7594299756608057202L)
							{
								if (key == 8463494484690562930L && AutomataKeyGen.GetKey(ref span) == 26226)
								{
									singleModeFreeTwinkleRaceNpcInfo.proper_ground_turf = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 29810)
							{
								singleModeFreeTwinkleRaceNpcInfo.proper_ground_dirt = reader.ReadInt32();
								break;
							}
						}
						goto default;
					case 11:
						{
							if (span.SequenceEqual(GetSpan_skill_array().Slice(1)))
							{
								singleModeFreeTwinkleRaceNpcInfo.skill_array = resolver.GetFormatterWithVerify<SkillData[]>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						}
						end_IL_0046:
						break;
					}
				}
				reader.Depth--;
				return singleModeFreeTwinkleRaceNpcInfo;
			}
		}

		internal sealed class SingleModeFreeUserItemFormatter : IMessagePackFormatter<SingleModeFreeUserItem>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_item_id()
			{
				return new byte[8] { 167, 105, 116, 101, 109, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_num()
			{
				return new byte[4] { 163, 110, 117, 109 };
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeFreeUserItem value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_item_id());
				writer.Write(value.item_id);
				writer.WriteRaw(GetSpan_num());
				writer.Write(value.num);
			}

			public SingleModeFreeUserItem Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeFreeUserItem singleModeFreeUserItem = new SingleModeFreeUserItem();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 3)
					{
						if (length == 7 && AutomataKeyGen.GetKey(ref span) == 28263356249240681L)
						{
							singleModeFreeUserItem.item_id = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 7173486)
					{
						singleModeFreeUserItem.num = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeFreeUserItem;
			}
		}

		internal sealed class SingleModeHomeInfoFormatter : IMessagePackFormatter<SingleModeHomeInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_info_array()
			{
				return new byte[19]
				{
					178, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					110, 102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_entry_restriction()
			{
				return new byte[23]
				{
					182, 114, 97, 99, 101, 95, 101, 110, 116, 114,
					121, 95, 114, 101, 115, 116, 114, 105, 99, 116,
					105, 111, 110
				};
			}

			private static ReadOnlySpan<byte> GetSpan_disable_command_id_array()
			{
				return new byte[25]
				{
					184, 100, 105, 115, 97, 98, 108, 101, 95, 99,
					111, 109, 109, 97, 110, 100, 95, 105, 100, 95,
					97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_available_continue_num()
			{
				return new byte[23]
				{
					182, 97, 118, 97, 105, 108, 97, 98, 108, 101,
					95, 99, 111, 110, 116, 105, 110, 117, 101, 95,
					110, 117, 109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_free_continue_time()
			{
				return new byte[19]
				{
					178, 102, 114, 101, 101, 95, 99, 111, 110, 116,
					105, 110, 117, 101, 95, 116, 105, 109, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_shortened_race_state()
			{
				return new byte[21]
				{
					180, 115, 104, 111, 114, 116, 101, 110, 101, 100,
					95, 114, 97, 99, 101, 95, 115, 116, 97, 116,
					101
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeHomeInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(6);
				writer.WriteRaw(GetSpan_command_info_array());
				resolver.GetFormatterWithVerify<SingleModeCommandInfo[]>().Serialize(ref writer, value.command_info_array, options);
				writer.WriteRaw(GetSpan_race_entry_restriction());
				writer.Write(value.race_entry_restriction);
				writer.WriteRaw(GetSpan_disable_command_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.disable_command_id_array, options);
				writer.WriteRaw(GetSpan_available_continue_num());
				writer.Write(value.available_continue_num);
				writer.WriteRaw(GetSpan_free_continue_time());
				writer.Write(value.free_continue_time);
				writer.WriteRaw(GetSpan_shortened_race_state());
				writer.Write(value.shortened_race_state);
			}

			public SingleModeHomeInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeHomeInfo singleModeHomeInfo = new SingleModeHomeInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 18:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6873740296000991075L)
						{
							if (key == 7957688327961145958L && span.SequenceEqual(GetSpan_free_continue_time().Slice(9)))
							{
								singleModeHomeInfo.free_continue_time = reader.ReadInt64();
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_command_info_array().Slice(9)))
						{
							singleModeHomeInfo.command_info_array = resolver.GetFormatterWithVerify<SingleModeCommandInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 22:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7809911822066218593L)
						{
							if (key == 8389754616235123058L && span.SequenceEqual(GetSpan_race_entry_restriction().Slice(9)))
							{
								singleModeHomeInfo.race_entry_restriction = reader.ReadInt32();
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_available_continue_num().Slice(9)))
						{
							singleModeHomeInfo.available_continue_num = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 24:
						if (span.SequenceEqual(GetSpan_disable_command_id_array().Slice(1)))
						{
							singleModeHomeInfo.disable_command_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 20:
						if (span.SequenceEqual(GetSpan_shortened_race_state().Slice(1)))
						{
							singleModeHomeInfo.shortened_race_state = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleModeHomeInfo;
			}
		}

		internal sealed class SingleModeLiveCommandInfoFormatter : IMessagePackFormatter<SingleModeLiveCommandInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_type()
			{
				return new byte[13]
				{
					172, 99, 111, 109, 109, 97, 110, 100, 95, 116,
					121, 112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_id()
			{
				return new byte[11]
				{
					170, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_params_inc_dec_info_array()
			{
				return new byte[26]
				{
					185, 112, 97, 114, 97, 109, 115, 95, 105, 110,
					99, 95, 100, 101, 99, 95, 105, 110, 102, 111,
					95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeLiveCommandInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_command_type());
				writer.Write(value.command_type);
				writer.WriteRaw(GetSpan_command_id());
				writer.Write(value.command_id);
				writer.WriteRaw(GetSpan_params_inc_dec_info_array());
				resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Serialize(ref writer, value.params_inc_dec_info_array, options);
			}

			public SingleModeLiveCommandInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeLiveCommandInfo singleModeLiveCommandInfo = new SingleModeLiveCommandInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 10)
					{
						if (length != 12)
						{
							if (length == 25 && span.SequenceEqual(GetSpan_params_inc_dec_info_array().Slice(1)))
							{
								singleModeLiveCommandInfo.params_inc_dec_info_array = resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_command_type().Slice(1)))
						{
							singleModeLiveCommandInfo.command_type = reader.ReadInt32();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_command_id().Slice(1)))
					{
						singleModeLiveCommandInfo.command_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeLiveCommandInfo;
			}
		}

		internal sealed class SingleModeLiveDataSetFormatter : IMessagePackFormatter<SingleModeLiveDataSet>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_info_array()
			{
				return new byte[19]
				{
					178, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					110, 102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeLiveDataSet value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(1);
				writer.WriteRaw(GetSpan_command_info_array());
				resolver.GetFormatterWithVerify<SingleModeLiveCommandInfo[]>().Serialize(ref writer, value.command_info_array, options);
			}

			public SingleModeLiveDataSet Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeLiveDataSet singleModeLiveDataSet = new SingleModeLiveDataSet();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					if (span.Length != 18 || !span.SequenceEqual(GetSpan_command_info_array().Slice(1)))
					{
						reader.Skip();
					}
					else
					{
						singleModeLiveDataSet.command_info_array = resolver.GetFormatterWithVerify<SingleModeLiveCommandInfo[]>().Deserialize(ref reader, options);
					}
				}
				reader.Depth--;
				return singleModeLiveDataSet;
			}
		}

		internal sealed class SingleModeNpcResultFormatter : IMessagePackFormatter<SingleModeNpcResult>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_npc_id()
			{
				return new byte[7] { 166, 110, 112, 99, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_result_rank()
			{
				return new byte[12]
				{
					171, 114, 101, 115, 117, 108, 116, 95, 114, 97,
					110, 107
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeNpcResult value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_npc_id());
				writer.Write(value.npc_id);
				writer.WriteRaw(GetSpan_result_rank());
				writer.Write(value.result_rank);
			}

			public SingleModeNpcResult Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeNpcResult singleModeNpcResult = new SingleModeNpcResult();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 6)
					{
						if (length == 11 && span.SequenceEqual(GetSpan_result_rank().Slice(1)))
						{
							singleModeNpcResult.result_rank = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 110403734696046L)
					{
						singleModeNpcResult.npc_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeNpcResult;
			}
		}

		internal sealed class SingleModeParamsIncDecInfoFormatter : IMessagePackFormatter<SingleModeParamsIncDecInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_target_type()
			{
				return new byte[12]
				{
					171, 116, 97, 114, 103, 101, 116, 95, 116, 121,
					112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_value()
			{
				return new byte[6] { 165, 118, 97, 108, 117, 101 };
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeParamsIncDecInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_target_type());
				writer.Write(value.target_type);
				writer.WriteRaw(GetSpan_value());
				writer.Write(value.value);
			}

			public SingleModeParamsIncDecInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeParamsIncDecInfo singleModeParamsIncDecInfo = new SingleModeParamsIncDecInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 5)
					{
						if (length == 11 && span.SequenceEqual(GetSpan_target_type().Slice(1)))
						{
							singleModeParamsIncDecInfo.target_type = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 435761734006L)
					{
						singleModeParamsIncDecInfo.value = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeParamsIncDecInfo;
			}
		}

		internal sealed class SingleModeRaceConditionFormatter : IMessagePackFormatter<SingleModeRaceCondition>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_program_id()
			{
				return new byte[11]
				{
					170, 112, 114, 111, 103, 114, 97, 109, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_weather()
			{
				return new byte[8] { 167, 119, 101, 97, 116, 104, 101, 114 };
			}

			private static ReadOnlySpan<byte> GetSpan_ground_condition()
			{
				return new byte[17]
				{
					176, 103, 114, 111, 117, 110, 100, 95, 99, 111,
					110, 100, 105, 116, 105, 111, 110
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeRaceCondition value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_program_id());
				writer.Write(value.program_id);
				writer.WriteRaw(GetSpan_weather());
				writer.Write(value.weather);
				writer.WriteRaw(GetSpan_ground_condition());
				writer.Write(value.ground_condition);
			}

			public SingleModeRaceCondition Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeRaceCondition singleModeRaceCondition = new SingleModeRaceCondition();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 7)
					{
						if (length != 10)
						{
							if (length == 16 && span.SequenceEqual(GetSpan_ground_condition().Slice(1)))
							{
								singleModeRaceCondition.ground_condition = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_program_id().Slice(1)))
						{
							singleModeRaceCondition.program_id = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 32199646648558967L)
					{
						singleModeRaceCondition.weather = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeRaceCondition;
			}
		}

		internal sealed class SingleModeRivalRaceInfoFormatter : IMessagePackFormatter<SingleModeRivalRaceInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_program_id()
			{
				return new byte[11]
				{
					170, 112, 114, 111, 103, 114, 97, 109, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeRivalRaceInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_program_id());
				writer.Write(value.program_id);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
			}

			public SingleModeRivalRaceInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeRivalRaceInfo singleModeRivalRaceInfo = new SingleModeRivalRaceInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 8)
					{
						if (length == 10 && span.SequenceEqual(GetSpan_program_id().Slice(1)))
						{
							singleModeRivalRaceInfo.program_id = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 7235419148482865251L)
					{
						singleModeRivalRaceInfo.chara_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeRivalRaceInfo;
			}
		}

		internal sealed class SingleModeSportCommandInfoFormatter : IMessagePackFormatter<global::Gallop.SingleModeSportCommandInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_type()
			{
				return new byte[13]
				{
					172, 99, 111, 109, 109, 97, 110, 100, 95, 116,
					121, 112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_id()
			{
				return new byte[11]
				{
					170, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_params_inc_dec_info_array()
			{
				return new byte[26]
				{
					185, 112, 97, 114, 97, 109, 115, 95, 105, 110,
					99, 95, 100, 101, 99, 95, 105, 110, 102, 111,
					95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_gain_sport_rank_array()
			{
				return new byte[22]
				{
					181, 103, 97, 105, 110, 95, 115, 112, 111, 114,
					116, 95, 114, 97, 110, 107, 95, 97, 114, 114,
					97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, global::Gallop.SingleModeSportCommandInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(4);
				writer.WriteRaw(GetSpan_command_type());
				writer.Write(value.command_type);
				writer.WriteRaw(GetSpan_command_id());
				writer.Write(value.command_id);
				writer.WriteRaw(GetSpan_params_inc_dec_info_array());
				resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Serialize(ref writer, value.params_inc_dec_info_array, options);
				writer.WriteRaw(GetSpan_gain_sport_rank_array());
				resolver.GetFormatterWithVerify<global::Gallop.SingleModeSportCommandInfo.SingleModeSportGainRank[]>().Serialize(ref writer, value.gain_sport_rank_array, options);
			}

			public global::Gallop.SingleModeSportCommandInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				global::Gallop.SingleModeSportCommandInfo singleModeSportCommandInfo = new global::Gallop.SingleModeSportCommandInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length <= 12)
					{
						if (length != 10)
						{
							if (length == 12 && span.SequenceEqual(GetSpan_command_type().Slice(1)))
							{
								singleModeSportCommandInfo.command_type = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_command_id().Slice(1)))
						{
							singleModeSportCommandInfo.command_id = reader.ReadInt32();
							continue;
						}
					}
					else if (length != 21)
					{
						if (length == 25 && span.SequenceEqual(GetSpan_params_inc_dec_info_array().Slice(1)))
						{
							singleModeSportCommandInfo.params_inc_dec_info_array = resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Deserialize(ref reader, options);
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_gain_sport_rank_array().Slice(1)))
					{
						singleModeSportCommandInfo.gain_sport_rank_array = resolver.GetFormatterWithVerify<global::Gallop.SingleModeSportCommandInfo.SingleModeSportGainRank[]>().Deserialize(ref reader, options);
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeSportCommandInfo;
			}
		}

		internal sealed class SingleModeSportCompetitionResultFormatter : IMessagePackFormatter<SingleModeSportCompetitionResult>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_compe_type()
			{
				return new byte[11]
				{
					170, 99, 111, 109, 112, 101, 95, 116, 121, 112,
					101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_result_state()
			{
				return new byte[13]
				{
					172, 114, 101, 115, 117, 108, 116, 95, 115, 116,
					97, 116, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_win_command_id_array()
			{
				return new byte[21]
				{
					180, 119, 105, 110, 95, 99, 111, 109, 109, 97,
					110, 100, 95, 105, 100, 95, 97, 114, 114, 97,
					121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_prize_command_id_array()
			{
				return new byte[23]
				{
					182, 112, 114, 105, 122, 101, 95, 99, 111, 109,
					109, 97, 110, 100, 95, 105, 100, 95, 97, 114,
					114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeSportCompetitionResult value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(4);
				writer.WriteRaw(GetSpan_compe_type());
				writer.Write(value.compe_type);
				writer.WriteRaw(GetSpan_result_state());
				writer.Write(value.result_state);
				writer.WriteRaw(GetSpan_win_command_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.win_command_id_array, options);
				writer.WriteRaw(GetSpan_prize_command_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.prize_command_id_array, options);
			}

			public SingleModeSportCompetitionResult Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeSportCompetitionResult singleModeSportCompetitionResult = new SingleModeSportCompetitionResult();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length <= 12)
					{
						if (length != 10)
						{
							if (length == 12 && span.SequenceEqual(GetSpan_result_state().Slice(1)))
							{
								singleModeSportCompetitionResult.result_state = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_compe_type().Slice(1)))
						{
							singleModeSportCompetitionResult.compe_type = reader.ReadInt32();
							continue;
						}
					}
					else if (length != 20)
					{
						if (length == 22 && span.SequenceEqual(GetSpan_prize_command_id_array().Slice(1)))
						{
							singleModeSportCompetitionResult.prize_command_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_win_command_id_array().Slice(1)))
					{
						singleModeSportCompetitionResult.win_command_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeSportCompetitionResult;
			}
		}

		internal sealed class SingleModeSportDataSetFormatter : IMessagePackFormatter<SingleModeSportDataSet>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_training_array()
			{
				return new byte[15]
				{
					174, 116, 114, 97, 105, 110, 105, 110, 103, 95,
					97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_info_array()
			{
				return new byte[19]
				{
					178, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					110, 102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_item_id_array()
			{
				return new byte[14]
				{
					173, 105, 116, 101, 109, 95, 105, 100, 95, 97,
					114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_effected_item_id_array()
			{
				return new byte[23]
				{
					182, 101, 102, 102, 101, 99, 116, 101, 100, 95,
					105, 116, 101, 109, 95, 105, 100, 95, 97, 114,
					114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_competition_result_array()
			{
				return new byte[25]
				{
					184, 99, 111, 109, 112, 101, 116, 105, 116, 105,
					111, 110, 95, 114, 101, 115, 117, 108, 116, 95,
					97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_effected_stance_array()
			{
				return new byte[22]
				{
					181, 101, 102, 102, 101, 99, 116, 101, 100, 95,
					115, 116, 97, 110, 99, 101, 95, 97, 114, 114,
					97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_compe_effect_id_array()
			{
				return new byte[22]
				{
					181, 99, 111, 109, 112, 101, 95, 101, 102, 102,
					101, 99, 116, 95, 105, 100, 95, 97, 114, 114,
					97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeSportDataSet value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(7);
				writer.WriteRaw(GetSpan_training_array());
				resolver.GetFormatterWithVerify<SingleModeSportTraining[]>().Serialize(ref writer, value.training_array, options);
				writer.WriteRaw(GetSpan_command_info_array());
				resolver.GetFormatterWithVerify<global::Gallop.SingleModeSportCommandInfo[]>().Serialize(ref writer, value.command_info_array, options);
				writer.WriteRaw(GetSpan_item_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.item_id_array, options);
				writer.WriteRaw(GetSpan_effected_item_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.effected_item_id_array, options);
				writer.WriteRaw(GetSpan_competition_result_array());
				resolver.GetFormatterWithVerify<SingleModeSportCompetitionResult[]>().Serialize(ref writer, value.competition_result_array, options);
				writer.WriteRaw(GetSpan_effected_stance_array());
				resolver.GetFormatterWithVerify<SingleModeSportEffectedStance[]>().Serialize(ref writer, value.effected_stance_array, options);
				writer.WriteRaw(GetSpan_compe_effect_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.compe_effect_id_array, options);
			}

			public SingleModeSportDataSet Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeSportDataSet singleModeSportDataSet = new SingleModeSportDataSet();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 14:
						if (span.SequenceEqual(GetSpan_training_array().Slice(1)))
						{
							singleModeSportDataSet.training_array = resolver.GetFormatterWithVerify<SingleModeSportTraining[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 18:
						if (span.SequenceEqual(GetSpan_command_info_array().Slice(1)))
						{
							singleModeSportDataSet.command_info_array = resolver.GetFormatterWithVerify<global::Gallop.SingleModeSportCommandInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 13:
						if (span.SequenceEqual(GetSpan_item_id_array().Slice(1)))
						{
							singleModeSportDataSet.item_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 22:
						if (span.SequenceEqual(GetSpan_effected_item_id_array().Slice(1)))
						{
							singleModeSportDataSet.effected_item_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 24:
						if (span.SequenceEqual(GetSpan_competition_result_array().Slice(1)))
						{
							singleModeSportDataSet.competition_result_array = resolver.GetFormatterWithVerify<SingleModeSportCompetitionResult[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 21:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7234316346692363877L)
						{
							if (key == 7378408453798981475L && span.SequenceEqual(GetSpan_compe_effect_id_array().Slice(9)))
							{
								singleModeSportDataSet.compe_effect_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_effected_stance_array().Slice(9)))
						{
							singleModeSportDataSet.effected_stance_array = resolver.GetFormatterWithVerify<SingleModeSportEffectedStance[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					}
				}
				reader.Depth--;
				return singleModeSportDataSet;
			}
		}

		internal sealed class SingleModeSportEffectedStanceFormatter : IMessagePackFormatter<SingleModeSportEffectedStance>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_stance_id()
			{
				return new byte[10] { 169, 115, 116, 97, 110, 99, 101, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_remain_count()
			{
				return new byte[13]
				{
					172, 114, 101, 109, 97, 105, 110, 95, 99, 111,
					117, 110, 116
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeSportEffectedStance value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_stance_id());
				writer.Write(value.stance_id);
				writer.WriteRaw(GetSpan_remain_count());
				writer.Write(value.remain_count);
			}

			public SingleModeSportEffectedStance Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeSportEffectedStance singleModeSportEffectedStance = new SingleModeSportEffectedStance();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 9)
					{
						if (length == 12 && span.SequenceEqual(GetSpan_remain_count().Slice(1)))
						{
							singleModeSportEffectedStance.remain_count = reader.ReadInt32();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_stance_id().Slice(1)))
					{
						singleModeSportEffectedStance.stance_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeSportEffectedStance;
			}
		}

		internal sealed class SingleModeSportTrainingFormatter : IMessagePackFormatter<SingleModeSportTraining>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_type()
			{
				return new byte[13]
				{
					172, 99, 111, 109, 109, 97, 110, 100, 95, 116,
					121, 112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_id()
			{
				return new byte[11]
				{
					170, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_sport_rank()
			{
				return new byte[11]
				{
					170, 115, 112, 111, 114, 116, 95, 114, 97, 110,
					107
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeSportTraining value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_command_type());
				writer.Write(value.command_type);
				writer.WriteRaw(GetSpan_command_id());
				writer.Write(value.command_id);
				writer.WriteRaw(GetSpan_sport_rank());
				writer.Write(value.sport_rank);
			}

			public SingleModeSportTraining Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeSportTraining singleModeSportTraining = new SingleModeSportTraining();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 10)
					{
						if (length == 12 && span.SequenceEqual(GetSpan_command_type().Slice(1)))
						{
							singleModeSportTraining.command_type = reader.ReadInt32();
							continue;
						}
					}
					else
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6873740296000991075L)
						{
							if (key == 7021779722764775539L && AutomataKeyGen.GetKey(ref span) == 27502)
							{
								singleModeSportTraining.sport_rank = reader.ReadInt32();
								continue;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 25705)
						{
							singleModeSportTraining.command_id = reader.ReadInt32();
							continue;
						}
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeSportTraining;
			}
		}

		internal sealed class SingleModeSuccessionEventInfoFormatter : IMessagePackFormatter<SingleModeSuccessionEventInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_effect_type()
			{
				return new byte[12]
				{
					171, 101, 102, 102, 101, 99, 116, 95, 116, 121,
					112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_succession_gain_info_array()
			{
				return new byte[27]
				{
					186, 115, 117, 99, 99, 101, 115, 115, 105, 111,
					110, 95, 103, 97, 105, 110, 95, 105, 110, 102,
					111, 95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeSuccessionEventInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_effect_type());
				writer.Write(value.effect_type);
				writer.WriteRaw(GetSpan_succession_gain_info_array());
				resolver.GetFormatterWithVerify<SingleModeSuccessionGainInfo[]>().Serialize(ref writer, value.succession_gain_info_array, options);
			}

			public SingleModeSuccessionEventInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeSuccessionEventInfo singleModeSuccessionEventInfo = new SingleModeSuccessionEventInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 11)
					{
						if (length == 26 && span.SequenceEqual(GetSpan_succession_gain_info_array().Slice(1)))
						{
							singleModeSuccessionEventInfo.succession_gain_info_array = resolver.GetFormatterWithVerify<SingleModeSuccessionGainInfo[]>().Deserialize(ref reader, options);
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_effect_type().Slice(1)))
					{
						singleModeSuccessionEventInfo.effect_type = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeSuccessionEventInfo;
			}
		}

		internal sealed class SingleModeSuccessionGainInfoFormatter : IMessagePackFormatter<SingleModeSuccessionGainInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_lottery_id()
			{
				return new byte[11]
				{
					170, 108, 111, 116, 116, 101, 114, 121, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_speed()
			{
				return new byte[6] { 165, 115, 112, 101, 101, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_stamina()
			{
				return new byte[8] { 167, 115, 116, 97, 109, 105, 110, 97 };
			}

			private static ReadOnlySpan<byte> GetSpan_power()
			{
				return new byte[6] { 165, 112, 111, 119, 101, 114 };
			}

			private static ReadOnlySpan<byte> GetSpan_wiz()
			{
				return new byte[4] { 163, 119, 105, 122 };
			}

			private static ReadOnlySpan<byte> GetSpan_guts()
			{
				return new byte[5] { 164, 103, 117, 116, 115 };
			}

			private static ReadOnlySpan<byte> GetSpan_max_speed()
			{
				return new byte[10] { 169, 109, 97, 120, 95, 115, 112, 101, 101, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_max_stamina()
			{
				return new byte[12]
				{
					171, 109, 97, 120, 95, 115, 116, 97, 109, 105,
					110, 97
				};
			}

			private static ReadOnlySpan<byte> GetSpan_max_power()
			{
				return new byte[10] { 169, 109, 97, 120, 95, 112, 111, 119, 101, 114 };
			}

			private static ReadOnlySpan<byte> GetSpan_max_wiz()
			{
				return new byte[8] { 167, 109, 97, 120, 95, 119, 105, 122 };
			}

			private static ReadOnlySpan<byte> GetSpan_max_guts()
			{
				return new byte[9] { 168, 109, 97, 120, 95, 103, 117, 116, 115 };
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_short()
			{
				return new byte[22]
				{
					181, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 115, 104, 111,
					114, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_mile()
			{
				return new byte[21]
				{
					180, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 109, 105, 108,
					101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_middle()
			{
				return new byte[23]
				{
					182, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 109, 105, 100,
					100, 108, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_long()
			{
				return new byte[21]
				{
					180, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 108, 111, 110,
					103
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_nige()
			{
				return new byte[26]
				{
					185, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 110, 105, 103, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_senko()
			{
				return new byte[27]
				{
					186, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 115, 101, 110, 107, 111
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_sashi()
			{
				return new byte[27]
				{
					186, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 115, 97, 115, 104, 105
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_oikomi()
			{
				return new byte[28]
				{
					187, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 111, 105, 107, 111, 109, 105
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_ground_turf()
			{
				return new byte[19]
				{
					178, 112, 114, 111, 112, 101, 114, 95, 103, 114,
					111, 117, 110, 100, 95, 116, 117, 114, 102
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_ground_dirt()
			{
				return new byte[19]
				{
					178, 112, 114, 111, 112, 101, 114, 95, 103, 114,
					111, 117, 110, 100, 95, 100, 105, 114, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_skill_point()
			{
				return new byte[12]
				{
					171, 115, 107, 105, 108, 108, 95, 112, 111, 105,
					110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_skill_tips_array()
			{
				return new byte[17]
				{
					176, 115, 107, 105, 108, 108, 95, 116, 105, 112,
					115, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_effected_factor_array()
			{
				return new byte[22]
				{
					181, 101, 102, 102, 101, 99, 116, 101, 100, 95,
					102, 97, 99, 116, 111, 114, 95, 97, 114, 114,
					97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeSuccessionGainInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(24);
				writer.WriteRaw(GetSpan_lottery_id());
				writer.Write(value.lottery_id);
				writer.WriteRaw(GetSpan_speed());
				writer.Write(value.speed);
				writer.WriteRaw(GetSpan_stamina());
				writer.Write(value.stamina);
				writer.WriteRaw(GetSpan_power());
				writer.Write(value.power);
				writer.WriteRaw(GetSpan_wiz());
				writer.Write(value.wiz);
				writer.WriteRaw(GetSpan_guts());
				writer.Write(value.guts);
				writer.WriteRaw(GetSpan_max_speed());
				writer.Write(value.max_speed);
				writer.WriteRaw(GetSpan_max_stamina());
				writer.Write(value.max_stamina);
				writer.WriteRaw(GetSpan_max_power());
				writer.Write(value.max_power);
				writer.WriteRaw(GetSpan_max_wiz());
				writer.Write(value.max_wiz);
				writer.WriteRaw(GetSpan_max_guts());
				writer.Write(value.max_guts);
				writer.WriteRaw(GetSpan_proper_distance_short());
				writer.Write(value.proper_distance_short);
				writer.WriteRaw(GetSpan_proper_distance_mile());
				writer.Write(value.proper_distance_mile);
				writer.WriteRaw(GetSpan_proper_distance_middle());
				writer.Write(value.proper_distance_middle);
				writer.WriteRaw(GetSpan_proper_distance_long());
				writer.Write(value.proper_distance_long);
				writer.WriteRaw(GetSpan_proper_running_style_nige());
				writer.Write(value.proper_running_style_nige);
				writer.WriteRaw(GetSpan_proper_running_style_senko());
				writer.Write(value.proper_running_style_senko);
				writer.WriteRaw(GetSpan_proper_running_style_sashi());
				writer.Write(value.proper_running_style_sashi);
				writer.WriteRaw(GetSpan_proper_running_style_oikomi());
				writer.Write(value.proper_running_style_oikomi);
				writer.WriteRaw(GetSpan_proper_ground_turf());
				writer.Write(value.proper_ground_turf);
				writer.WriteRaw(GetSpan_proper_ground_dirt());
				writer.Write(value.proper_ground_dirt);
				writer.WriteRaw(GetSpan_skill_point());
				writer.Write(value.skill_point);
				writer.WriteRaw(GetSpan_skill_tips_array());
				resolver.GetFormatterWithVerify<SkillTips[]>().Serialize(ref writer, value.skill_tips_array, options);
				writer.WriteRaw(GetSpan_effected_factor_array());
				resolver.GetFormatterWithVerify<SuccessionEffectedFactor[]>().Serialize(ref writer, value.effected_factor_array, options);
			}

			public SingleModeSuccessionGainInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeSuccessionGainInfo singleModeSuccessionGainInfo = new SingleModeSuccessionGainInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 10:
						if (span.SequenceEqual(GetSpan_lottery_id().Slice(1)))
						{
							singleModeSuccessionGainInfo.lottery_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 5:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 431197876339uL:
							singleModeSuccessionGainInfo.speed = reader.ReadInt32();
							goto end_IL_0046;
						case 491328597872uL:
							singleModeSuccessionGainInfo.power = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 7:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 27424471826658419uL:
							singleModeSuccessionGainInfo.stamina = reader.ReadInt32();
							goto end_IL_0046;
						case 34455908582449517uL:
							singleModeSuccessionGainInfo.max_wiz = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 3:
						if (AutomataKeyGen.GetKey(ref span) == 8022391)
						{
							singleModeSuccessionGainInfo.wiz = reader.ReadInt32();
							break;
						}
						goto default;
					case 4:
						if (AutomataKeyGen.GetKey(ref span) == 1937012071)
						{
							singleModeSuccessionGainInfo.guts = reader.ReadInt32();
							break;
						}
						goto default;
					case 9:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7306369611303772525L)
						{
							if (key == 7311435048488034669L && span[0] == 114)
							{
								singleModeSuccessionGainInfo.max_power = reader.ReadInt32();
								break;
							}
						}
						else if (span[0] == 100)
						{
							singleModeSuccessionGainInfo.max_speed = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 11:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7881708861746864493L)
						{
							if (key == 8030023054881549171L && AutomataKeyGen.GetKey(ref span) == 7630441)
							{
								singleModeSuccessionGainInfo.skill_point = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 6385257)
						{
							singleModeSuccessionGainInfo.max_stamina = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 8319403498503954797L)
						{
							singleModeSuccessionGainInfo.max_guts = reader.ReadInt32();
							break;
						}
						goto default;
					case 21:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7232625306583921264L)
						{
							if (key == 7234316346692363877L && span.SequenceEqual(GetSpan_effected_factor_array().Slice(9)))
							{
								singleModeSuccessionGainInfo.effected_factor_array = resolver.GetFormatterWithVerify<SuccessionEffectedFactor[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_proper_distance_short().Slice(9)))
						{
							singleModeSuccessionGainInfo.proper_distance_short = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 20:
						if (AutomataKeyGen.GetKey(ref span) == 7232625306583921264L && AutomataKeyGen.GetKey(ref span) == 6874009731983504233L)
						{
							switch (AutomataKeyGen.GetKey(ref span))
							{
							case 1701603693uL:
								singleModeSuccessionGainInfo.proper_distance_mile = reader.ReadInt32();
								goto end_IL_0046;
							case 1735290732uL:
								singleModeSuccessionGainInfo.proper_distance_long = reader.ReadInt32();
								goto end_IL_0046;
							}
						}
						goto default;
					case 22:
						if (span.SequenceEqual(GetSpan_proper_distance_middle().Slice(1)))
						{
							singleModeSuccessionGainInfo.proper_distance_middle = reader.ReadInt32();
							break;
						}
						goto default;
					case 25:
						if (span.SequenceEqual(GetSpan_proper_running_style_nige().Slice(1)))
						{
							singleModeSuccessionGainInfo.proper_running_style_nige = reader.ReadInt32();
							break;
						}
						goto default;
					case 26:
						if (AutomataKeyGen.GetKey(ref span) == 8241431623114912368L && AutomataKeyGen.GetKey(ref span) == 8313477161062133365L)
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 7954891170380544372L)
							{
								if (key == 8314053240663341428L && AutomataKeyGen.GetKey(ref span) == 26984)
								{
									singleModeSuccessionGainInfo.proper_running_style_sashi = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 28523)
							{
								singleModeSuccessionGainInfo.proper_running_style_senko = reader.ReadInt32();
								break;
							}
						}
						goto default;
					case 27:
						if (span.SequenceEqual(GetSpan_proper_running_style_oikomi().Slice(1)))
						{
							singleModeSuccessionGainInfo.proper_running_style_oikomi = reader.ReadInt32();
							break;
						}
						goto default;
					case 18:
						if (AutomataKeyGen.GetKey(ref span) == 7448798088697705072L)
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 7594299756608057202L)
							{
								if (key == 8463494484690562930L && AutomataKeyGen.GetKey(ref span) == 26226)
								{
									singleModeSuccessionGainInfo.proper_ground_turf = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 29810)
							{
								singleModeSuccessionGainInfo.proper_ground_dirt = reader.ReadInt32();
								break;
							}
						}
						goto default;
					case 16:
						{
							if (span.SequenceEqual(GetSpan_skill_tips_array().Slice(1)))
							{
								singleModeSuccessionGainInfo.skill_tips_array = resolver.GetFormatterWithVerify<SkillTips[]>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						}
						end_IL_0046:
						break;
					}
				}
				reader.Depth--;
				return singleModeSuccessionGainInfo;
			}
		}

		internal sealed class SingleModeSupportCardFormatter : IMessagePackFormatter<SingleModeSupportCard>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_position()
			{
				return new byte[9] { 168, 112, 111, 115, 105, 116, 105, 111, 110 };
			}

			private static ReadOnlySpan<byte> GetSpan_support_card_id()
			{
				return new byte[16]
				{
					175, 115, 117, 112, 112, 111, 114, 116, 95, 99,
					97, 114, 100, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_limit_break_count()
			{
				return new byte[18]
				{
					177, 108, 105, 109, 105, 116, 95, 98, 114, 101,
					97, 107, 95, 99, 111, 117, 110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_exp()
			{
				return new byte[4] { 163, 101, 120, 112 };
			}

			private static ReadOnlySpan<byte> GetSpan_training_partner_state()
			{
				return new byte[23]
				{
					182, 116, 114, 97, 105, 110, 105, 110, 103, 95,
					112, 97, 114, 116, 110, 101, 114, 95, 115, 116,
					97, 116, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_owner_viewer_id()
			{
				return new byte[16]
				{
					175, 111, 119, 110, 101, 114, 95, 118, 105, 101,
					119, 101, 114, 95, 105, 100
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeSupportCard value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(6);
				writer.WriteRaw(GetSpan_position());
				writer.Write(value.position);
				writer.WriteRaw(GetSpan_support_card_id());
				writer.Write(value.support_card_id);
				writer.WriteRaw(GetSpan_limit_break_count());
				writer.Write(value.limit_break_count);
				writer.WriteRaw(GetSpan_exp());
				writer.Write(value.exp);
				writer.WriteRaw(GetSpan_training_partner_state());
				writer.Write(value.training_partner_state);
				writer.WriteRaw(GetSpan_owner_viewer_id());
				writer.Write(value.owner_viewer_id);
			}

			public SingleModeSupportCard Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeSupportCard singleModeSupportCard = new SingleModeSupportCard();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length <= 8)
					{
						if (length != 3)
						{
							if (length == 8 && AutomataKeyGen.GetKey(ref span) == 7957695015293251440L)
							{
								singleModeSupportCard.position = reader.ReadInt32();
								continue;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 7370853)
						{
							singleModeSupportCard.exp = reader.ReadInt32();
							continue;
						}
					}
					else if (length != 15)
					{
						if (length != 17)
						{
							if (length == 22 && span.SequenceEqual(GetSpan_training_partner_state().Slice(1)))
							{
								singleModeSupportCard.training_partner_state = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_limit_break_count().Slice(1)))
						{
							singleModeSupportCard.limit_break_count = reader.ReadInt32();
							continue;
						}
					}
					else
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6878248353854944627L)
						{
							if (key == 7599366366166939503L && AutomataKeyGen.GetKey(ref span) == 28263356333127525L)
							{
								singleModeSupportCard.owner_viewer_id = reader.ReadInt64();
								continue;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 28263356099092835L)
						{
							singleModeSupportCard.support_card_id = reader.ReadInt32();
							continue;
						}
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeSupportCard;
			}
		}

		internal sealed class SingleModeTeamCommandInfoFormatter : IMessagePackFormatter<SingleModeTeamCommandInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_type()
			{
				return new byte[13]
				{
					172, 99, 111, 109, 109, 97, 110, 100, 95, 116,
					121, 112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_id()
			{
				return new byte[11]
				{
					170, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_params_inc_dec_info_array()
			{
				return new byte[26]
				{
					185, 112, 97, 114, 97, 109, 115, 95, 105, 110,
					99, 95, 100, 101, 99, 95, 105, 110, 102, 111,
					95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeTeamCommandInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_command_type());
				writer.Write(value.command_type);
				writer.WriteRaw(GetSpan_command_id());
				writer.Write(value.command_id);
				writer.WriteRaw(GetSpan_params_inc_dec_info_array());
				resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Serialize(ref writer, value.params_inc_dec_info_array, options);
			}

			public SingleModeTeamCommandInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeTeamCommandInfo singleModeTeamCommandInfo = new SingleModeTeamCommandInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 10)
					{
						if (length != 12)
						{
							if (length == 25 && span.SequenceEqual(GetSpan_params_inc_dec_info_array().Slice(1)))
							{
								singleModeTeamCommandInfo.params_inc_dec_info_array = resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_command_type().Slice(1)))
						{
							singleModeTeamCommandInfo.command_type = reader.ReadInt32();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_command_id().Slice(1)))
					{
						singleModeTeamCommandInfo.command_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeTeamCommandInfo;
			}
		}

		internal sealed class SingleModeTeamDataSetFormatter : IMessagePackFormatter<SingleModeTeamDataSet>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_info_array()
			{
				return new byte[19]
				{
					178, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					110, 102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeTeamDataSet value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(1);
				writer.WriteRaw(GetSpan_command_info_array());
				resolver.GetFormatterWithVerify<SingleModeTeamCommandInfo[]>().Serialize(ref writer, value.command_info_array, options);
			}

			public SingleModeTeamDataSet Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeTeamDataSet singleModeTeamDataSet = new SingleModeTeamDataSet();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					if (span.Length != 18 || !span.SequenceEqual(GetSpan_command_info_array().Slice(1)))
					{
						reader.Skip();
					}
					else
					{
						singleModeTeamDataSet.command_info_array = resolver.GetFormatterWithVerify<SingleModeTeamCommandInfo[]>().Deserialize(ref reader, options);
					}
				}
				reader.Depth--;
				return singleModeTeamDataSet;
			}
		}

		internal sealed class SingleModeTwikleRaceNpcResultFormatter : IMessagePackFormatter<SingleModeTwikleRaceNpcResult>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_turn()
			{
				return new byte[5] { 164, 116, 117, 114, 110 };
			}

			private static ReadOnlySpan<byte> GetSpan_program_id()
			{
				return new byte[11]
				{
					170, 112, 114, 111, 103, 114, 97, 109, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_result_array()
			{
				return new byte[18]
				{
					177, 114, 97, 99, 101, 95, 114, 101, 115, 117,
					108, 116, 95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeTwikleRaceNpcResult value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_turn());
				writer.Write(value.turn);
				writer.WriteRaw(GetSpan_program_id());
				writer.Write(value.program_id);
				writer.WriteRaw(GetSpan_race_result_array());
				resolver.GetFormatterWithVerify<SingleModeNpcResult[]>().Serialize(ref writer, value.race_result_array, options);
			}

			public SingleModeTwikleRaceNpcResult Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeTwikleRaceNpcResult singleModeTwikleRaceNpcResult = new SingleModeTwikleRaceNpcResult();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 4)
					{
						if (length != 10)
						{
							if (length == 17 && span.SequenceEqual(GetSpan_race_result_array().Slice(1)))
							{
								singleModeTwikleRaceNpcResult.race_result_array = resolver.GetFormatterWithVerify<SingleModeNpcResult[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_program_id().Slice(1)))
						{
							singleModeTwikleRaceNpcResult.program_id = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 1852994932)
					{
						singleModeTwikleRaceNpcResult.turn = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeTwikleRaceNpcResult;
			}
		}

		internal sealed class SingleModeVenusActiveSpiritEffectFormatter : IMessagePackFormatter<SingleModeVenusActiveSpiritEffect>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_effect_group_id()
			{
				return new byte[16]
				{
					175, 101, 102, 102, 101, 99, 116, 95, 103, 114,
					111, 117, 112, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_begin_turn()
			{
				return new byte[11]
				{
					170, 98, 101, 103, 105, 110, 95, 116, 117, 114,
					110
				};
			}

			private static ReadOnlySpan<byte> GetSpan_end_turn()
			{
				return new byte[9] { 168, 101, 110, 100, 95, 116, 117, 114, 110 };
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeVenusActiveSpiritEffect value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(4);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
				writer.WriteRaw(GetSpan_effect_group_id());
				writer.Write(value.effect_group_id);
				writer.WriteRaw(GetSpan_begin_turn());
				writer.Write(value.begin_turn);
				writer.WriteRaw(GetSpan_end_turn());
				writer.Write(value.end_turn);
			}

			public SingleModeVenusActiveSpiritEffect Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeVenusActiveSpiritEffect singleModeVenusActiveSpiritEffect = new SingleModeVenusActiveSpiritEffect();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 8)
					{
						if (length != 10)
						{
							if (length == 15 && span.SequenceEqual(GetSpan_effect_group_id().Slice(1)))
							{
								singleModeVenusActiveSpiritEffect.effect_group_id = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_begin_turn().Slice(1)))
						{
							singleModeVenusActiveSpiritEffect.begin_turn = reader.ReadInt32();
							continue;
						}
					}
					else
					{
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 7235419148482865251uL:
							singleModeVenusActiveSpiritEffect.chara_id = reader.ReadInt32();
							continue;
						case 7958552634194161253uL:
							singleModeVenusActiveSpiritEffect.end_turn = reader.ReadInt32();
							continue;
						}
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeVenusActiveSpiritEffect;
			}
		}

		internal sealed class SingleModeVenusCharaCommandInfoFormatter : IMessagePackFormatter<SingleModeVenusCharaCommandInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_type()
			{
				return new byte[13]
				{
					172, 99, 111, 109, 109, 97, 110, 100, 95, 116,
					121, 112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_id()
			{
				return new byte[11]
				{
					170, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_spirit_id()
			{
				return new byte[10] { 169, 115, 112, 105, 114, 105, 116, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_is_boost()
			{
				return new byte[9] { 168, 105, 115, 95, 98, 111, 111, 115, 116 };
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeVenusCharaCommandInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(4);
				writer.WriteRaw(GetSpan_command_type());
				writer.Write(value.command_type);
				writer.WriteRaw(GetSpan_command_id());
				writer.Write(value.command_id);
				writer.WriteRaw(GetSpan_spirit_id());
				writer.Write(value.spirit_id);
				writer.WriteRaw(GetSpan_is_boost());
				writer.Write(value.is_boost);
			}

			public SingleModeVenusCharaCommandInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeVenusCharaCommandInfo singleModeVenusCharaCommandInfo = new SingleModeVenusCharaCommandInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 12:
						if (span.SequenceEqual(GetSpan_command_type().Slice(1)))
						{
							singleModeVenusCharaCommandInfo.command_type = reader.ReadInt32();
							break;
						}
						goto default;
					case 10:
						if (span.SequenceEqual(GetSpan_command_id().Slice(1)))
						{
							singleModeVenusCharaCommandInfo.command_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 9:
						if (span.SequenceEqual(GetSpan_spirit_id().Slice(1)))
						{
							singleModeVenusCharaCommandInfo.spirit_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 8391173054903841641L)
						{
							singleModeVenusCharaCommandInfo.is_boost = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleModeVenusCharaCommandInfo;
			}
		}

		internal sealed class SingleModeVenusCharaInfoFormatter : IMessagePackFormatter<SingleModeVenusCharaInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_venus_level()
			{
				return new byte[12]
				{
					171, 118, 101, 110, 117, 115, 95, 108, 101, 118,
					101, 108
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeVenusCharaInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
				writer.WriteRaw(GetSpan_venus_level());
				writer.Write(value.venus_level);
			}

			public SingleModeVenusCharaInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeVenusCharaInfo singleModeVenusCharaInfo = new SingleModeVenusCharaInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 8)
					{
						if (length == 11 && span.SequenceEqual(GetSpan_venus_level().Slice(1)))
						{
							singleModeVenusCharaInfo.venus_level = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 7235419148482865251L)
					{
						singleModeVenusCharaInfo.chara_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeVenusCharaInfo;
			}
		}

		internal sealed class SingleModeVenusCommandInfoFormatter : IMessagePackFormatter<SingleModeVenusCommandInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_type()
			{
				return new byte[13]
				{
					172, 99, 111, 109, 109, 97, 110, 100, 95, 116,
					121, 112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_id()
			{
				return new byte[11]
				{
					170, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_params_inc_dec_info_array()
			{
				return new byte[26]
				{
					185, 112, 97, 114, 97, 109, 115, 95, 105, 110,
					99, 95, 100, 101, 99, 95, 105, 110, 102, 111,
					95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeVenusCommandInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_command_type());
				writer.Write(value.command_type);
				writer.WriteRaw(GetSpan_command_id());
				writer.Write(value.command_id);
				writer.WriteRaw(GetSpan_params_inc_dec_info_array());
				resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Serialize(ref writer, value.params_inc_dec_info_array, options);
			}

			public SingleModeVenusCommandInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeVenusCommandInfo singleModeVenusCommandInfo = new SingleModeVenusCommandInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 10)
					{
						if (length != 12)
						{
							if (length == 25 && span.SequenceEqual(GetSpan_params_inc_dec_info_array().Slice(1)))
							{
								singleModeVenusCommandInfo.params_inc_dec_info_array = resolver.GetFormatterWithVerify<SingleModeParamsIncDecInfo[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_command_type().Slice(1)))
						{
							singleModeVenusCommandInfo.command_type = reader.ReadInt32();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_command_id().Slice(1)))
					{
						singleModeVenusCommandInfo.command_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeVenusCommandInfo;
			}
		}

		internal sealed class SingleModeVenusDataSetFormatter : IMessagePackFormatter<SingleModeVenusDataSet>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_race_start_info()
			{
				return new byte[16]
				{
					175, 114, 97, 99, 101, 95, 115, 116, 97, 114,
					116, 95, 105, 110, 102, 111
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_scenario()
			{
				return new byte[14]
				{
					173, 114, 97, 99, 101, 95, 115, 99, 101, 110,
					97, 114, 105, 111
				};
			}

			private static ReadOnlySpan<byte> GetSpan_command_info_array()
			{
				return new byte[19]
				{
					178, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					110, 102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_evaluation_info_array()
			{
				return new byte[22]
				{
					181, 101, 118, 97, 108, 117, 97, 116, 105, 111,
					110, 95, 105, 110, 102, 111, 95, 97, 114, 114,
					97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_spirit_info_array()
			{
				return new byte[18]
				{
					177, 115, 112, 105, 114, 105, 116, 95, 105, 110,
					102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_venus_spirit_active_effect_info_array()
			{
				return new byte[39]
				{
					217, 37, 118, 101, 110, 117, 115, 95, 115, 112,
					105, 114, 105, 116, 95, 97, 99, 116, 105, 118,
					101, 95, 101, 102, 102, 101, 99, 116, 95, 105,
					110, 102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_venus_chara_info_array()
			{
				return new byte[23]
				{
					182, 118, 101, 110, 117, 115, 95, 99, 104, 97,
					114, 97, 95, 105, 110, 102, 111, 95, 97, 114,
					114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_venus_chara_command_info_array()
			{
				return new byte[31]
				{
					190, 118, 101, 110, 117, 115, 95, 99, 104, 97,
					114, 97, 95, 99, 111, 109, 109, 97, 110, 100,
					95, 105, 110, 102, 111, 95, 97, 114, 114, 97,
					121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_venus_race_condition()
			{
				return new byte[21]
				{
					180, 118, 101, 110, 117, 115, 95, 114, 97, 99,
					101, 95, 99, 111, 110, 100, 105, 116, 105, 111,
					110
				};
			}

			private static ReadOnlySpan<byte> GetSpan_venus_race_history_array()
			{
				return new byte[25]
				{
					184, 118, 101, 110, 117, 115, 95, 114, 97, 99,
					101, 95, 104, 105, 115, 116, 111, 114, 121, 95,
					97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_reward_info()
			{
				return new byte[17]
				{
					176, 114, 97, 99, 101, 95, 114, 101, 119, 97,
					114, 100, 95, 105, 110, 102, 111
				};
			}

			private static ReadOnlySpan<byte> GetSpan_live_item_id()
			{
				return new byte[13]
				{
					172, 108, 105, 118, 101, 95, 105, 116, 101, 109,
					95, 105, 100
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeVenusDataSet value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(12);
				writer.WriteRaw(GetSpan_race_start_info());
				resolver.GetFormatterWithVerify<SingleRaceStartInfo>().Serialize(ref writer, value.race_start_info, options);
				writer.WriteRaw(GetSpan_race_scenario());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.race_scenario, options);
				writer.WriteRaw(GetSpan_command_info_array());
				resolver.GetFormatterWithVerify<SingleModeVenusCommandInfo[]>().Serialize(ref writer, value.command_info_array, options);
				writer.WriteRaw(GetSpan_evaluation_info_array());
				resolver.GetFormatterWithVerify<SingleModeVenusEvaluationInfo[]>().Serialize(ref writer, value.evaluation_info_array, options);
				writer.WriteRaw(GetSpan_spirit_info_array());
				resolver.GetFormatterWithVerify<SingleModeVenusSpiritInfo[]>().Serialize(ref writer, value.spirit_info_array, options);
				writer.WriteRaw(GetSpan_venus_spirit_active_effect_info_array());
				resolver.GetFormatterWithVerify<SingleModeVenusActiveSpiritEffect[]>().Serialize(ref writer, value.venus_spirit_active_effect_info_array, options);
				writer.WriteRaw(GetSpan_venus_chara_info_array());
				resolver.GetFormatterWithVerify<SingleModeVenusCharaInfo[]>().Serialize(ref writer, value.venus_chara_info_array, options);
				writer.WriteRaw(GetSpan_venus_chara_command_info_array());
				resolver.GetFormatterWithVerify<SingleModeVenusCharaCommandInfo[]>().Serialize(ref writer, value.venus_chara_command_info_array, options);
				writer.WriteRaw(GetSpan_venus_race_condition());
				resolver.GetFormatterWithVerify<SingleModeRaceCondition>().Serialize(ref writer, value.venus_race_condition, options);
				writer.WriteRaw(GetSpan_venus_race_history_array());
				resolver.GetFormatterWithVerify<SingleModeVenusRaceHistory[]>().Serialize(ref writer, value.venus_race_history_array, options);
				writer.WriteRaw(GetSpan_race_reward_info());
				resolver.GetFormatterWithVerify<CharaRaceReward>().Serialize(ref writer, value.race_reward_info, options);
				writer.WriteRaw(GetSpan_live_item_id());
				writer.Write(value.live_item_id);
			}

			public SingleModeVenusDataSet Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleModeVenusDataSet singleModeVenusDataSet = new SingleModeVenusDataSet();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 15:
						if (span.SequenceEqual(GetSpan_race_start_info().Slice(1)))
						{
							singleModeVenusDataSet.race_start_info = resolver.GetFormatterWithVerify<SingleRaceStartInfo>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 13:
						if (span.SequenceEqual(GetSpan_race_scenario().Slice(1)))
						{
							singleModeVenusDataSet.race_scenario = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 18:
						if (span.SequenceEqual(GetSpan_command_info_array().Slice(1)))
						{
							singleModeVenusDataSet.command_info_array = resolver.GetFormatterWithVerify<SingleModeVenusCommandInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 21:
						if (span.SequenceEqual(GetSpan_evaluation_info_array().Slice(1)))
						{
							singleModeVenusDataSet.evaluation_info_array = resolver.GetFormatterWithVerify<SingleModeVenusEvaluationInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 17:
						if (span.SequenceEqual(GetSpan_spirit_info_array().Slice(1)))
						{
							singleModeVenusDataSet.spirit_info_array = resolver.GetFormatterWithVerify<SingleModeVenusSpiritInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 37:
						if (span.SequenceEqual(GetSpan_venus_spirit_active_effect_info_array().Slice(2)))
						{
							singleModeVenusDataSet.venus_spirit_active_effect_info_array = resolver.GetFormatterWithVerify<SingleModeVenusActiveSpiritEffect[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 22:
						if (span.SequenceEqual(GetSpan_venus_chara_info_array().Slice(1)))
						{
							singleModeVenusDataSet.venus_chara_info_array = resolver.GetFormatterWithVerify<SingleModeVenusCharaInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 30:
						if (span.SequenceEqual(GetSpan_venus_chara_command_info_array().Slice(1)))
						{
							singleModeVenusDataSet.venus_chara_command_info_array = resolver.GetFormatterWithVerify<SingleModeVenusCharaCommandInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 20:
						if (span.SequenceEqual(GetSpan_venus_race_condition().Slice(1)))
						{
							singleModeVenusDataSet.venus_race_condition = resolver.GetFormatterWithVerify<SingleModeRaceCondition>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 24:
						if (span.SequenceEqual(GetSpan_venus_race_history_array().Slice(1)))
						{
							singleModeVenusDataSet.venus_race_history_array = resolver.GetFormatterWithVerify<SingleModeVenusRaceHistory[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 16:
						if (span.SequenceEqual(GetSpan_race_reward_info().Slice(1)))
						{
							singleModeVenusDataSet.race_reward_info = resolver.GetFormatterWithVerify<CharaRaceReward>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 12:
						if (span.SequenceEqual(GetSpan_live_item_id().Slice(1)))
						{
							singleModeVenusDataSet.live_item_id = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleModeVenusDataSet;
			}
		}

		internal sealed class SingleModeVenusEvaluationInfoFormatter : IMessagePackFormatter<SingleModeVenusEvaluationInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_target_id()
			{
				return new byte[10] { 169, 116, 97, 114, 103, 101, 116, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_chara_id()
			{
				return new byte[9] { 168, 99, 104, 97, 114, 97, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_member_state()
			{
				return new byte[13]
				{
					172, 109, 101, 109, 98, 101, 114, 95, 115, 116,
					97, 116, 101
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeVenusEvaluationInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_target_id());
				writer.Write(value.target_id);
				writer.WriteRaw(GetSpan_chara_id());
				writer.Write(value.chara_id);
				writer.WriteRaw(GetSpan_member_state());
				writer.Write(value.member_state);
			}

			public SingleModeVenusEvaluationInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeVenusEvaluationInfo singleModeVenusEvaluationInfo = new SingleModeVenusEvaluationInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 9:
						if (span.SequenceEqual(GetSpan_target_id().Slice(1)))
						{
							singleModeVenusEvaluationInfo.target_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 7235419148482865251L)
						{
							singleModeVenusEvaluationInfo.chara_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 12:
						if (span.SequenceEqual(GetSpan_member_state().Slice(1)))
						{
							singleModeVenusEvaluationInfo.member_state = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleModeVenusEvaluationInfo;
			}
		}

		internal sealed class SingleModeVenusRaceHistoryFormatter : IMessagePackFormatter<SingleModeVenusRaceHistory>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_race_num()
			{
				return new byte[9] { 168, 114, 97, 99, 101, 95, 110, 117, 109 };
			}

			private static ReadOnlySpan<byte> GetSpan_turn()
			{
				return new byte[5] { 164, 116, 117, 114, 110 };
			}

			private static ReadOnlySpan<byte> GetSpan_result_rank()
			{
				return new byte[12]
				{
					171, 114, 101, 115, 117, 108, 116, 95, 114, 97,
					110, 107
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeVenusRaceHistory value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_race_num());
				writer.Write(value.race_num);
				writer.WriteRaw(GetSpan_turn());
				writer.Write(value.turn);
				writer.WriteRaw(GetSpan_result_rank());
				writer.Write(value.result_rank);
			}

			public SingleModeVenusRaceHistory Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeVenusRaceHistory singleModeVenusRaceHistory = new SingleModeVenusRaceHistory();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 4)
					{
						if (length != 8)
						{
							if (length == 11 && span.SequenceEqual(GetSpan_result_rank().Slice(1)))
							{
								singleModeVenusRaceHistory.result_rank = reader.ReadInt32();
								continue;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 7887331678411252082L)
						{
							singleModeVenusRaceHistory.race_num = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 1852994932)
					{
						singleModeVenusRaceHistory.turn = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeVenusRaceHistory;
			}
		}

		internal sealed class SingleModeVenusSpiritInfoFormatter : IMessagePackFormatter<SingleModeVenusSpiritInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_spirit_num()
			{
				return new byte[11]
				{
					170, 115, 112, 105, 114, 105, 116, 95, 110, 117,
					109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_spirit_id()
			{
				return new byte[10] { 169, 115, 112, 105, 114, 105, 116, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_effect_group_id()
			{
				return new byte[16]
				{
					175, 101, 102, 102, 101, 99, 116, 95, 103, 114,
					111, 117, 112, 95, 105, 100
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleModeVenusSpiritInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_spirit_num());
				writer.Write(value.spirit_num);
				writer.WriteRaw(GetSpan_spirit_id());
				writer.Write(value.spirit_id);
				writer.WriteRaw(GetSpan_effect_group_id());
				writer.Write(value.effect_group_id);
			}

			public SingleModeVenusSpiritInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SingleModeVenusSpiritInfo singleModeVenusSpiritInfo = new SingleModeVenusSpiritInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 9)
					{
						if (length != 10)
						{
							if (length == 15 && span.SequenceEqual(GetSpan_effect_group_id().Slice(1)))
							{
								singleModeVenusSpiritInfo.effect_group_id = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_spirit_num().Slice(1)))
						{
							singleModeVenusSpiritInfo.spirit_num = reader.ReadInt32();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_spirit_id().Slice(1)))
					{
						singleModeVenusSpiritInfo.spirit_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return singleModeVenusSpiritInfo;
			}
		}

		internal sealed class SingleRaceStartInfoFormatter : IMessagePackFormatter<SingleRaceStartInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_program_id()
			{
				return new byte[11]
				{
					170, 112, 114, 111, 103, 114, 97, 109, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_random_seed()
			{
				return new byte[12]
				{
					171, 114, 97, 110, 100, 111, 109, 95, 115, 101,
					101, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_weather()
			{
				return new byte[8] { 167, 119, 101, 97, 116, 104, 101, 114 };
			}

			private static ReadOnlySpan<byte> GetSpan_ground_condition()
			{
				return new byte[17]
				{
					176, 103, 114, 111, 117, 110, 100, 95, 99, 111,
					110, 100, 105, 116, 105, 111, 110
				};
			}

			private static ReadOnlySpan<byte> GetSpan_race_horse_data()
			{
				return new byte[16]
				{
					175, 114, 97, 99, 101, 95, 104, 111, 114, 115,
					101, 95, 100, 97, 116, 97
				};
			}

			private static ReadOnlySpan<byte> GetSpan_continue_num()
			{
				return new byte[13]
				{
					172, 99, 111, 110, 116, 105, 110, 117, 101, 95,
					110, 117, 109
				};
			}

			public void Serialize(ref MessagePackWriter writer, SingleRaceStartInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(6);
				writer.WriteRaw(GetSpan_program_id());
				writer.Write(value.program_id);
				writer.WriteRaw(GetSpan_random_seed());
				writer.Write(value.random_seed);
				writer.WriteRaw(GetSpan_weather());
				writer.Write(value.weather);
				writer.WriteRaw(GetSpan_ground_condition());
				writer.Write(value.ground_condition);
				writer.WriteRaw(GetSpan_race_horse_data());
				resolver.GetFormatterWithVerify<RaceHorseData[]>().Serialize(ref writer, value.race_horse_data, options);
				writer.WriteRaw(GetSpan_continue_num());
				writer.Write(value.continue_num);
			}

			public SingleRaceStartInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SingleRaceStartInfo singleRaceStartInfo = new SingleRaceStartInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 10:
						if (span.SequenceEqual(GetSpan_program_id().Slice(1)))
						{
							singleRaceStartInfo.program_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 11:
						if (span.SequenceEqual(GetSpan_random_seed().Slice(1)))
						{
							singleRaceStartInfo.random_seed = reader.ReadInt32();
							break;
						}
						goto default;
					case 7:
						if (AutomataKeyGen.GetKey(ref span) == 32199646648558967L)
						{
							singleRaceStartInfo.weather = reader.ReadInt32();
							break;
						}
						goto default;
					case 16:
						if (span.SequenceEqual(GetSpan_ground_condition().Slice(1)))
						{
							singleRaceStartInfo.ground_condition = reader.ReadInt32();
							break;
						}
						goto default;
					case 15:
						if (span.SequenceEqual(GetSpan_race_horse_data().Slice(1)))
						{
							singleRaceStartInfo.race_horse_data = resolver.GetFormatterWithVerify<RaceHorseData[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 12:
						if (span.SequenceEqual(GetSpan_continue_num().Slice(1)))
						{
							singleRaceStartInfo.continue_num = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return singleRaceStartInfo;
			}
		}

		internal sealed class SkillDataFormatter : IMessagePackFormatter<SkillData>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_skill_id()
			{
				return new byte[9] { 168, 115, 107, 105, 108, 108, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_level()
			{
				return new byte[6] { 165, 108, 101, 118, 101, 108 };
			}

			public void Serialize(ref MessagePackWriter writer, SkillData value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_skill_id());
				writer.Write(value.skill_id);
				writer.WriteRaw(GetSpan_level());
				writer.Write(value.level);
			}

			public SkillData Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SkillData skillData = new SkillData();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 5)
					{
						if (length == 8 && AutomataKeyGen.GetKey(ref span) == 7235419195627367283L)
						{
							skillData.skill_id = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 465558725996L)
					{
						skillData.level = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return skillData;
			}
		}

		internal sealed class SkillTipsFormatter : IMessagePackFormatter<SkillTips>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_group_id()
			{
				return new byte[9] { 168, 103, 114, 111, 117, 112, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_rarity()
			{
				return new byte[7] { 166, 114, 97, 114, 105, 116, 121 };
			}

			private static ReadOnlySpan<byte> GetSpan_level()
			{
				return new byte[6] { 165, 108, 101, 118, 101, 108 };
			}

			public void Serialize(ref MessagePackWriter writer, SkillTips value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_group_id());
				writer.Write(value.group_id);
				writer.WriteRaw(GetSpan_rarity());
				writer.Write(value.rarity);
				writer.WriteRaw(GetSpan_level());
				writer.Write(value.level);
			}

			public SkillTips Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SkillTips skillTips = new SkillTips();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 7235419212958626407L)
						{
							skillTips.group_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 6:
						if (AutomataKeyGen.GetKey(ref span) == 133540892270962L)
						{
							skillTips.rarity = reader.ReadInt32();
							break;
						}
						goto default;
					case 5:
						if (AutomataKeyGen.GetKey(ref span) == 465558725996L)
						{
							skillTips.level = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return skillTips;
			}
		}

		internal sealed class SkillUpgradeInfoFormatter : IMessagePackFormatter<SkillUpgradeInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_condition_id()
			{
				return new byte[13]
				{
					172, 99, 111, 110, 100, 105, 116, 105, 111, 110,
					95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_total_count()
			{
				return new byte[12]
				{
					171, 116, 111, 116, 97, 108, 95, 99, 111, 117,
					110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_current_count()
			{
				return new byte[14]
				{
					173, 99, 117, 114, 114, 101, 110, 116, 95, 99,
					111, 117, 110, 116
				};
			}

			public void Serialize(ref MessagePackWriter writer, SkillUpgradeInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_condition_id());
				writer.Write(value.condition_id);
				writer.WriteRaw(GetSpan_total_count());
				writer.Write(value.total_count);
				writer.WriteRaw(GetSpan_current_count());
				writer.Write(value.current_count);
			}

			public SkillUpgradeInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				SkillUpgradeInfo skillUpgradeInfo = new SkillUpgradeInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 12:
						if (span.SequenceEqual(GetSpan_condition_id().Slice(1)))
						{
							skillUpgradeInfo.condition_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 11:
						if (span.SequenceEqual(GetSpan_total_count().Slice(1)))
						{
							skillUpgradeInfo.total_count = reader.ReadInt32();
							break;
						}
						goto default;
					case 13:
						if (span.SequenceEqual(GetSpan_current_count().Slice(1)))
						{
							skillUpgradeInfo.current_count = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return skillUpgradeInfo;
			}
		}

		internal sealed class SuccessionCharaFormatter : IMessagePackFormatter<SuccessionChara>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_position_id()
			{
				return new byte[12]
				{
					171, 112, 111, 115, 105, 116, 105, 111, 110, 95,
					105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_card_id()
			{
				return new byte[8] { 167, 99, 97, 114, 100, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_rank()
			{
				return new byte[5] { 164, 114, 97, 110, 107 };
			}

			private static ReadOnlySpan<byte> GetSpan_rarity()
			{
				return new byte[7] { 166, 114, 97, 114, 105, 116, 121 };
			}

			private static ReadOnlySpan<byte> GetSpan_talent_level()
			{
				return new byte[13]
				{
					172, 116, 97, 108, 101, 110, 116, 95, 108, 101,
					118, 101, 108
				};
			}

			private static ReadOnlySpan<byte> GetSpan_factor_info_array()
			{
				return new byte[18]
				{
					177, 102, 97, 99, 116, 111, 114, 95, 105, 110,
					102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_win_saddle_id_array()
			{
				return new byte[20]
				{
					179, 119, 105, 110, 95, 115, 97, 100, 100, 108,
					101, 95, 105, 100, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_owner_viewer_id()
			{
				return new byte[16]
				{
					175, 111, 119, 110, 101, 114, 95, 118, 105, 101,
					119, 101, 114, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_user_info_summary()
			{
				return new byte[18]
				{
					177, 117, 115, 101, 114, 95, 105, 110, 102, 111,
					95, 115, 117, 109, 109, 97, 114, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SuccessionChara value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(9);
				writer.WriteRaw(GetSpan_position_id());
				writer.Write(value.position_id);
				writer.WriteRaw(GetSpan_card_id());
				writer.Write(value.card_id);
				writer.WriteRaw(GetSpan_rank());
				writer.Write(value.rank);
				writer.WriteRaw(GetSpan_rarity());
				writer.Write(value.rarity);
				writer.WriteRaw(GetSpan_talent_level());
				writer.Write(value.talent_level);
				writer.WriteRaw(GetSpan_factor_info_array());
				resolver.GetFormatterWithVerify<FactorInfo[]>().Serialize(ref writer, value.factor_info_array, options);
				writer.WriteRaw(GetSpan_win_saddle_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.win_saddle_id_array, options);
				writer.WriteRaw(GetSpan_owner_viewer_id());
				writer.Write(value.owner_viewer_id);
				writer.WriteRaw(GetSpan_user_info_summary());
				resolver.GetFormatterWithVerify<UserInfoAtFriend>().Serialize(ref writer, value.user_info_summary, options);
			}

			public SuccessionChara Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SuccessionChara successionChara = new SuccessionChara();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 11:
						if (span.SequenceEqual(GetSpan_position_id().Slice(1)))
						{
							successionChara.position_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 7:
						if (AutomataKeyGen.GetKey(ref span) == 28263356099092835L)
						{
							successionChara.card_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 4:
						if (AutomataKeyGen.GetKey(ref span) == 1802396018)
						{
							successionChara.rank = reader.ReadInt32();
							break;
						}
						goto default;
					case 6:
						if (AutomataKeyGen.GetKey(ref span) == 133540892270962L)
						{
							successionChara.rarity = reader.ReadInt32();
							break;
						}
						goto default;
					case 12:
						if (span.SequenceEqual(GetSpan_talent_level().Slice(1)))
						{
							successionChara.talent_level = reader.ReadInt32();
							break;
						}
						goto default;
					case 17:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7380952697968882549L)
						{
							if (key == 7592913319789551974L && span.SequenceEqual(GetSpan_factor_info_array().Slice(9)))
							{
								successionChara.factor_info_array = resolver.GetFormatterWithVerify<FactorInfo[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_user_info_summary().Slice(9)))
						{
							successionChara.user_info_summary = resolver.GetFormatterWithVerify<UserInfoAtFriend>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 19:
						if (span.SequenceEqual(GetSpan_win_saddle_id_array().Slice(1)))
						{
							successionChara.win_saddle_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 15:
						if (span.SequenceEqual(GetSpan_owner_viewer_id().Slice(1)))
						{
							successionChara.owner_viewer_id = reader.ReadInt64();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return successionChara;
			}
		}

		internal sealed class SuccessionEffectedFactorFormatter : IMessagePackFormatter<SuccessionEffectedFactor>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_position()
			{
				return new byte[9] { 168, 112, 111, 115, 105, 116, 105, 111, 110 };
			}

			private static ReadOnlySpan<byte> GetSpan_factor_id_array()
			{
				return new byte[16]
				{
					175, 102, 97, 99, 116, 111, 114, 95, 105, 100,
					95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_factor_info_array()
			{
				return new byte[18]
				{
					177, 102, 97, 99, 116, 111, 114, 95, 105, 110,
					102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			public void Serialize(ref MessagePackWriter writer, SuccessionEffectedFactor value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_position());
				writer.Write(value.position);
				writer.WriteRaw(GetSpan_factor_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.factor_id_array, options);
				writer.WriteRaw(GetSpan_factor_info_array());
				resolver.GetFormatterWithVerify<FactorInfo[]>().Serialize(ref writer, value.factor_info_array, options);
			}

			public SuccessionEffectedFactor Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SuccessionEffectedFactor successionEffectedFactor = new SuccessionEffectedFactor();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 8)
					{
						if (length != 15)
						{
							if (length == 17 && span.SequenceEqual(GetSpan_factor_info_array().Slice(1)))
							{
								successionEffectedFactor.factor_info_array = resolver.GetFormatterWithVerify<FactorInfo[]>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_factor_id_array().Slice(1)))
						{
							successionEffectedFactor.factor_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 7957695015293251440L)
					{
						successionEffectedFactor.position = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return successionEffectedFactor;
			}
		}

		internal sealed class SuccessionHistoryFormatter : IMessagePackFormatter<SuccessionHistory>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_id()
			{
				return new byte[3] { 162, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_viewer_id()
			{
				return new byte[10] { 169, 118, 105, 101, 119, 101, 114, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_trained_chara_id()
			{
				return new byte[17]
				{
					176, 116, 114, 97, 105, 110, 101, 100, 95, 99,
					104, 97, 114, 97, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_hisotry_type()
			{
				return new byte[13]
				{
					172, 104, 105, 115, 111, 116, 114, 121, 95, 116,
					121, 112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_succession_card_id()
			{
				return new byte[19]
				{
					178, 115, 117, 99, 99, 101, 115, 115, 105, 111,
					110, 95, 99, 97, 114, 100, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_date()
			{
				return new byte[5] { 164, 100, 97, 116, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_user_name()
			{
				return new byte[10] { 169, 117, 115, 101, 114, 95, 110, 97, 109, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_circle_name()
			{
				return new byte[12]
				{
					171, 99, 105, 114, 99, 108, 101, 95, 110, 97,
					109, 101
				};
			}

			public void Serialize(ref MessagePackWriter writer, SuccessionHistory value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(8);
				writer.WriteRaw(GetSpan_id());
				writer.Write(value.id);
				writer.WriteRaw(GetSpan_viewer_id());
				writer.Write(value.viewer_id);
				writer.WriteRaw(GetSpan_trained_chara_id());
				writer.Write(value.trained_chara_id);
				writer.WriteRaw(GetSpan_hisotry_type());
				writer.Write(value.hisotry_type);
				writer.WriteRaw(GetSpan_succession_card_id());
				writer.Write(value.succession_card_id);
				writer.WriteRaw(GetSpan_date());
				writer.Write(value.date);
				writer.WriteRaw(GetSpan_user_name());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.user_name, options);
				writer.WriteRaw(GetSpan_circle_name());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.circle_name, options);
			}

			public SuccessionHistory Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				SuccessionHistory successionHistory = new SuccessionHistory();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 2:
						if (AutomataKeyGen.GetKey(ref span) == 25705)
						{
							successionHistory.id = reader.ReadInt32();
							break;
						}
						goto default;
					case 9:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7592913276890343798L)
						{
							if (key == 7881702179095278453L && span[0] == 101)
							{
								successionHistory.user_name = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span[0] == 100)
						{
							successionHistory.viewer_id = reader.ReadInt64();
							break;
						}
						goto default;
					}
					case 16:
						if (span.SequenceEqual(GetSpan_trained_chara_id().Slice(1)))
						{
							successionHistory.trained_chara_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 12:
						if (span.SequenceEqual(GetSpan_hisotry_type().Slice(1)))
						{
							successionHistory.hisotry_type = reader.ReadInt32();
							break;
						}
						goto default;
					case 18:
						if (span.SequenceEqual(GetSpan_succession_card_id().Slice(1)))
						{
							successionHistory.succession_card_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 4:
						if (AutomataKeyGen.GetKey(ref span) == 1702125924)
						{
							successionHistory.date = reader.ReadInt32();
							break;
						}
						goto default;
					case 11:
						if (span.SequenceEqual(GetSpan_circle_name().Slice(1)))
						{
							successionHistory.circle_name = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return successionHistory;
			}
		}

		internal sealed class TeamStadiumOpponentFormatter : IMessagePackFormatter<TeamStadiumOpponent>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_strength()
			{
				return new byte[9] { 168, 115, 116, 114, 101, 110, 103, 116, 104 };
			}

			private static ReadOnlySpan<byte> GetSpan_opponent_viewer_id()
			{
				return new byte[19]
				{
					178, 111, 112, 112, 111, 110, 101, 110, 116, 95,
					118, 105, 101, 119, 101, 114, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_evaluation_point()
			{
				return new byte[17]
				{
					176, 101, 118, 97, 108, 117, 97, 116, 105, 111,
					110, 95, 112, 111, 105, 110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_user_info()
			{
				return new byte[10] { 169, 117, 115, 101, 114, 95, 105, 110, 102, 111 };
			}

			private static ReadOnlySpan<byte> GetSpan_team_data_array()
			{
				return new byte[16]
				{
					175, 116, 101, 97, 109, 95, 100, 97, 116, 97,
					95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_trained_chara_array()
			{
				return new byte[20]
				{
					179, 116, 114, 97, 105, 110, 101, 100, 95, 99,
					104, 97, 114, 97, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_winning_reward_guarantee_status()
			{
				return new byte[32]
				{
					191, 119, 105, 110, 110, 105, 110, 103, 95, 114,
					101, 119, 97, 114, 100, 95, 103, 117, 97, 114,
					97, 110, 116, 101, 101, 95, 115, 116, 97, 116,
					117, 115
				};
			}

			public void Serialize(ref MessagePackWriter writer, TeamStadiumOpponent value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(7);
				writer.WriteRaw(GetSpan_strength());
				writer.Write(value.strength);
				writer.WriteRaw(GetSpan_opponent_viewer_id());
				writer.Write(value.opponent_viewer_id);
				writer.WriteRaw(GetSpan_evaluation_point());
				writer.Write(value.evaluation_point);
				writer.WriteRaw(GetSpan_user_info());
				resolver.GetFormatterWithVerify<UserInfoAtFriend>().Serialize(ref writer, value.user_info, options);
				writer.WriteRaw(GetSpan_team_data_array());
				resolver.GetFormatterWithVerify<TeamStadiumTeamData[]>().Serialize(ref writer, value.team_data_array, options);
				writer.WriteRaw(GetSpan_trained_chara_array());
				resolver.GetFormatterWithVerify<TrainedChara[]>().Serialize(ref writer, value.trained_chara_array, options);
				writer.WriteRaw(GetSpan_winning_reward_guarantee_status());
				writer.Write(value.winning_reward_guarantee_status);
			}

			public TeamStadiumOpponent Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				TeamStadiumOpponent teamStadiumOpponent = new TeamStadiumOpponent();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 7526754601089004659L)
						{
							teamStadiumOpponent.strength = reader.ReadInt32();
							break;
						}
						goto default;
					case 18:
						if (span.SequenceEqual(GetSpan_opponent_viewer_id().Slice(1)))
						{
							teamStadiumOpponent.opponent_viewer_id = reader.ReadInt64();
							break;
						}
						goto default;
					case 16:
						if (span.SequenceEqual(GetSpan_evaluation_point().Slice(1)))
						{
							teamStadiumOpponent.evaluation_point = reader.ReadInt32();
							break;
						}
						goto default;
					case 9:
						if (span.SequenceEqual(GetSpan_user_info().Slice(1)))
						{
							teamStadiumOpponent.user_info = resolver.GetFormatterWithVerify<UserInfoAtFriend>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 15:
						if (span.SequenceEqual(GetSpan_team_data_array().Slice(1)))
						{
							teamStadiumOpponent.team_data_array = resolver.GetFormatterWithVerify<TeamStadiumTeamData[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 19:
						if (span.SequenceEqual(GetSpan_trained_chara_array().Slice(1)))
						{
							teamStadiumOpponent.trained_chara_array = resolver.GetFormatterWithVerify<TrainedChara[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 31:
						if (span.SequenceEqual(GetSpan_winning_reward_guarantee_status().Slice(1)))
						{
							teamStadiumOpponent.winning_reward_guarantee_status = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return teamStadiumOpponent;
			}
		}

		internal sealed class TeamStadiumOpponentListResponseFormatter : IMessagePackFormatter<global::Gallop.TeamStadiumOpponentListResponse>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_data()
			{
				return new byte[5] { 164, 100, 97, 116, 97 };
			}

			public void Serialize(ref MessagePackWriter writer, global::Gallop.TeamStadiumOpponentListResponse value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(1);
				writer.WriteRaw(GetSpan_data());
				resolver.GetFormatterWithVerify<global::Gallop.TeamStadiumOpponentListResponse.CommonResponse>().Serialize(ref writer, value.data, options);
			}

			public global::Gallop.TeamStadiumOpponentListResponse Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				global::Gallop.TeamStadiumOpponentListResponse teamStadiumOpponentListResponse = new global::Gallop.TeamStadiumOpponentListResponse();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					if (span.Length != 4 || AutomataKeyGen.GetKey(ref span) != 1635017060)
					{
						reader.Skip();
					}
					else
					{
						teamStadiumOpponentListResponse.data = resolver.GetFormatterWithVerify<global::Gallop.TeamStadiumOpponentListResponse.CommonResponse>().Deserialize(ref reader, options);
					}
				}
				reader.Depth--;
				return teamStadiumOpponentListResponse;
			}
		}

		internal sealed class TeamStadiumTeamDataFormatter : IMessagePackFormatter<TeamStadiumTeamData>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_distance_type()
			{
				return new byte[14]
				{
					173, 100, 105, 115, 116, 97, 110, 99, 101, 95,
					116, 121, 112, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_member_id()
			{
				return new byte[10] { 169, 109, 101, 109, 98, 101, 114, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_trained_chara_id()
			{
				return new byte[17]
				{
					176, 116, 114, 97, 105, 110, 101, 100, 95, 99,
					104, 97, 114, 97, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_running_style()
			{
				return new byte[14]
				{
					173, 114, 117, 110, 110, 105, 110, 103, 95, 115,
					116, 121, 108, 101
				};
			}

			public void Serialize(ref MessagePackWriter writer, TeamStadiumTeamData value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(4);
				writer.WriteRaw(GetSpan_distance_type());
				writer.Write(value.distance_type);
				writer.WriteRaw(GetSpan_member_id());
				writer.Write(value.member_id);
				writer.WriteRaw(GetSpan_trained_chara_id());
				writer.Write(value.trained_chara_id);
				writer.WriteRaw(GetSpan_running_style());
				writer.Write(value.running_style);
			}

			public TeamStadiumTeamData Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				TeamStadiumTeamData teamStadiumTeamData = new TeamStadiumTeamData();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 9)
					{
						if (length != 13)
						{
							if (length == 16 && span.SequenceEqual(GetSpan_trained_chara_id().Slice(1)))
							{
								teamStadiumTeamData.trained_chara_id = reader.ReadInt32();
								continue;
							}
						}
						else
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 6874584755307705714L)
							{
								if (key == 7305804385369680228L && AutomataKeyGen.GetKey(ref span) == 435678704735L)
								{
									teamStadiumTeamData.distance_type = reader.ReadInt32();
									continue;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 435611595891L)
							{
								teamStadiumTeamData.running_style = reader.ReadInt32();
								continue;
							}
						}
					}
					else if (span.SequenceEqual(GetSpan_member_id().Slice(1)))
					{
						teamStadiumTeamData.member_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return teamStadiumTeamData;
			}
		}

		internal sealed class TeamStadiumUserFormatter : IMessagePackFormatter<TeamStadiumUser>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_team_class()
			{
				return new byte[11]
				{
					170, 116, 101, 97, 109, 95, 99, 108, 97, 115,
					115
				};
			}

			private static ReadOnlySpan<byte> GetSpan_best_team_class()
			{
				return new byte[16]
				{
					175, 98, 101, 115, 116, 95, 116, 101, 97, 109,
					95, 99, 108, 97, 115, 115
				};
			}

			private static ReadOnlySpan<byte> GetSpan_best_point()
			{
				return new byte[11]
				{
					170, 98, 101, 115, 116, 95, 112, 111, 105, 110,
					116
				};
			}

			public void Serialize(ref MessagePackWriter writer, TeamStadiumUser value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_team_class());
				writer.Write(value.team_class);
				writer.WriteRaw(GetSpan_best_team_class());
				writer.Write(value.best_team_class);
				writer.WriteRaw(GetSpan_best_point());
				writer.Write(value.best_point);
			}

			public TeamStadiumUser Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				TeamStadiumUser teamStadiumUser = new TeamStadiumUser();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 10)
					{
						if (length == 15 && span.SequenceEqual(GetSpan_best_team_class().Slice(1)))
						{
							teamStadiumUser.best_team_class = reader.ReadInt32();
							continue;
						}
					}
					else
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7020095180671903092L)
						{
							if (key == 7597414651675239778L && AutomataKeyGen.GetKey(ref span) == 29806)
							{
								teamStadiumUser.best_point = reader.ReadInt32();
								continue;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 29555)
						{
							teamStadiumUser.team_class = reader.ReadInt32();
							continue;
						}
					}
					reader.Skip();
				}
				reader.Depth--;
				return teamStadiumUser;
			}
		}

		internal sealed class TrainedCharaFormatter : IMessagePackFormatter<TrainedChara>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_viewer_id()
			{
				return new byte[10] { 169, 118, 105, 101, 119, 101, 114, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_trained_chara_id()
			{
				return new byte[17]
				{
					176, 116, 114, 97, 105, 110, 101, 100, 95, 99,
					104, 97, 114, 97, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_owner_viewer_id()
			{
				return new byte[16]
				{
					175, 111, 119, 110, 101, 114, 95, 118, 105, 101,
					119, 101, 114, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_use_type()
			{
				return new byte[9] { 168, 117, 115, 101, 95, 116, 121, 112, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_card_id()
			{
				return new byte[8] { 167, 99, 97, 114, 100, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_name()
			{
				return new byte[5] { 164, 110, 97, 109, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_stamina()
			{
				return new byte[8] { 167, 115, 116, 97, 109, 105, 110, 97 };
			}

			private static ReadOnlySpan<byte> GetSpan_speed()
			{
				return new byte[6] { 165, 115, 112, 101, 101, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_power()
			{
				return new byte[6] { 165, 112, 111, 119, 101, 114 };
			}

			private static ReadOnlySpan<byte> GetSpan_guts()
			{
				return new byte[5] { 164, 103, 117, 116, 115 };
			}

			private static ReadOnlySpan<byte> GetSpan_wiz()
			{
				return new byte[4] { 163, 119, 105, 122 };
			}

			private static ReadOnlySpan<byte> GetSpan_fans()
			{
				return new byte[5] { 164, 102, 97, 110, 115 };
			}

			private static ReadOnlySpan<byte> GetSpan_rank_score()
			{
				return new byte[11]
				{
					170, 114, 97, 110, 107, 95, 115, 99, 111, 114,
					101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_rank()
			{
				return new byte[5] { 164, 114, 97, 110, 107 };
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_short()
			{
				return new byte[22]
				{
					181, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 115, 104, 111,
					114, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_mile()
			{
				return new byte[21]
				{
					180, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 109, 105, 108,
					101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_middle()
			{
				return new byte[23]
				{
					182, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 109, 105, 100,
					100, 108, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_long()
			{
				return new byte[21]
				{
					180, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 108, 111, 110,
					103
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_nige()
			{
				return new byte[26]
				{
					185, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 110, 105, 103, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_senko()
			{
				return new byte[27]
				{
					186, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 115, 101, 110, 107, 111
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_sashi()
			{
				return new byte[27]
				{
					186, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 115, 97, 115, 104, 105
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_oikomi()
			{
				return new byte[28]
				{
					187, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 111, 105, 107, 111, 109, 105
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_ground_turf()
			{
				return new byte[19]
				{
					178, 112, 114, 111, 112, 101, 114, 95, 103, 114,
					111, 117, 110, 100, 95, 116, 117, 114, 102
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_ground_dirt()
			{
				return new byte[19]
				{
					178, 112, 114, 111, 112, 101, 114, 95, 103, 114,
					111, 117, 110, 100, 95, 100, 105, 114, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_succession_num()
			{
				return new byte[15]
				{
					174, 115, 117, 99, 99, 101, 115, 115, 105, 111,
					110, 95, 110, 117, 109
				};
			}

			private static ReadOnlySpan<byte> GetSpan_is_locked()
			{
				return new byte[10] { 169, 105, 115, 95, 108, 111, 99, 107, 101, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_rarity()
			{
				return new byte[7] { 166, 114, 97, 114, 105, 116, 121 };
			}

			private static ReadOnlySpan<byte> GetSpan_talent_level()
			{
				return new byte[13]
				{
					172, 116, 97, 108, 101, 110, 116, 95, 108, 101,
					118, 101, 108
				};
			}

			private static ReadOnlySpan<byte> GetSpan_chara_grade()
			{
				return new byte[12]
				{
					171, 99, 104, 97, 114, 97, 95, 103, 114, 97,
					100, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_running_style()
			{
				return new byte[14]
				{
					173, 114, 117, 110, 110, 105, 110, 103, 95, 115,
					116, 121, 108, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_nickname_id()
			{
				return new byte[12]
				{
					171, 110, 105, 99, 107, 110, 97, 109, 101, 95,
					105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_wins()
			{
				return new byte[5] { 164, 119, 105, 110, 115 };
			}

			private static ReadOnlySpan<byte> GetSpan_skill_array()
			{
				return new byte[12]
				{
					171, 115, 107, 105, 108, 108, 95, 97, 114, 114,
					97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_support_card_list()
			{
				return new byte[18]
				{
					177, 115, 117, 112, 112, 111, 114, 116, 95, 99,
					97, 114, 100, 95, 108, 105, 115, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_is_saved()
			{
				return new byte[9] { 168, 105, 115, 95, 115, 97, 118, 101, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_race_result_list()
			{
				return new byte[17]
				{
					176, 114, 97, 99, 101, 95, 114, 101, 115, 117,
					108, 116, 95, 108, 105, 115, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_win_saddle_id_array()
			{
				return new byte[20]
				{
					179, 119, 105, 110, 95, 115, 97, 100, 100, 108,
					101, 95, 105, 100, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_nickname_id_array()
			{
				return new byte[18]
				{
					177, 110, 105, 99, 107, 110, 97, 109, 101, 95,
					105, 100, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_factor_info_array()
			{
				return new byte[18]
				{
					177, 102, 97, 99, 116, 111, 114, 95, 105, 110,
					102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_factor_extend_array()
			{
				return new byte[20]
				{
					179, 102, 97, 99, 116, 111, 114, 95, 101, 120,
					116, 101, 110, 100, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_succession_chara_array()
			{
				return new byte[23]
				{
					182, 115, 117, 99, 99, 101, 115, 115, 105, 111,
					110, 95, 99, 104, 97, 114, 97, 95, 97, 114,
					114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_succession_history_array()
			{
				return new byte[25]
				{
					184, 115, 117, 99, 99, 101, 115, 115, 105, 111,
					110, 95, 104, 105, 115, 116, 111, 114, 121, 95,
					97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_scenario_id()
			{
				return new byte[12]
				{
					171, 115, 99, 101, 110, 97, 114, 105, 111, 95,
					105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_create_time()
			{
				return new byte[12]
				{
					171, 99, 114, 101, 97, 116, 101, 95, 116, 105,
					109, 101
				};
			}

			public void Serialize(ref MessagePackWriter writer, TrainedChara value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(44);
				writer.WriteRaw(GetSpan_viewer_id());
				writer.Write(value.viewer_id);
				writer.WriteRaw(GetSpan_trained_chara_id());
				writer.Write(value.trained_chara_id);
				writer.WriteRaw(GetSpan_owner_viewer_id());
				writer.Write(value.owner_viewer_id);
				writer.WriteRaw(GetSpan_use_type());
				writer.Write(value.use_type);
				writer.WriteRaw(GetSpan_card_id());
				writer.Write(value.card_id);
				writer.WriteRaw(GetSpan_name());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.name, options);
				writer.WriteRaw(GetSpan_stamina());
				writer.Write(value.stamina);
				writer.WriteRaw(GetSpan_speed());
				writer.Write(value.speed);
				writer.WriteRaw(GetSpan_power());
				writer.Write(value.power);
				writer.WriteRaw(GetSpan_guts());
				writer.Write(value.guts);
				writer.WriteRaw(GetSpan_wiz());
				writer.Write(value.wiz);
				writer.WriteRaw(GetSpan_fans());
				writer.Write(value.fans);
				writer.WriteRaw(GetSpan_rank_score());
				writer.Write(value.rank_score);
				writer.WriteRaw(GetSpan_rank());
				writer.Write(value.rank);
				writer.WriteRaw(GetSpan_proper_distance_short());
				writer.Write(value.proper_distance_short);
				writer.WriteRaw(GetSpan_proper_distance_mile());
				writer.Write(value.proper_distance_mile);
				writer.WriteRaw(GetSpan_proper_distance_middle());
				writer.Write(value.proper_distance_middle);
				writer.WriteRaw(GetSpan_proper_distance_long());
				writer.Write(value.proper_distance_long);
				writer.WriteRaw(GetSpan_proper_running_style_nige());
				writer.Write(value.proper_running_style_nige);
				writer.WriteRaw(GetSpan_proper_running_style_senko());
				writer.Write(value.proper_running_style_senko);
				writer.WriteRaw(GetSpan_proper_running_style_sashi());
				writer.Write(value.proper_running_style_sashi);
				writer.WriteRaw(GetSpan_proper_running_style_oikomi());
				writer.Write(value.proper_running_style_oikomi);
				writer.WriteRaw(GetSpan_proper_ground_turf());
				writer.Write(value.proper_ground_turf);
				writer.WriteRaw(GetSpan_proper_ground_dirt());
				writer.Write(value.proper_ground_dirt);
				writer.WriteRaw(GetSpan_succession_num());
				writer.Write(value.succession_num);
				writer.WriteRaw(GetSpan_is_locked());
				writer.Write(value.is_locked);
				writer.WriteRaw(GetSpan_rarity());
				writer.Write(value.rarity);
				writer.WriteRaw(GetSpan_talent_level());
				writer.Write(value.talent_level);
				writer.WriteRaw(GetSpan_chara_grade());
				writer.Write(value.chara_grade);
				writer.WriteRaw(GetSpan_running_style());
				writer.Write(value.running_style);
				writer.WriteRaw(GetSpan_nickname_id());
				writer.Write(value.nickname_id);
				writer.WriteRaw(GetSpan_wins());
				writer.Write(value.wins);
				writer.WriteRaw(GetSpan_skill_array());
				resolver.GetFormatterWithVerify<SkillData[]>().Serialize(ref writer, value.skill_array, options);
				writer.WriteRaw(GetSpan_support_card_list());
				resolver.GetFormatterWithVerify<TrainedCharaSupportCardList[]>().Serialize(ref writer, value.support_card_list, options);
				writer.WriteRaw(GetSpan_is_saved());
				writer.Write(value.is_saved);
				writer.WriteRaw(GetSpan_race_result_list());
				resolver.GetFormatterWithVerify<TrainedCharaRaceResult[]>().Serialize(ref writer, value.race_result_list, options);
				writer.WriteRaw(GetSpan_win_saddle_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.win_saddle_id_array, options);
				writer.WriteRaw(GetSpan_nickname_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.nickname_id_array, options);
				writer.WriteRaw(GetSpan_factor_info_array());
				resolver.GetFormatterWithVerify<FactorInfo[]>().Serialize(ref writer, value.factor_info_array, options);
				writer.WriteRaw(GetSpan_factor_extend_array());
				resolver.GetFormatterWithVerify<FactorExtendInfo[]>().Serialize(ref writer, value.factor_extend_array, options);
				writer.WriteRaw(GetSpan_succession_chara_array());
				resolver.GetFormatterWithVerify<SuccessionChara[]>().Serialize(ref writer, value.succession_chara_array, options);
				writer.WriteRaw(GetSpan_succession_history_array());
				resolver.GetFormatterWithVerify<SuccessionHistory[]>().Serialize(ref writer, value.succession_history_array, options);
				writer.WriteRaw(GetSpan_scenario_id());
				writer.Write(value.scenario_id);
				writer.WriteRaw(GetSpan_create_time());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.create_time, options);
			}

			public TrainedChara Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				TrainedChara trainedChara = new TrainedChara();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 9:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7308044150549476201L)
						{
							if (key == 7592913276890343798L && span[0] == 100)
							{
								trainedChara.viewer_id = reader.ReadInt64();
								break;
							}
						}
						else if (span[0] == 100)
						{
							trainedChara.is_locked = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 16:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6873730456163021428L)
						{
							if (key == 8315178041057960306L && AutomataKeyGen.GetKey(ref span) == 8391166444900215925L)
							{
								trainedChara.race_result_list = resolver.GetFormatterWithVerify<TrainedCharaRaceResult[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 7235419148482865251L)
						{
							trainedChara.trained_chara_id = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 15:
						if (span.SequenceEqual(GetSpan_owner_viewer_id().Slice(1)))
						{
							trainedChara.owner_viewer_id = reader.ReadInt64();
							break;
						}
						goto default;
					case 8:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 7309475735945966453uL:
							trainedChara.use_type = reader.ReadInt32();
							goto end_IL_0046;
						case 7234318537360110441uL:
							trainedChara.is_saved = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 7:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 28263356099092835uL:
							trainedChara.card_id = reader.ReadInt32();
							goto end_IL_0046;
						case 27424471826658419uL:
							trainedChara.stamina = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 4:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 1701667182uL:
							trainedChara.name = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							goto end_IL_0046;
						case 1937012071uL:
							trainedChara.guts = reader.ReadInt32();
							goto end_IL_0046;
						case 1936613734uL:
							trainedChara.fans = reader.ReadInt32();
							goto end_IL_0046;
						case 1802396018uL:
							trainedChara.rank = reader.ReadInt32();
							goto end_IL_0046;
						case 1936615799uL:
							trainedChara.wins = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 5:
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 431197876339uL:
							trainedChara.speed = reader.ReadInt32();
							goto end_IL_0046;
						case 491328597872uL:
							trainedChara.power = reader.ReadInt32();
							goto end_IL_0046;
						}
						goto default;
					case 3:
						if (AutomataKeyGen.GetKey(ref span) == 8022391)
						{
							trainedChara.wiz = reader.ReadInt32();
							break;
						}
						goto default;
					case 10:
						if (span.SequenceEqual(GetSpan_rank_score().Slice(1)))
						{
							trainedChara.rank_score = reader.ReadInt32();
							break;
						}
						goto default;
					case 21:
						if (span.SequenceEqual(GetSpan_proper_distance_short().Slice(1)))
						{
							trainedChara.proper_distance_short = reader.ReadInt32();
							break;
						}
						goto default;
					case 20:
						if (AutomataKeyGen.GetKey(ref span) == 7232625306583921264L && AutomataKeyGen.GetKey(ref span) == 6874009731983504233L)
						{
							switch (AutomataKeyGen.GetKey(ref span))
							{
							case 1701603693uL:
								trainedChara.proper_distance_mile = reader.ReadInt32();
								goto end_IL_0046;
							case 1735290732uL:
								trainedChara.proper_distance_long = reader.ReadInt32();
								goto end_IL_0046;
							}
						}
						goto default;
					case 22:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7232625306583921264L)
						{
							if (key == 7598543875600512371L && span.SequenceEqual(GetSpan_succession_chara_array().Slice(9)))
							{
								trainedChara.succession_chara_array = resolver.GetFormatterWithVerify<SuccessionChara[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_proper_distance_middle().Slice(9)))
						{
							trainedChara.proper_distance_middle = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 25:
						if (span.SequenceEqual(GetSpan_proper_running_style_nige().Slice(1)))
						{
							trainedChara.proper_running_style_nige = reader.ReadInt32();
							break;
						}
						goto default;
					case 26:
						if (AutomataKeyGen.GetKey(ref span) == 8241431623114912368L && AutomataKeyGen.GetKey(ref span) == 8313477161062133365L)
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 7954891170380544372L)
							{
								if (key == 8314053240663341428L && AutomataKeyGen.GetKey(ref span) == 26984)
								{
									trainedChara.proper_running_style_sashi = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 28523)
							{
								trainedChara.proper_running_style_senko = reader.ReadInt32();
								break;
							}
						}
						goto default;
					case 27:
						if (span.SequenceEqual(GetSpan_proper_running_style_oikomi().Slice(1)))
						{
							trainedChara.proper_running_style_oikomi = reader.ReadInt32();
							break;
						}
						goto default;
					case 18:
						if (AutomataKeyGen.GetKey(ref span) == 7448798088697705072L)
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 7594299756608057202L)
							{
								if (key == 8463494484690562930L && AutomataKeyGen.GetKey(ref span) == 26226)
								{
									trainedChara.proper_ground_turf = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 29810)
							{
								trainedChara.proper_ground_dirt = reader.ReadInt32();
								break;
							}
						}
						goto default;
					case 14:
						if (span.SequenceEqual(GetSpan_succession_num().Slice(1)))
						{
							trainedChara.succession_num = reader.ReadInt32();
							break;
						}
						goto default;
					case 6:
						if (AutomataKeyGen.GetKey(ref span) == 133540892270962L)
						{
							trainedChara.rarity = reader.ReadInt32();
							break;
						}
						goto default;
					case 12:
						if (span.SequenceEqual(GetSpan_talent_level().Slice(1)))
						{
							trainedChara.talent_level = reader.ReadInt32();
							break;
						}
						goto default;
					case 11:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key <= 8028073573554152307L)
						{
							if (key != 7308604897168157038L)
							{
								if (key == 8028073573554152307L && AutomataKeyGen.GetKey(ref span) == 6580575)
								{
									trainedChara.scenario_id = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 6580575)
							{
								trainedChara.nickname_id = reader.ReadInt32();
								break;
							}
						}
						else if (key != 8241973712344673139L)
						{
							if (key != 8243662515060435043L)
							{
								if (key == 8385532581711802979L && AutomataKeyGen.GetKey(ref span) == 6647145)
								{
									trainedChara.create_time = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 6644833)
							{
								trainedChara.chara_grade = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 7954802)
						{
							trainedChara.skill_array = resolver.GetFormatterWithVerify<SkillData[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 13:
						if (span.SequenceEqual(GetSpan_running_style().Slice(1)))
						{
							trainedChara.running_style = reader.ReadInt32();
							break;
						}
						goto default;
					case 17:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 6878248353854944627L)
						{
							if (key != 7308604897168157038L)
							{
								if (key == 7592913319789551974L && span.SequenceEqual(GetSpan_factor_info_array().Slice(9)))
								{
									trainedChara.factor_info_array = resolver.GetFormatterWithVerify<FactorInfo[]>().Deserialize(ref reader, options);
									break;
								}
							}
							else if (span.SequenceEqual(GetSpan_nickname_id_array().Slice(9)))
							{
								trainedChara.nickname_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_support_card_list().Slice(9)))
						{
							trainedChara.support_card_list = resolver.GetFormatterWithVerify<TrainedCharaSupportCardList[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 19:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7234014049614063991L)
						{
							if (key == 7304682943637840230L && span.SequenceEqual(GetSpan_factor_extend_array().Slice(9)))
							{
								trainedChara.factor_extend_array = resolver.GetFormatterWithVerify<FactorExtendInfo[]>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_win_saddle_id_array().Slice(9)))
						{
							trainedChara.win_saddle_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 24:
						{
							if (span.SequenceEqual(GetSpan_succession_history_array().Slice(1)))
							{
								trainedChara.succession_history_array = resolver.GetFormatterWithVerify<SuccessionHistory[]>().Deserialize(ref reader, options);
								break;
							}
							goto default;
						}
						end_IL_0046:
						break;
					}
				}
				reader.Depth--;
				return trainedChara;
			}
		}

		internal sealed class TrainedCharaFavoriteFormatter : IMessagePackFormatter<TrainedCharaFavorite>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_trained_chara_id()
			{
				return new byte[17]
				{
					176, 116, 114, 97, 105, 110, 101, 100, 95, 99,
					104, 97, 114, 97, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_icon_type()
			{
				return new byte[10] { 169, 105, 99, 111, 110, 95, 116, 121, 112, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_memo()
			{
				return new byte[5] { 164, 109, 101, 109, 111 };
			}

			public void Serialize(ref MessagePackWriter writer, TrainedCharaFavorite value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_trained_chara_id());
				writer.Write(value.trained_chara_id);
				writer.WriteRaw(GetSpan_icon_type());
				writer.Write(value.icon_type);
				writer.WriteRaw(GetSpan_memo());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.memo, options);
			}

			public TrainedCharaFavorite Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				TrainedCharaFavorite trainedCharaFavorite = new TrainedCharaFavorite();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 4)
					{
						if (length != 9)
						{
							if (length == 16 && span.SequenceEqual(GetSpan_trained_chara_id().Slice(1)))
							{
								trainedCharaFavorite.trained_chara_id = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_icon_type().Slice(1)))
						{
							trainedCharaFavorite.icon_type = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 1869440365)
					{
						trainedCharaFavorite.memo = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return trainedCharaFavorite;
			}
		}

		internal sealed class TrainedCharaLoadResponseFormatter : IMessagePackFormatter<global::Gallop.TrainedCharaLoadResponse>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_data()
			{
				return new byte[5] { 164, 100, 97, 116, 97 };
			}

			private static ReadOnlySpan<byte> GetSpan_data_headers()
			{
				return new byte[13]
				{
					172, 100, 97, 116, 97, 95, 104, 101, 97, 100,
					101, 114, 115
				};
			}

			public void Serialize(ref MessagePackWriter writer, global::Gallop.TrainedCharaLoadResponse value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_data());
				resolver.GetFormatterWithVerify<global::Gallop.TrainedCharaLoadResponse.CommonResponse>().Serialize(ref writer, value.data, options);
				writer.WriteRaw(GetSpan_data_headers());
				resolver.GetFormatterWithVerify<DataHeader>().Serialize(ref writer, value.data_headers, options);
			}

			public global::Gallop.TrainedCharaLoadResponse Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				global::Gallop.TrainedCharaLoadResponse trainedCharaLoadResponse = new global::Gallop.TrainedCharaLoadResponse();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 4)
					{
						if (length == 12 && span.SequenceEqual(GetSpan_data_headers().Slice(1)))
						{
							trainedCharaLoadResponse.data_headers = resolver.GetFormatterWithVerify<DataHeader>().Deserialize(ref reader, options);
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 1635017060)
					{
						trainedCharaLoadResponse.data = resolver.GetFormatterWithVerify<global::Gallop.TrainedCharaLoadResponse.CommonResponse>().Deserialize(ref reader, options);
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return trainedCharaLoadResponse;
			}
		}

		internal sealed class TrainedCharaRaceResultFormatter : IMessagePackFormatter<TrainedCharaRaceResult>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_turn()
			{
				return new byte[5] { 164, 116, 117, 114, 110 };
			}

			private static ReadOnlySpan<byte> GetSpan_program_id()
			{
				return new byte[11]
				{
					170, 112, 114, 111, 103, 114, 97, 109, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_weather()
			{
				return new byte[8] { 167, 119, 101, 97, 116, 104, 101, 114 };
			}

			private static ReadOnlySpan<byte> GetSpan_ground_condition()
			{
				return new byte[17]
				{
					176, 103, 114, 111, 117, 110, 100, 95, 99, 111,
					110, 100, 105, 116, 105, 111, 110
				};
			}

			private static ReadOnlySpan<byte> GetSpan_running_style()
			{
				return new byte[14]
				{
					173, 114, 117, 110, 110, 105, 110, 103, 95, 115,
					116, 121, 108, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_result_rank()
			{
				return new byte[12]
				{
					171, 114, 101, 115, 117, 108, 116, 95, 114, 97,
					110, 107
				};
			}

			public void Serialize(ref MessagePackWriter writer, TrainedCharaRaceResult value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(6);
				writer.WriteRaw(GetSpan_turn());
				writer.Write(value.turn);
				writer.WriteRaw(GetSpan_program_id());
				writer.Write(value.program_id);
				writer.WriteRaw(GetSpan_weather());
				writer.Write(value.weather);
				writer.WriteRaw(GetSpan_ground_condition());
				writer.Write(value.ground_condition);
				writer.WriteRaw(GetSpan_running_style());
				writer.Write(value.running_style);
				writer.WriteRaw(GetSpan_result_rank());
				writer.Write(value.result_rank);
			}

			public TrainedCharaRaceResult Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				TrainedCharaRaceResult trainedCharaRaceResult = new TrainedCharaRaceResult();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 4:
						if (AutomataKeyGen.GetKey(ref span) == 1852994932)
						{
							trainedCharaRaceResult.turn = reader.ReadInt32();
							break;
						}
						goto default;
					case 10:
						if (span.SequenceEqual(GetSpan_program_id().Slice(1)))
						{
							trainedCharaRaceResult.program_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 7:
						if (AutomataKeyGen.GetKey(ref span) == 32199646648558967L)
						{
							trainedCharaRaceResult.weather = reader.ReadInt32();
							break;
						}
						goto default;
					case 16:
						if (span.SequenceEqual(GetSpan_ground_condition().Slice(1)))
						{
							trainedCharaRaceResult.ground_condition = reader.ReadInt32();
							break;
						}
						goto default;
					case 13:
						if (span.SequenceEqual(GetSpan_running_style().Slice(1)))
						{
							trainedCharaRaceResult.running_style = reader.ReadInt32();
							break;
						}
						goto default;
					case 11:
						if (span.SequenceEqual(GetSpan_result_rank().Slice(1)))
						{
							trainedCharaRaceResult.result_rank = reader.ReadInt32();
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return trainedCharaRaceResult;
			}
		}

		internal sealed class TrainedCharaSupportCardListFormatter : IMessagePackFormatter<TrainedCharaSupportCardList>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_position()
			{
				return new byte[9] { 168, 112, 111, 115, 105, 116, 105, 111, 110 };
			}

			private static ReadOnlySpan<byte> GetSpan_support_card_id()
			{
				return new byte[16]
				{
					175, 115, 117, 112, 112, 111, 114, 116, 95, 99,
					97, 114, 100, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_exp()
			{
				return new byte[4] { 163, 101, 120, 112 };
			}

			private static ReadOnlySpan<byte> GetSpan_limit_break_count()
			{
				return new byte[18]
				{
					177, 108, 105, 109, 105, 116, 95, 98, 114, 101,
					97, 107, 95, 99, 111, 117, 110, 116
				};
			}

			public void Serialize(ref MessagePackWriter writer, TrainedCharaSupportCardList value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(4);
				writer.WriteRaw(GetSpan_position());
				writer.Write(value.position);
				writer.WriteRaw(GetSpan_support_card_id());
				writer.Write(value.support_card_id);
				writer.WriteRaw(GetSpan_exp());
				writer.Write(value.exp);
				writer.WriteRaw(GetSpan_limit_break_count());
				writer.Write(value.limit_break_count);
			}

			public TrainedCharaSupportCardList Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				TrainedCharaSupportCardList trainedCharaSupportCardList = new TrainedCharaSupportCardList();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length <= 8)
					{
						if (length != 3)
						{
							if (length == 8 && AutomataKeyGen.GetKey(ref span) == 7957695015293251440L)
							{
								trainedCharaSupportCardList.position = reader.ReadInt32();
								continue;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 7370853)
						{
							trainedCharaSupportCardList.exp = reader.ReadInt32();
							continue;
						}
					}
					else if (length != 15)
					{
						if (length == 17 && span.SequenceEqual(GetSpan_limit_break_count().Slice(1)))
						{
							trainedCharaSupportCardList.limit_break_count = reader.ReadInt32();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_support_card_id().Slice(1)))
					{
						trainedCharaSupportCardList.support_card_id = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return trainedCharaSupportCardList;
			}
		}

		internal sealed class TrainingLevelInfoFormatter : IMessagePackFormatter<TrainingLevelInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_command_id()
			{
				return new byte[11]
				{
					170, 99, 111, 109, 109, 97, 110, 100, 95, 105,
					100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_level()
			{
				return new byte[6] { 165, 108, 101, 118, 101, 108 };
			}

			public void Serialize(ref MessagePackWriter writer, TrainingLevelInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(2);
				writer.WriteRaw(GetSpan_command_id());
				writer.Write(value.command_id);
				writer.WriteRaw(GetSpan_level());
				writer.Write(value.level);
			}

			public TrainingLevelInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				TrainingLevelInfo trainingLevelInfo = new TrainingLevelInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 5)
					{
						if (length == 10 && span.SequenceEqual(GetSpan_command_id().Slice(1)))
						{
							trainingLevelInfo.command_id = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 465558725996L)
					{
						trainingLevelInfo.level = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return trainingLevelInfo;
			}
		}

		internal sealed class TrophyNumInfoFormatter : IMessagePackFormatter<TrophyNumInfo>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_grade_1()
			{
				return new byte[8] { 167, 103, 114, 97, 100, 101, 95, 49 };
			}

			private static ReadOnlySpan<byte> GetSpan_grade_2()
			{
				return new byte[8] { 167, 103, 114, 97, 100, 101, 95, 50 };
			}

			private static ReadOnlySpan<byte> GetSpan_grade_3()
			{
				return new byte[8] { 167, 103, 114, 97, 100, 101, 95, 51 };
			}

			private static ReadOnlySpan<byte> GetSpan_grade_ex()
			{
				return new byte[9] { 168, 103, 114, 97, 100, 101, 95, 101, 120 };
			}

			public void Serialize(ref MessagePackWriter writer, TrophyNumInfo value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(4);
				writer.WriteRaw(GetSpan_grade_1());
				writer.Write(value.grade_1);
				writer.WriteRaw(GetSpan_grade_2());
				writer.Write(value.grade_2);
				writer.WriteRaw(GetSpan_grade_3());
				writer.Write(value.grade_3);
				writer.WriteRaw(GetSpan_grade_ex());
				writer.Write(value.grade_ex);
			}

			public TrophyNumInfo Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				TrophyNumInfo trophyNumInfo = new TrophyNumInfo();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 7)
					{
						if (length == 8 && AutomataKeyGen.GetKey(ref span) == 8675445146279572071L)
						{
							trophyNumInfo.grade_ex = reader.ReadInt32();
							continue;
						}
					}
					else
					{
						switch (AutomataKeyGen.GetKey(ref span))
						{
						case 13897162939265639uL:
							trophyNumInfo.grade_1 = reader.ReadInt32();
							continue;
						case 14178637915976295uL:
							trophyNumInfo.grade_2 = reader.ReadInt32();
							continue;
						case 14460112892686951uL:
							trophyNumInfo.grade_3 = reader.ReadInt32();
							continue;
						}
					}
					reader.Skip();
				}
				reader.Depth--;
				return trophyNumInfo;
			}
		}

		internal sealed class UserFriendFormatter : IMessagePackFormatter<UserFriend>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_friend_viewer_id()
			{
				return new byte[17]
				{
					176, 102, 114, 105, 101, 110, 100, 95, 118, 105,
					101, 119, 101, 114, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_state()
			{
				return new byte[6] { 165, 115, 116, 97, 116, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_follow_time()
			{
				return new byte[12]
				{
					171, 102, 111, 108, 108, 111, 119, 95, 116, 105,
					109, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_follower_time()
			{
				return new byte[14]
				{
					173, 102, 111, 108, 108, 111, 119, 101, 114, 95,
					116, 105, 109, 101
				};
			}

			public void Serialize(ref MessagePackWriter writer, UserFriend value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(4);
				writer.WriteRaw(GetSpan_friend_viewer_id());
				writer.Write(value.friend_viewer_id);
				writer.WriteRaw(GetSpan_state());
				writer.Write(value.state);
				writer.WriteRaw(GetSpan_follow_time());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.follow_time, options);
				writer.WriteRaw(GetSpan_follower_time());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.follower_time, options);
			}

			public UserFriend Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				UserFriend userFriend = new UserFriend();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length <= 11)
					{
						if (length != 5)
						{
							if (length == 11 && span.SequenceEqual(GetSpan_follow_time().Slice(1)))
							{
								userFriend.follow_time = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
								continue;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 435744240755L)
						{
							userFriend.state = reader.ReadInt32();
							continue;
						}
					}
					else if (length != 13)
					{
						if (length == 16 && span.SequenceEqual(GetSpan_friend_viewer_id().Slice(1)))
						{
							userFriend.friend_viewer_id = reader.ReadInt64();
							continue;
						}
					}
					else if (span.SequenceEqual(GetSpan_follower_time().Slice(1)))
					{
						userFriend.follower_time = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return userFriend;
			}
		}

		internal sealed class UserInfoAtFriendFormatter : IMessagePackFormatter<UserInfoAtFriend>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_viewer_id()
			{
				return new byte[10] { 169, 118, 105, 101, 119, 101, 114, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_name()
			{
				return new byte[5] { 164, 110, 97, 109, 101 };
			}

			private static ReadOnlySpan<byte> GetSpan_honor_id()
			{
				return new byte[9] { 168, 104, 111, 110, 111, 114, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_last_login_time()
			{
				return new byte[16]
				{
					175, 108, 97, 115, 116, 95, 108, 111, 103, 105,
					110, 95, 116, 105, 109, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_leader_chara_id()
			{
				return new byte[16]
				{
					175, 108, 101, 97, 100, 101, 114, 95, 99, 104,
					97, 114, 97, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_support_card_id()
			{
				return new byte[16]
				{
					175, 115, 117, 112, 112, 111, 114, 116, 95, 99,
					97, 114, 100, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_comment()
			{
				return new byte[8] { 167, 99, 111, 109, 109, 101, 110, 116 };
			}

			private static ReadOnlySpan<byte> GetSpan_fan()
			{
				return new byte[4] { 163, 102, 97, 110 };
			}

			private static ReadOnlySpan<byte> GetSpan_directory_level()
			{
				return new byte[16]
				{
					175, 100, 105, 114, 101, 99, 116, 111, 114, 121,
					95, 108, 101, 118, 101, 108
				};
			}

			private static ReadOnlySpan<byte> GetSpan_rank_score()
			{
				return new byte[11]
				{
					170, 114, 97, 110, 107, 95, 115, 99, 111, 114,
					101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_team_stadium_win_count()
			{
				return new byte[23]
				{
					182, 116, 101, 97, 109, 95, 115, 116, 97, 100,
					105, 117, 109, 95, 119, 105, 110, 95, 99, 111,
					117, 110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_single_mode_play_count()
			{
				return new byte[23]
				{
					182, 115, 105, 110, 103, 108, 101, 95, 109, 111,
					100, 101, 95, 112, 108, 97, 121, 95, 99, 111,
					117, 110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_team_evaluation_point()
			{
				return new byte[22]
				{
					181, 116, 101, 97, 109, 95, 101, 118, 97, 108,
					117, 97, 116, 105, 111, 110, 95, 112, 111, 105,
					110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_best_team_evaluation_point()
			{
				return new byte[27]
				{
					186, 98, 101, 115, 116, 95, 116, 101, 97, 109,
					95, 101, 118, 97, 108, 117, 97, 116, 105, 111,
					110, 95, 112, 111, 105, 110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_friend_state()
			{
				return new byte[13]
				{
					172, 102, 114, 105, 101, 110, 100, 95, 115, 116,
					97, 116, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_circle_info()
			{
				return new byte[12]
				{
					171, 99, 105, 114, 99, 108, 101, 95, 105, 110,
					102, 111
				};
			}

			private static ReadOnlySpan<byte> GetSpan_circle_user()
			{
				return new byte[12]
				{
					171, 99, 105, 114, 99, 108, 101, 95, 117, 115,
					101, 114
				};
			}

			private static ReadOnlySpan<byte> GetSpan_user_support_card()
			{
				return new byte[18]
				{
					177, 117, 115, 101, 114, 95, 115, 117, 112, 112,
					111, 114, 116, 95, 99, 97, 114, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_leader_chara_dress_id()
			{
				return new byte[22]
				{
					181, 108, 101, 97, 100, 101, 114, 95, 99, 104,
					97, 114, 97, 95, 100, 114, 101, 115, 115, 95,
					105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_user_trained_chara()
			{
				return new byte[19]
				{
					178, 117, 115, 101, 114, 95, 116, 114, 97, 105,
					110, 101, 100, 95, 99, 104, 97, 114, 97
				};
			}

			private static ReadOnlySpan<byte> GetSpan_user_trained_chara_array()
			{
				return new byte[25]
				{
					184, 117, 115, 101, 114, 95, 116, 114, 97, 105,
					110, 101, 100, 95, 99, 104, 97, 114, 97, 95,
					97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_total_login_day_count()
			{
				return new byte[22]
				{
					181, 116, 111, 116, 97, 108, 95, 108, 111, 103,
					105, 110, 95, 100, 97, 121, 95, 99, 111, 117,
					110, 116
				};
			}

			public void Serialize(ref MessagePackWriter writer, UserInfoAtFriend value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(22);
				writer.WriteRaw(GetSpan_viewer_id());
				writer.Write(value.viewer_id);
				writer.WriteRaw(GetSpan_name());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.name, options);
				writer.WriteRaw(GetSpan_honor_id());
				writer.Write(value.honor_id);
				writer.WriteRaw(GetSpan_last_login_time());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.last_login_time, options);
				writer.WriteRaw(GetSpan_leader_chara_id());
				writer.Write(value.leader_chara_id);
				writer.WriteRaw(GetSpan_support_card_id());
				writer.Write(value.support_card_id);
				writer.WriteRaw(GetSpan_comment());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.comment, options);
				writer.WriteRaw(GetSpan_fan());
				writer.Write(value.fan);
				writer.WriteRaw(GetSpan_directory_level());
				writer.Write(value.directory_level);
				writer.WriteRaw(GetSpan_rank_score());
				writer.Write(value.rank_score);
				writer.WriteRaw(GetSpan_team_stadium_win_count());
				writer.Write(value.team_stadium_win_count);
				writer.WriteRaw(GetSpan_single_mode_play_count());
				writer.Write(value.single_mode_play_count);
				writer.WriteRaw(GetSpan_team_evaluation_point());
				writer.Write(value.team_evaluation_point);
				writer.WriteRaw(GetSpan_best_team_evaluation_point());
				writer.Write(value.best_team_evaluation_point);
				writer.WriteRaw(GetSpan_friend_state());
				writer.Write(value.friend_state);
				writer.WriteRaw(GetSpan_circle_info());
				resolver.GetFormatterWithVerify<CircleInfoAtFriend>().Serialize(ref writer, value.circle_info, options);
				writer.WriteRaw(GetSpan_circle_user());
				resolver.GetFormatterWithVerify<CircleUser>().Serialize(ref writer, value.circle_user, options);
				writer.WriteRaw(GetSpan_user_support_card());
				resolver.GetFormatterWithVerify<UserSupportCardAtFriend>().Serialize(ref writer, value.user_support_card, options);
				writer.WriteRaw(GetSpan_leader_chara_dress_id());
				writer.Write(value.leader_chara_dress_id);
				writer.WriteRaw(GetSpan_user_trained_chara());
				resolver.GetFormatterWithVerify<UserTrainedCharaAtFriend>().Serialize(ref writer, value.user_trained_chara, options);
				writer.WriteRaw(GetSpan_user_trained_chara_array());
				resolver.GetFormatterWithVerify<UserTrainedCharaAtFriend[]>().Serialize(ref writer, value.user_trained_chara_array, options);
				writer.WriteRaw(GetSpan_total_login_day_count());
				writer.Write(value.total_login_day_count);
			}

			public UserInfoAtFriend Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				UserInfoAtFriend userInfoAtFriend = new UserInfoAtFriend();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 9:
						if (span.SequenceEqual(GetSpan_viewer_id().Slice(1)))
						{
							userInfoAtFriend.viewer_id = reader.ReadInt64();
							break;
						}
						goto default;
					case 4:
						if (AutomataKeyGen.GetKey(ref span) == 1701667182)
						{
							userInfoAtFriend.name = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 8:
						if (AutomataKeyGen.GetKey(ref span) == 7235419221447831400L)
						{
							userInfoAtFriend.honor_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 15:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key <= 7160567712343745900L)
						{
							if (key != 6878248353854944627L)
							{
								if (key == 7160567712343745900L && AutomataKeyGen.GetKey(ref span) == 28263356048761192L)
								{
									userInfoAtFriend.leader_chara_id = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 28263356099092835L)
							{
								userInfoAtFriend.support_card_id = reader.ReadInt32();
								break;
							}
						}
						else if (key != 7453295065552871788L)
						{
							if (key == 8245937412991248740L && AutomataKeyGen.GetKey(ref span) == 30510856666898297L)
							{
								userInfoAtFriend.directory_level = reader.ReadInt32();
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 28549272339181161L)
						{
							userInfoAtFriend.last_login_time = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 7:
						if (AutomataKeyGen.GetKey(ref span) == 32772479205076835L)
						{
							userInfoAtFriend.comment = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 3:
						if (AutomataKeyGen.GetKey(ref span) == 7233894)
						{
							userInfoAtFriend.fan = reader.ReadUInt64();
							break;
						}
						goto default;
					case 10:
						if (span.SequenceEqual(GetSpan_rank_score().Slice(1)))
						{
							userInfoAtFriend.rank_score = reader.ReadInt32();
							break;
						}
						goto default;
					case 22:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7022364572671632756L)
						{
							if (key == 7881129389187819891L && span.SequenceEqual(GetSpan_single_mode_play_count().Slice(9)))
							{
								userInfoAtFriend.single_mode_play_count = reader.ReadInt32();
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_team_stadium_win_count().Slice(9)))
						{
							userInfoAtFriend.team_stadium_win_count = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 21:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7022912129462265204L)
						{
							if (key != 7160567712343745900L)
							{
								if (key == 8028897154790879092L && span.SequenceEqual(GetSpan_total_login_day_count().Slice(9)))
								{
									userInfoAtFriend.total_login_day_count = reader.ReadInt32();
									break;
								}
							}
							else if (span.SequenceEqual(GetSpan_leader_chara_dress_id().Slice(9)))
							{
								userInfoAtFriend.leader_chara_dress_id = reader.ReadInt32();
								break;
							}
						}
						else if (span.SequenceEqual(GetSpan_team_evaluation_point().Slice(9)))
						{
							userInfoAtFriend.team_evaluation_point = reader.ReadInt32();
							break;
						}
						goto default;
					}
					case 26:
						if (span.SequenceEqual(GetSpan_best_team_evaluation_point().Slice(1)))
						{
							userInfoAtFriend.best_team_evaluation_point = reader.ReadInt32();
							break;
						}
						goto default;
					case 12:
						if (span.SequenceEqual(GetSpan_friend_state().Slice(1)))
						{
							userInfoAtFriend.friend_state = reader.ReadInt32();
							break;
						}
						goto default;
					case 11:
					{
						ulong key = AutomataKeyGen.GetKey(ref span);
						if (key != 7592899012969261411L)
						{
							if (key == 8457590141424396643L && AutomataKeyGen.GetKey(ref span) == 7497075)
							{
								userInfoAtFriend.circle_user = resolver.GetFormatterWithVerify<CircleUser>().Deserialize(ref reader, options);
								break;
							}
						}
						else if (AutomataKeyGen.GetKey(ref span) == 7300718)
						{
							userInfoAtFriend.circle_info = resolver.GetFormatterWithVerify<CircleInfoAtFriend>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
					case 17:
						if (span.SequenceEqual(GetSpan_user_support_card().Slice(1)))
						{
							userInfoAtFriend.user_support_card = resolver.GetFormatterWithVerify<UserSupportCardAtFriend>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 18:
						if (span.SequenceEqual(GetSpan_user_trained_chara().Slice(1)))
						{
							userInfoAtFriend.user_trained_chara = resolver.GetFormatterWithVerify<UserTrainedCharaAtFriend>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 24:
						if (span.SequenceEqual(GetSpan_user_trained_chara_array().Slice(1)))
						{
							userInfoAtFriend.user_trained_chara_array = resolver.GetFormatterWithVerify<UserTrainedCharaAtFriend[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return userInfoAtFriend;
			}
		}

		internal sealed class UserSupportCardFormatter : IMessagePackFormatter<UserSupportCard>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_viewer_id()
			{
				return new byte[10] { 169, 118, 105, 101, 119, 101, 114, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_support_card_id()
			{
				return new byte[16]
				{
					175, 115, 117, 112, 112, 111, 114, 116, 95, 99,
					97, 114, 100, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_exp()
			{
				return new byte[4] { 163, 101, 120, 112 };
			}

			private static ReadOnlySpan<byte> GetSpan_limit_break_count()
			{
				return new byte[18]
				{
					177, 108, 105, 109, 105, 116, 95, 98, 114, 101,
					97, 107, 95, 99, 111, 117, 110, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_favorite_flag()
			{
				return new byte[14]
				{
					173, 102, 97, 118, 111, 114, 105, 116, 101, 95,
					102, 108, 97, 103
				};
			}

			private static ReadOnlySpan<byte> GetSpan_stock()
			{
				return new byte[6] { 165, 115, 116, 111, 99, 107 };
			}

			private static ReadOnlySpan<byte> GetSpan_possess_time()
			{
				return new byte[13]
				{
					172, 112, 111, 115, 115, 101, 115, 115, 95, 116,
					105, 109, 101
				};
			}

			public void Serialize(ref MessagePackWriter writer, UserSupportCard value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(7);
				writer.WriteRaw(GetSpan_viewer_id());
				writer.Write(value.viewer_id);
				writer.WriteRaw(GetSpan_support_card_id());
				writer.Write(value.support_card_id);
				writer.WriteRaw(GetSpan_exp());
				writer.Write(value.exp);
				writer.WriteRaw(GetSpan_limit_break_count());
				writer.Write(value.limit_break_count);
				writer.WriteRaw(GetSpan_favorite_flag());
				writer.Write(value.favorite_flag);
				writer.WriteRaw(GetSpan_stock());
				writer.Write(value.stock);
				writer.WriteRaw(GetSpan_possess_time());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.possess_time, options);
			}

			public UserSupportCard Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				UserSupportCard userSupportCard = new UserSupportCard();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 9:
						if (span.SequenceEqual(GetSpan_viewer_id().Slice(1)))
						{
							userSupportCard.viewer_id = reader.ReadInt64();
							break;
						}
						goto default;
					case 15:
						if (span.SequenceEqual(GetSpan_support_card_id().Slice(1)))
						{
							userSupportCard.support_card_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 3:
						if (AutomataKeyGen.GetKey(ref span) == 7370853)
						{
							userSupportCard.exp = reader.ReadInt32();
							break;
						}
						goto default;
					case 17:
						if (span.SequenceEqual(GetSpan_limit_break_count().Slice(1)))
						{
							userSupportCard.limit_break_count = reader.ReadInt32();
							break;
						}
						goto default;
					case 13:
						if (span.SequenceEqual(GetSpan_favorite_flag().Slice(1)))
						{
							userSupportCard.favorite_flag = reader.ReadInt32();
							break;
						}
						goto default;
					case 5:
						if (AutomataKeyGen.GetKey(ref span) == 461229749363L)
						{
							userSupportCard.stock = reader.ReadInt32();
							break;
						}
						goto default;
					case 12:
						if (span.SequenceEqual(GetSpan_possess_time().Slice(1)))
						{
							userSupportCard.possess_time = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					}
				}
				reader.Depth--;
				return userSupportCard;
			}
		}

		internal sealed class UserSupportCardAtFriendFormatter : IMessagePackFormatter<UserSupportCardAtFriend>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_support_card_id()
			{
				return new byte[16]
				{
					175, 115, 117, 112, 112, 111, 114, 116, 95, 99,
					97, 114, 100, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_exp()
			{
				return new byte[4] { 163, 101, 120, 112 };
			}

			private static ReadOnlySpan<byte> GetSpan_limit_break_count()
			{
				return new byte[18]
				{
					177, 108, 105, 109, 105, 116, 95, 98, 114, 101,
					97, 107, 95, 99, 111, 117, 110, 116
				};
			}

			public void Serialize(ref MessagePackWriter writer, UserSupportCardAtFriend value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				writer.WriteMapHeader(3);
				writer.WriteRaw(GetSpan_support_card_id());
				writer.Write(value.support_card_id);
				writer.WriteRaw(GetSpan_exp());
				writer.Write(value.exp);
				writer.WriteRaw(GetSpan_limit_break_count());
				writer.Write(value.limit_break_count);
			}

			public UserSupportCardAtFriend Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				int num = reader.ReadMapHeader();
				UserSupportCardAtFriend userSupportCardAtFriend = new UserSupportCardAtFriend();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					int length = span.Length;
					if (length != 3)
					{
						if (length != 15)
						{
							if (length == 17 && span.SequenceEqual(GetSpan_limit_break_count().Slice(1)))
							{
								userSupportCardAtFriend.limit_break_count = reader.ReadInt32();
								continue;
							}
						}
						else if (span.SequenceEqual(GetSpan_support_card_id().Slice(1)))
						{
							userSupportCardAtFriend.support_card_id = reader.ReadInt32();
							continue;
						}
					}
					else if (AutomataKeyGen.GetKey(ref span) == 7370853)
					{
						userSupportCardAtFriend.exp = reader.ReadInt32();
						continue;
					}
					reader.Skip();
				}
				reader.Depth--;
				return userSupportCardAtFriend;
			}
		}

		internal sealed class UserTrainedCharaAtFriendFormatter : IMessagePackFormatter<UserTrainedCharaAtFriend>, IMessagePackFormatter
		{
			private static ReadOnlySpan<byte> GetSpan_viewer_id()
			{
				return new byte[10] { 169, 118, 105, 101, 119, 101, 114, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_trained_chara_id()
			{
				return new byte[17]
				{
					176, 116, 114, 97, 105, 110, 101, 100, 95, 99,
					104, 97, 114, 97, 95, 105, 100
				};
			}

			private static ReadOnlySpan<byte> GetSpan_card_id()
			{
				return new byte[8] { 167, 99, 97, 114, 100, 95, 105, 100 };
			}

			private static ReadOnlySpan<byte> GetSpan_rank_score()
			{
				return new byte[11]
				{
					170, 114, 97, 110, 107, 95, 115, 99, 111, 114,
					101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_rank()
			{
				return new byte[5] { 164, 114, 97, 110, 107 };
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_short()
			{
				return new byte[22]
				{
					181, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 115, 104, 111,
					114, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_mile()
			{
				return new byte[21]
				{
					180, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 109, 105, 108,
					101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_middle()
			{
				return new byte[23]
				{
					182, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 109, 105, 100,
					100, 108, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_distance_long()
			{
				return new byte[21]
				{
					180, 112, 114, 111, 112, 101, 114, 95, 100, 105,
					115, 116, 97, 110, 99, 101, 95, 108, 111, 110,
					103
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_nige()
			{
				return new byte[26]
				{
					185, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 110, 105, 103, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_senko()
			{
				return new byte[27]
				{
					186, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 115, 101, 110, 107, 111
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_sashi()
			{
				return new byte[27]
				{
					186, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 115, 97, 115, 104, 105
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_running_style_oikomi()
			{
				return new byte[28]
				{
					187, 112, 114, 111, 112, 101, 114, 95, 114, 117,
					110, 110, 105, 110, 103, 95, 115, 116, 121, 108,
					101, 95, 111, 105, 107, 111, 109, 105
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_ground_turf()
			{
				return new byte[19]
				{
					178, 112, 114, 111, 112, 101, 114, 95, 103, 114,
					111, 117, 110, 100, 95, 116, 117, 114, 102
				};
			}

			private static ReadOnlySpan<byte> GetSpan_proper_ground_dirt()
			{
				return new byte[19]
				{
					178, 112, 114, 111, 112, 101, 114, 95, 103, 114,
					111, 117, 110, 100, 95, 100, 105, 114, 116
				};
			}

			private static ReadOnlySpan<byte> GetSpan_rarity()
			{
				return new byte[7] { 166, 114, 97, 114, 105, 116, 121 };
			}

			private static ReadOnlySpan<byte> GetSpan_talent_level()
			{
				return new byte[13]
				{
					172, 116, 97, 108, 101, 110, 116, 95, 108, 101,
					118, 101, 108
				};
			}

			private static ReadOnlySpan<byte> GetSpan_register_time()
			{
				return new byte[14]
				{
					173, 114, 101, 103, 105, 115, 116, 101, 114, 95,
					116, 105, 109, 101
				};
			}

			private static ReadOnlySpan<byte> GetSpan_factor_id_array()
			{
				return new byte[16]
				{
					175, 102, 97, 99, 116, 111, 114, 95, 105, 100,
					95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_factor_info_array()
			{
				return new byte[18]
				{
					177, 102, 97, 99, 116, 111, 114, 95, 105, 110,
					102, 111, 95, 97, 114, 114, 97, 121
				};
			}

			private static ReadOnlySpan<byte> GetSpan_skill_count()
			{
				return new byte[12]
				{
					171, 115, 107, 105, 108, 108, 95, 99, 111, 117,
					110, 116
				};
			}

			public void Serialize(ref MessagePackWriter writer, UserTrainedCharaAtFriend value, MessagePackSerializerOptions options)
			{
				if (value == null)
				{
					writer.WriteNil();
					return;
				}
				IFormatterResolver resolver = options.Resolver;
				writer.WriteMapHeader(21);
				writer.WriteRaw(GetSpan_viewer_id());
				writer.Write(value.viewer_id);
				writer.WriteRaw(GetSpan_trained_chara_id());
				writer.Write(value.trained_chara_id);
				writer.WriteRaw(GetSpan_card_id());
				writer.Write(value.card_id);
				writer.WriteRaw(GetSpan_rank_score());
				writer.Write(value.rank_score);
				writer.WriteRaw(GetSpan_rank());
				writer.Write(value.rank);
				writer.WriteRaw(GetSpan_proper_distance_short());
				writer.Write(value.proper_distance_short);
				writer.WriteRaw(GetSpan_proper_distance_mile());
				writer.Write(value.proper_distance_mile);
				writer.WriteRaw(GetSpan_proper_distance_middle());
				writer.Write(value.proper_distance_middle);
				writer.WriteRaw(GetSpan_proper_distance_long());
				writer.Write(value.proper_distance_long);
				writer.WriteRaw(GetSpan_proper_running_style_nige());
				writer.Write(value.proper_running_style_nige);
				writer.WriteRaw(GetSpan_proper_running_style_senko());
				writer.Write(value.proper_running_style_senko);
				writer.WriteRaw(GetSpan_proper_running_style_sashi());
				writer.Write(value.proper_running_style_sashi);
				writer.WriteRaw(GetSpan_proper_running_style_oikomi());
				writer.Write(value.proper_running_style_oikomi);
				writer.WriteRaw(GetSpan_proper_ground_turf());
				writer.Write(value.proper_ground_turf);
				writer.WriteRaw(GetSpan_proper_ground_dirt());
				writer.Write(value.proper_ground_dirt);
				writer.WriteRaw(GetSpan_rarity());
				writer.Write(value.rarity);
				writer.WriteRaw(GetSpan_talent_level());
				writer.Write(value.talent_level);
				writer.WriteRaw(GetSpan_register_time());
				resolver.GetFormatterWithVerify<string>().Serialize(ref writer, value.register_time, options);
				writer.WriteRaw(GetSpan_factor_id_array());
				resolver.GetFormatterWithVerify<int[]>().Serialize(ref writer, value.factor_id_array, options);
				writer.WriteRaw(GetSpan_factor_info_array());
				resolver.GetFormatterWithVerify<FactorInfo[]>().Serialize(ref writer, value.factor_info_array, options);
				writer.WriteRaw(GetSpan_skill_count());
				writer.Write(value.skill_count);
			}

			public UserTrainedCharaAtFriend Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
			{
				if (reader.TryReadNil())
				{
					return null;
				}
				options.Security.DepthStep(ref reader);
				IFormatterResolver resolver = options.Resolver;
				int num = reader.ReadMapHeader();
				UserTrainedCharaAtFriend userTrainedCharaAtFriend = new UserTrainedCharaAtFriend();
				for (int i = 0; i < num; i++)
				{
					ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
					switch (span.Length)
					{
					default:
						reader.Skip();
						break;
					case 9:
						if (span.SequenceEqual(GetSpan_viewer_id().Slice(1)))
						{
							userTrainedCharaAtFriend.viewer_id = reader.ReadInt64();
							break;
						}
						goto default;
					case 16:
						if (span.SequenceEqual(GetSpan_trained_chara_id().Slice(1)))
						{
							userTrainedCharaAtFriend.trained_chara_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 7:
						if (AutomataKeyGen.GetKey(ref span) == 28263356099092835L)
						{
							userTrainedCharaAtFriend.card_id = reader.ReadInt32();
							break;
						}
						goto default;
					case 10:
						if (span.SequenceEqual(GetSpan_rank_score().Slice(1)))
						{
							userTrainedCharaAtFriend.rank_score = reader.ReadInt32();
							break;
						}
						goto default;
					case 4:
						if (AutomataKeyGen.GetKey(ref span) == 1802396018)
						{
							userTrainedCharaAtFriend.rank = reader.ReadInt32();
							break;
						}
						goto default;
					case 21:
						if (span.SequenceEqual(GetSpan_proper_distance_short().Slice(1)))
						{
							userTrainedCharaAtFriend.proper_distance_short = reader.ReadInt32();
							break;
						}
						goto default;
					case 20:
						if (AutomataKeyGen.GetKey(ref span) == 7232625306583921264L && AutomataKeyGen.GetKey(ref span) == 6874009731983504233L)
						{
							switch (AutomataKeyGen.GetKey(ref span))
							{
							case 1701603693uL:
								userTrainedCharaAtFriend.proper_distance_mile = reader.ReadInt32();
								goto end_IL_0046;
							case 1735290732uL:
								userTrainedCharaAtFriend.proper_distance_long = reader.ReadInt32();
								goto end_IL_0046;
							}
						}
						goto default;
					case 22:
						if (span.SequenceEqual(GetSpan_proper_distance_middle().Slice(1)))
						{
							userTrainedCharaAtFriend.proper_distance_middle = reader.ReadInt32();
							break;
						}
						goto default;
					case 25:
						if (span.SequenceEqual(GetSpan_proper_running_style_nige().Slice(1)))
						{
							userTrainedCharaAtFriend.proper_running_style_nige = reader.ReadInt32();
							break;
						}
						goto default;
					case 26:
						if (AutomataKeyGen.GetKey(ref span) == 8241431623114912368L && AutomataKeyGen.GetKey(ref span) == 8313477161062133365L)
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 7954891170380544372L)
							{
								if (key == 8314053240663341428L && AutomataKeyGen.GetKey(ref span) == 26984)
								{
									userTrainedCharaAtFriend.proper_running_style_sashi = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 28523)
							{
								userTrainedCharaAtFriend.proper_running_style_senko = reader.ReadInt32();
								break;
							}
						}
						goto default;
					case 27:
						if (span.SequenceEqual(GetSpan_proper_running_style_oikomi().Slice(1)))
						{
							userTrainedCharaAtFriend.proper_running_style_oikomi = reader.ReadInt32();
							break;
						}
						goto default;
					case 18:
						if (AutomataKeyGen.GetKey(ref span) == 7448798088697705072L)
						{
							ulong key = AutomataKeyGen.GetKey(ref span);
							if (key != 7594299756608057202L)
							{
								if (key == 8463494484690562930L && AutomataKeyGen.GetKey(ref span) == 26226)
								{
									userTrainedCharaAtFriend.proper_ground_turf = reader.ReadInt32();
									break;
								}
							}
							else if (AutomataKeyGen.GetKey(ref span) == 29810)
							{
								userTrainedCharaAtFriend.proper_ground_dirt = reader.ReadInt32();
								break;
							}
						}
						goto default;
					case 6:
						if (AutomataKeyGen.GetKey(ref span) == 133540892270962L)
						{
							userTrainedCharaAtFriend.rarity = reader.ReadInt32();
							break;
						}
						goto default;
					case 12:
						if (span.SequenceEqual(GetSpan_talent_level().Slice(1)))
						{
							userTrainedCharaAtFriend.talent_level = reader.ReadInt32();
							break;
						}
						goto default;
					case 13:
						if (span.SequenceEqual(GetSpan_register_time().Slice(1)))
						{
							userTrainedCharaAtFriend.register_time = resolver.GetFormatterWithVerify<string>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 15:
						if (span.SequenceEqual(GetSpan_factor_id_array().Slice(1)))
						{
							userTrainedCharaAtFriend.factor_id_array = resolver.GetFormatterWithVerify<int[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 17:
						if (span.SequenceEqual(GetSpan_factor_info_array().Slice(1)))
						{
							userTrainedCharaAtFriend.factor_info_array = resolver.GetFormatterWithVerify<FactorInfo[]>().Deserialize(ref reader, options);
							break;
						}
						goto default;
					case 11:
						{
							if (span.SequenceEqual(GetSpan_skill_count().Slice(1)))
							{
								userTrainedCharaAtFriend.skill_count = reader.ReadInt32();
								break;
							}
							goto default;
						}
						end_IL_0046:
						break;
					}
				}
				reader.Depth--;
				return userTrainedCharaAtFriend;
			}
		}
	}

	internal class Cute
	{
		internal class Http
		{
			internal sealed class DataHeaderFormatter : IMessagePackFormatter<DataHeader>, IMessagePackFormatter
			{
				private static ReadOnlySpan<byte> GetSpan_result_code()
				{
					return new byte[12]
					{
						171, 114, 101, 115, 117, 108, 116, 95, 99, 111,
						100, 101
					};
				}

				public void Serialize(ref MessagePackWriter writer, DataHeader value, MessagePackSerializerOptions options)
				{
					if (value == null)
					{
						writer.WriteNil();
						return;
					}
					writer.WriteMapHeader(1);
					writer.WriteRaw(GetSpan_result_code());
					writer.Write(value.result_code);
				}

				public DataHeader Deserialize(ref MessagePackReader reader, MessagePackSerializerOptions options)
				{
					if (reader.TryReadNil())
					{
						return null;
					}
					options.Security.DepthStep(ref reader);
					int num = reader.ReadMapHeader();
					DataHeader dataHeader = new DataHeader();
					for (int i = 0; i < num; i++)
					{
						ReadOnlySpan<byte> span = CodeGenHelpers.ReadStringSpan(ref reader);
						if (span.Length != 11 || !span.SequenceEqual(GetSpan_result_code().Slice(1)))
						{
							reader.Skip();
						}
						else
						{
							dataHeader.result_code = reader.ReadInt32();
						}
					}
					reader.Depth--;
					return dataHeader;
				}
			}
		}
	}

	public static readonly IFormatterResolver Instance = new GeneratedMessagePackResolver();

	private GeneratedMessagePackResolver()
	{
	}

	public IMessagePackFormatter<T> GetFormatter<T>()
	{
		return FormatterCache<T>.Formatter;
	}
}
