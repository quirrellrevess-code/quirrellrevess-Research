using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;
using MessagePack;
using MessagePack.Internal;

[assembly: AssemblyCompany("UmamusumeResponseAnalyzer")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.14.3.2")]
[assembly: AssemblyInformationalVersion("1.14.3.2+4f85edeaacc86d30121edd7383a9278da05d58c9")]
[assembly: AssemblyProduct("UmamusumeResponseAnalyzer")]
[assembly: AssemblyTitle("UmamusumeResponseAnalyzer")]
[assembly: GeneratedAssemblyMessagePackResolver(typeof(GeneratedMessagePackResolver), 3, 1)]
[assembly: AssemblyVersion("1.14.3.2")]
