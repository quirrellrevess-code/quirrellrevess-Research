namespace Gallop.Mecha;

public class SingleModeMechaUpgradeRaceResult
{
	public int schedule_id;

	public int result_type;
}
